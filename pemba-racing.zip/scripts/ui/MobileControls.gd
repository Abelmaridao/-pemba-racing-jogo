class_name MobileControls
extends Control
## MobileControls: controlos para telemóvel com MULTI-TOQUE (acelerar + virar + travar ao mesmo tempo).
## Inclui: acelerar, travar, marcha-atrás, travão de mão, direção (botões, volante virtual ou inclinação),
## mudar câmara e pausa. No computador também funciona com teclado: W/S, A/D (ou setas), Espaço, C, P.
## Os botões são desenhados por nós e os toques tratados à mão porque os botões normais do Godot
## só aceitam um dedo de cada vez.

signal camera_pressed
signal pause_pressed

var _btns: Dictionary = {}     # nome -> Control
var _touch: Dictionary = {}    # índice do dedo -> nome do botão
var _wheel: Control = null
var _wheel_vis: Control = null
var _wheel_idx: int = -1
var _wheel_val: float = 0.0
var _tilt_zero: float = 0.0
var _tilt_ready: bool = false
var _steer: float = 0.0
var override_input = null      # usado pelos testes automáticos

## Modo de edição (ecrã "Editar controlos" nas Configurações): mostra TODOS os botões (mesmo os
## desativados, a tracejado) e permite arrastá-los para nova posição em vez de os usar para conduzir.
var edit_mode: bool = false
var _btn_base_pos: Dictionary = {}   # id -> posição por omissão (antes do deslocamento guardado)
var _drag_id: String = ""
var _drag_touch_start: Vector2 = Vector2.ZERO
var _drag_btn_start: Vector2 = Vector2.ZERO


func _is_on(id: String) -> bool:
	if not (id in Settings.EDITABLE_BUTTONS):
		return true
	return edit_mode or bool(Settings.button_enabled.get(id, true))


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	U.full(self)
	var root := U.safe_root(self)
	var ctype: int = Settings.control_type
	var bl := Vector2(0, 1)
	var br := Vector2(1, 1)
	var tr := Vector2(1, 0)

	if ctype == 0:
		_vbtn(root, "left", "<", Color(0.10, 0.40, 0.90, 0.5), bl, Vector2(10, 10), Vector2(230, 230), 90)
		_vbtn(root, "right", ">", Color(0.10, 0.40, 0.90, 0.5), bl, Vector2(260, 10), Vector2(230, 230), 90)
	elif ctype == 1:
		_wheel = U.panel(Color(1, 1, 1, 0.12), 190)
		root.add_child(_wheel)
		U.place(_wheel, bl, Vector2(20, 0), Vector2(380, 380))
		_wheel_vis = U.panel(Color(0.9, 0.13, 0.17, 0.5), 150)
		_wheel.add_child(_wheel_vis)
		U.place(_wheel_vis, Vector2(0.5, 0.5), Vector2.ZERO, Vector2(300, 300))
		_wheel_vis.pivot_offset = Vector2(150, 150)
		var hubp := U.panel(Color(0, 0, 0, 0.5), 95)
		_wheel_vis.add_child(hubp)
		U.place(hubp, Vector2(0.5, 0.5), Vector2.ZERO, Vector2(190, 190))
		var mark := U.panel(Color(1, 1, 1, 0.9), 8)
		_wheel_vis.add_child(mark)
		U.place(mark, Vector2(0.5, 0), Vector2.ZERO, Vector2(36, 60))
	else:
		var tip := U.label(U.t("INCLINA O TELEMÓVEL", "TILT YOUR PHONE"), 34, Color(1, 1, 1, 0.55))
		root.add_child(tip)
		U.place(tip, bl, Vector2(20, 20), Vector2(600, 60))

	_vbtn(root, "gas", U.t("ACELERAR", "GAS"), Color(0.10, 0.75, 0.35, 0.5), br, Vector2(10, 10), Vector2(300, 260), 44)
	_vbtn(root, "brake", U.t("TRAVAR", "BRAKE"), Color(0.90, 0.13, 0.17, 0.5), br, Vector2(330, 10), Vector2(220, 170), 36)
	_vbtn(root, "rev", U.t("MARCHA ATRÁS", "REVERSE"), Color(0.30, 0.33, 0.40, 0.55), br, Vector2(330, 200), Vector2(220, 90), 26)
	_vbtn(root, "hand", U.t("TRAVÃO DE MÃO", "HANDBRAKE"), Color(0.95, 0.5, 0.1, 0.5), br, Vector2(10, 290), Vector2(300, 90), 26)
	_vbtn(root, "nitro", "NITRO", Color(0.15, 0.55, 1.0, 0.65), br, Vector2(570, 10), Vector2(200, 170), 36)
	_vbtn(root, "cam", U.t("CÂMARA", "CAM"), Color(0.10, 0.40, 0.90, 0.7), tr, Vector2(10, 10), Vector2(190, 90), 30)
	_vbtn(root, "pause", "II", Color(0.30, 0.33, 0.40, 0.8), tr, Vector2(220, 10), Vector2(110, 90), 40)


func _vbtn(parent: Control, id: String, text: String, color: Color, anchor: Vector2, pos: Vector2, size: Vector2, fs: int) -> void:
	if not _is_on(id):
		return
	var p := U.panel(color, 28)
	parent.add_child(p)
	U.place(p, anchor, pos, size)
	_btn_base_pos[id] = p.position
	if id in Settings.EDITABLE_BUTTONS:
		p.position += Settings.button_offset.get(id, Vector2.ZERO)
	var l := U.label(text, fs, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	p.add_child(l)
	U.full(l)
	if edit_mode and id in Settings.EDITABLE_BUTTONS and not bool(Settings.button_enabled.get(id, true)):
		p.modulate.a = 0.35
	_btns[id] = p


## Mostra a carga do nitro no botão (texto + escurece quando vazio).
func set_nitro(v: float, on: bool) -> void:
	if not _btns.has("nitro"):
		return
	var p: Control = _btns["nitro"]
	for c in p.get_children():
		if c is Label:
			(c as Label).text = "NITRO\n%d%%" % int(round(v * 100.0)) if not on else "NITRO\n>>>"
	p.self_modulate = Color(1, 1, 1, 1) if v > 0.25 or on else Color(1, 0.6, 0.6, 1)


func held(id: String) -> bool:
	for k in _touch:
		if _touch[k] == id:
			return true
	return false


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_press(event.index, event.position)
		else:
			_release(event.index)
	elif event is InputEventScreenDrag:
		if edit_mode and _drag_id != "":
			var c: Control = _btns[_drag_id]
			c.position = _drag_btn_start + (event.position - _drag_touch_start)
		elif event.index == _wheel_idx:
			_wheel_move(event.position)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_C:
			camera_pressed.emit()
		elif event.keycode == KEY_P:
			pause_pressed.emit()


func _press(index: int, pos: Vector2) -> void:
	for id in _btns:
		var c: Control = _btns[id]
		if c.get_global_rect().has_point(pos):
			if edit_mode and id in Settings.EDITABLE_BUTTONS:
				_drag_id = id
				_drag_touch_start = pos
				_drag_btn_start = c.position
			elif id == "cam":
				camera_pressed.emit()
			elif id == "pause":
				pause_pressed.emit()
			else:
				_touch[index] = id
			return
	if _wheel != null and _wheel.get_global_rect().has_point(pos):
		_wheel_idx = index
		_wheel_move(pos)


func _release(index: int) -> void:
	_touch.erase(index)
	if _drag_id != "":
		var base: Vector2 = _btn_base_pos.get(_drag_id, _drag_btn_start)
		Settings.button_offset[_drag_id] = (_btns[_drag_id] as Control).position - base
		Settings.save()
		_drag_id = ""
	if index == _wheel_idx:
		_wheel_idx = -1
		_wheel_val = 0.0
		if _wheel_vis:
			_wheel_vis.rotation = 0.0


func _wheel_move(pos: Vector2) -> void:
	var r := _wheel.get_global_rect()
	_wheel_val = clampf((pos.x - r.get_center().x) / (r.size.x * 0.4), -1.0, 1.0)
	if _wheel_vis:
		_wheel_vis.rotation = deg_to_rad(_wheel_val * 100.0)


func _process(_delta: float) -> void:
	if edit_mode:
		return
	for id in _btns:
		(_btns[id] as Control).modulate.a = 1.0 if held(id) else 0.72


## Lê o estado de todos os controlos (toque + teclado). Devolve o dicionário "drive" do CarController.
func read(delta: float) -> Dictionary:
	if override_input != null:
		return override_input
	var r := {"throttle": 0.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": false, "nitro": false}
	if Input.is_key_pressed(KEY_N) or Input.is_key_pressed(KEY_SHIFT):
		r["nitro"] = true
	if held("nitro"):
		r["nitro"] = true
	var target := 0.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		r["throttle"] = 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		r["brake"] = 1.0
		r["reverse"] = true
	if Input.is_key_pressed(KEY_SPACE):
		r["handbrake"] = true
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		target -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		target += 1.0

	if held("gas"):
		r["throttle"] = 1.0
	if held("brake"):
		r["brake"] = 1.0
	if held("rev"):
		r["reverse"] = true
	if held("hand"):
		r["handbrake"] = true

	var ctype: int = Settings.control_type
	if ctype == 0:
		if held("left"):
			target -= 1.0
		if held("right"):
			target += 1.0
	elif ctype == 1:
		target += _wheel_val
	else:
		# Inclinação: o jogo corre sempre na horizontal (paisagem), por isso ao rodar o telemóvel para a
		# esquerda/direita é o eixo X do acelerómetro que muda (não o Y, que fica preso perto de -9.8 porque é
		# o telemóvel a apontar para baixo/cima na mão). Calibra-se sozinho na primeira leitura (zero = como o
		# jogador está a segurar o telemóvel ao começar a usar a inclinação).
		var ax: float = Input.get_accelerometer().x
		if not _tilt_ready:
			_tilt_zero = ax
			_tilt_ready = true
		target += clampf((ax - _tilt_zero) / 9.8 * 4.2, -1.0, 1.0) * (-1.0 if DisplayServer.screen_get_orientation() == DisplayServer.SCREEN_REVERSE_LANDSCAPE else 1.0)

	target = clampf(target, -1.0, 1.0)
	var rate: float = 5.0 if absf(target) > 0.01 else 8.0
	_steer = move_toward(_steer, target, rate * delta)
	r["steer"] = clampf(_steer * Settings.sensitivity, -1.0, 1.0)
	return r
