class_name AIController
extends RefCounted
## AIController: piloto automático. Segue a linha da pista com um alvo à frente (mais longe a alta velocidade),
## trava antes das curvas calculando a velocidade possível, muda um pouco de faixa para não andar colado aos outros,
## recupera se ficar preso e ajusta a velocidade à dificuldade (e um pouco ao jogador, para a corrida ficar disputada).
const IMPLEMENTED := true

var car: CarController
var circuit: Circuit
var skill: float = 0.9          # 0.8 fácil .. 0.97 difícil
var lane: float = 0.0           # deslocamento lateral preferido (m)
var phase: float = 0.0
var idx: int = 0
var _stuck_t: float = 0.0
var _rev_t: float = 0.0
var _t: float = 0.0
var rubber: float = 1.0         # ajuste dinâmico (atualizado pela corrida)


func setup(c: CarController, circ: Circuit, sk: float, ln: float, ph: float) -> void:
	car = c
	circuit = circ
	skill = sk
	lane = ln
	phase = ph
	idx = circ.nearest_global(c.global_position)


func update(delta: float) -> void:
	_t += delta
	var pos: Vector3 = car.global_position
	if not _synced or pos.distance_to(circuit.P[idx]) > circuit.hw + 25.0:
		idx = circuit.nearest_global(pos)   # o carro ainda não estava na grelha quando o piloto foi criado
		_synced = true
	idx = circuit.nearest(pos, idx)
	var N: int = circuit.N
	var speed: float = absf(car.forward_speed)
	var vmax: float = float(car.stats["max_ms"])
	# recuperar quando preso (marcha-atrás com direção contrária)
	if _rev_t > 0.0:
		_rev_t -= delta
		car.drive = {"throttle": 0.0, "brake": 0.0, "steer": -signf(_last_steer), "reverse": true, "handbrake": false}
		return
	if speed < 1.0 and car.controllable:
		_stuck_t += delta
		if _stuck_t > 1.6:
			_stuck_t = 0.0
			_rev_t = 1.1
	else:
		_stuck_t = 0.0
	# alvo à frente
	var look: float = 12.0 + speed * 0.55
	var ahead: int = (idx + int(look / circuit.ds)) % N
	var my_lane: float = lane + sin(_t * 0.35 + phase) * 1.5
	my_lane = clampf(my_lane, -(circuit.hw - 2.5), circuit.hw - 2.5)
	var target: Vector3 = circuit.P[ahead] + circuit.R[ahead] * my_lane
	var local: Vector3 = car.global_transform.basis.inverse() * (target - pos)
	var angle: float = atan2(local.x, -local.z)
	var steer: float = clampf(angle * 1.8, -1.0, 1.0)
	_last_steer = steer
	# velocidade de curva: v = s / (k + 0.45 s / vmax), com s = velocidade angular máxima disponível
	var kmax: float = 0.0
	var span: int = int((speed * 1.4 + 10.0) / circuit.ds)
	for o in range(0, span + 1, 2):
		kmax = maxf(kmax, circuit.K[(idx + o) % N])
	var srate: float = deg_to_rad(float(car.stats["steer"])) * 0.62
	var vcorner: float = srate / (kmax + 0.45 * srate / vmax)
	var vt: float = minf(vmax * skill * rubber, vcorner * (0.85 + 0.2 * skill))
	var thr: float = 0.0
	var brk: float = 0.0
	if speed < vt:
		thr = clampf((vt - speed) / 4.0 + 0.4, 0.0, 1.0)
	else:
		brk = clampf((speed - vt) / 7.0, 0.0, 1.0)
		if brk < 0.15:
			brk = 0.0
	car.drive = {"throttle": thr, "brake": brk, "steer": steer, "reverse": false, "handbrake": false}

var _last_steer: float = 0.0
var dbg: String = ""
var _synced: bool = false
