extends Node
## SettingsManager (autoload "Settings")
## Configurações do jogador: qualidade gráfica, volumes, sensibilidade, tipo de controlo e idioma.
## Guardadas em user://settings.cfg e aplicadas imediatamente.

const PATH := "user://settings.cfg"

var quality: int = 1          # 0 baixa, 1 média, 2 alta
var music_vol: float = 0.7
var sfx_vol: float = 0.9
var sensitivity: float = 1.0  # 0.5 a 1.5
var control_type: int = 0     # 0 botões, 1 volante virtual, 2 inclinação do telemóvel
var language: int = 0         # 0 português, 1 inglês

## Personalização dos botões de controlo (ecrã "Editar controlos" nas Configurações):
## button_enabled: id -> mostrar ou não o botão numa corrida (só os necessários para a partida).
## button_offset: id -> deslocamento (em pixels) a partir da posição por omissão, arrastado pelo jogador.
const EDITABLE_BUTTONS := ["gas", "brake", "rev", "hand", "nitro", "cam", "pause"]
var button_enabled: Dictionary = {}
var button_offset: Dictionary = {}


func _ready() -> void:
	_load()
	apply()


func _load() -> void:
	var cf := ConfigFile.new()
	var default_q := 1
	# Telemóveis começam em qualidade baixa (liso em aparelhos fracos); só ficam em média com 6 GB de RAM ou mais.
	var os_name := OS.get_name()
	if os_name == "Android" or os_name == "iOS":
		default_q = 0
		var mem: Dictionary = OS.get_memory_info()
		var phys: int = int(mem.get("physical", 0))
		if phys >= 6_000_000_000:
			default_q = 1
	if cf.load(PATH) == OK:
		quality = int(cf.get_value("s", "quality", default_q))
		music_vol = float(cf.get_value("s", "music", 0.7))
		sfx_vol = float(cf.get_value("s", "sfx", 0.9))
		sensitivity = float(cf.get_value("s", "sens", 1.0))
		control_type = int(cf.get_value("s", "ctrl", 0))
		language = int(cf.get_value("s", "lang", 0))
		button_enabled = cf.get_value("s", "btn_on", {})
		button_offset = cf.get_value("s", "btn_pos", {})
	else:
		quality = default_q
		language = 1 if OS.get_locale_language() == "en" else 0
	for id in EDITABLE_BUTTONS:
		if not button_enabled.has(id):
			button_enabled[id] = true
		if not button_offset.has(id):
			button_offset[id] = Vector2.ZERO


func save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("s", "quality", quality)
	cf.set_value("s", "music", music_vol)
	cf.set_value("s", "sfx", sfx_vol)
	cf.set_value("s", "sens", sensitivity)
	cf.set_value("s", "ctrl", control_type)
	cf.set_value("s", "lang", language)
	cf.set_value("s", "btn_on", button_enabled)
	cf.set_value("s", "btn_pos", button_offset)
	cf.save(PATH)


## Repõe todos os botões de controlo na posição e visibilidade por omissão.
func reset_buttons() -> void:
	for id in EDITABLE_BUTTONS:
		button_enabled[id] = true
		button_offset[id] = Vector2.ZERO
	save()


## Aplica qualidade gráfica e volumes.
## Nota: MSAA é muito pesado nos GPUs dos telemóveis (o "colar" na qualidade alta vinha daqui) —
## por isso usamos FXAA (muito mais leve) em vez de MSAA, e baixámos um pouco a escala/sombra da
## qualidade alta para ficar fluida sem perder muito visual.
func apply() -> void:
	Engine.max_fps = 30 if quality == 0 else 60
	var vp := get_viewport()
	if vp:
		vp.msaa_3d = Viewport.MSAA_DISABLED
		vp.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA if quality >= 1 else Viewport.SCREEN_SPACE_AA_DISABLED
		vp.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR
		vp.scaling_3d_scale = [0.58, 0.74, 0.85][quality]   # menos pixels 3D = muito mais leve
		vp.use_debanding = false
	if has_node("/root/Audio"):
		Audio.refresh_volumes()


## Sombras dinâmicas em tempo real são a parte mais pesada no GPU dos telemóveis (GL Compatibility) —
## era a maior causa do "colar" mesmo depois de trocar MSAA por FXAA. Por isso ficam sempre desligadas;
## os carros continuam a ter uma sombra falsa (a mancha escura debaixo de cada um) que já não custa nada.
func shadows_enabled() -> bool:
	return false


func fog_enabled() -> bool:
	return quality >= 1


func shadow_size() -> int:
	return 1024
