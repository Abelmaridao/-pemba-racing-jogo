extends Node
## MultiplayerManager (autoload "MP")
## Lógica do jogo em rede: lista de jogadores da sala, escolhas do anfitrião (pista, voltas), início sincronizado da corrida,
## troca do estado dos carros (~20 vezes por segundo) e saída de jogadores. O anfitrião (peer 1) manda na sala.

signal players_changed
signal host_lost

var players: Dictionary = {}      # peer_id -> {name, car, color, rim, finish, up_speed, up_accel, up_brake}
var track: String = "savana"
var laps: int = 3
var states: Dictionary = {}       # peer_id -> último estado recebido
var countdown_go: bool = false
var in_race: bool = false
var _ready_set: Dictionary = {}
var last_error: String = ""


func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	Net.connected_ok.connect(_on_connected)
	Net.server_lost.connect(func() -> void:
		players.clear()
		in_race = false
		host_lost.emit())


func my_id() -> int:
	return multiplayer.get_unique_id() if Net.has_peer() else 1


func is_host() -> bool:
	return Net.hosting


func my_info() -> Dictionary:
	var sel: String = str(Game.save["selected"])
	var sv: Dictionary = CarSelection.get_car(sel)
	var nm: String = str(Game.save.get("pname", ""))
	if nm == "":
		nm = "JOGADOR%d" % (randi() % 90 + 10)
		Game.save["pname"] = nm
		Game.save_game()
	return {"name": nm, "car": sel, "color": int(sv["color"]), "rim": int(sv["rim"]), "finish": int(sv["finish"]),
		"up_speed": int(sv["up_speed"]), "up_accel": int(sv["up_accel"]), "up_brake": int(sv["up_brake"])}


# ---------- Sala ----------
func create_room() -> int:
	var info: Dictionary = my_info()
	var err: int = Net.host(str(info["name"]))
	if err != OK:
		return err
	players = {1: info}
	_reset_race_state()
	players_changed.emit()
	return OK


func join_room(ip: String) -> int:
	players.clear()
	_reset_race_state()
	return Net.join(ip)


func leave() -> void:
	Net.leave()
	players.clear()
	_reset_race_state()


func _reset_race_state() -> void:
	states.clear()
	countdown_go = false
	in_race = false
	_ready_set.clear()


func _on_connected() -> void:
	_register.rpc_id(1, my_info())


func _on_peer_connected(_id: int) -> void:
	pass


func _on_peer_disconnected(id: int) -> void:
	if players.has(id):
		players.erase(id)
	states.erase(id)
	if Net.hosting:
		_sync_players.rpc(players, track, laps)
	players_changed.emit()


@rpc("any_peer", "reliable")
func _register(info: Dictionary) -> void:
	if not Net.hosting:
		return
	var id: int = multiplayer.get_remote_sender_id()
	if in_race or players.size() >= Net.MAX_PLAYERS:
		_kick.rpc_id(id, "Sala cheia ou corrida em curso")
		return
	players[id] = info
	_sync_players.rpc(players, track, laps)
	players_changed.emit()


@rpc("authority", "reliable")
func _kick(msg: String) -> void:
	last_error = msg
	leave()
	host_lost.emit()


@rpc("authority", "reliable")
func _sync_players(p: Dictionary, trk: String, lp: int) -> void:
	players = p
	track = trk
	laps = lp
	players_changed.emit()


## O jogador muda de carro/cor (por exemplo depois de ir à garagem).
func refresh_my_info() -> void:
	if not Net.has_peer():
		return
	if Net.hosting:
		players[1] = my_info()
		_sync_players.rpc(players, track, laps)
		players_changed.emit()
	else:
		_update_info.rpc_id(1, my_info())


@rpc("any_peer", "reliable")
func _update_info(info: Dictionary) -> void:
	if not Net.hosting:
		return
	var id: int = multiplayer.get_remote_sender_id()
	if players.has(id):
		players[id] = info
		_sync_players.rpc(players, track, laps)
		players_changed.emit()


func set_track(id: String) -> void:
	if not Net.hosting:
		return
	track = id
	_sync_players.rpc(players, track, laps)
	players_changed.emit()


func set_laps(n: int) -> void:
	if not Net.hosting:
		return
	laps = clampi(n, 1, 10)
	_sync_players.rpc(players, track, laps)
	players_changed.emit()


# ---------- Início da corrida ----------
func start_race() -> bool:
	if not Net.hosting or players.size() < 2:
		return false
	var plist: Array = []
	var ids: Array = players.keys()
	ids.sort()
	for i in ids.size():
		var p: Dictionary = (players[ids[i]] as Dictionary).duplicate()
		p["peer"] = int(ids[i])
		p["slot"] = i
		plist.append(p)
	var cfg := {"mode": "mp", "track": track, "laps": laps, "players": plist, "difficulty": 1}
	_begin.rpc(cfg)
	return true


@rpc("authority", "call_local", "reliable")
func _begin(cfg: Dictionary) -> void:
	states.clear()
	countdown_go = false
	_ready_set.clear()
	in_race = true
	Game.go_race(cfg)


## Cada telemóvel avisa quando acabou de carregar a pista; o anfitrião dá o sinal quando todos estão prontos.
func race_ready() -> void:
	if Net.hosting:
		_mark_ready(1)
	else:
		_ready_rpc.rpc_id(1)


@rpc("any_peer", "reliable")
func _ready_rpc() -> void:
	if Net.hosting:
		_mark_ready(multiplayer.get_remote_sender_id())


func _mark_ready(id: int) -> void:
	_ready_set[id] = true
	var all: bool = true
	for k in players.keys():
		if not _ready_set.has(k):
			all = false
	if all:
		_go.rpc()


@rpc("authority", "call_local", "reliable")
func _go() -> void:
	countdown_go = true


# ---------- Estado dos carros ----------
func send_state(d: Dictionary) -> void:
	if Net.has_peer():
		_state.rpc(d)


@rpc("any_peer", "unreliable")
func _state(d: Dictionary) -> void:
	states[multiplayer.get_remote_sender_id()] = d
