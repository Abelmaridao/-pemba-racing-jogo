class_name RaceSetupManager
extends Node
## Ecrã "JOGAR": escolhe a pista, o número de voltas, os adversários e a dificuldade; mostra o carro e vai para a corrida.

var _ui: CanvasLayer
var _root: Control
var _track_i: int = 0
var _laps: int = 3
var _opp: int = 5
var _diff: int = 1
var _prev: PreviewDraw
var _name_l: Label
var _info_l: Label
var _laps_l: Label
var _opp_l: Label
var _diff_l: Label
var _car_l: Label


class PreviewDraw extends Control:
	var pts := PackedVector2Array()
	var col := Color(1, 1, 1)
	func _draw() -> void:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.03, 0.06, 0.14, 0.85), true)
		if pts.size() > 2:
			var c := PackedVector2Array(pts)
			c.append(pts[0])
			draw_polyline(c, col, 7.0, true)
			var p0: Vector2 = pts[0]
			draw_circle(p0, 12.0, Color(1, 1, 1))


func _ready() -> void:
	var s: Dictionary = Game.save.get("setup", {})
	_track_i = clampi(int(s.get("track", 0)), 0, TrackData.ALL.size() - 1)
	_laps = clampi(int(s.get("laps", 3)), 1, 5)
	_opp = clampi(int(s.get("opp", 5)), 1, 11)
	_diff = clampi(int(s.get("diff", 1)), 0, 3)
	_build()
	_refresh()


func _build() -> void:
	_ui = CanvasLayer.new()
	add_child(_ui)
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.04, 0.10)
	_ui.add_child(bg)
	U.full(bg)
	var host := Control.new()
	host.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui.add_child(host)
	U.full(host)
	_root = U.safe_root(host)
	var title := U.label(U.t("CORRIDA RÁPIDA", "QUICK RACE"), 78, Color.WHITE)
	_root.add_child(title)
	U.place(title, Vector2(0, 0), Vector2(20, 4), Vector2(1200, 100))
	# pista
	_prev = PreviewDraw.new()
	_prev.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_prev)
	U.place(_prev, Vector2(0, 0), Vector2(20, 130), Vector2(640, 640))
	_name_l = U.label("", 52, Color(1, 0.85, 0.2), HORIZONTAL_ALIGNMENT_CENTER)
	_root.add_child(_name_l)
	U.place(_name_l, Vector2(0, 0), Vector2(160, 780), Vector2(400, 70))
	_info_l = U.label("", 30, Color(0.7, 0.85, 1.0), HORIZONTAL_ALIGNMENT_CENTER, false)
	_root.add_child(_info_l)
	U.place(_info_l, Vector2(0, 0), Vector2(60, 845), Vector2(600, 44))
	var pb := U.button("◀", U.BLUE, Vector2(120, 80), 52, func() -> void: _move_track(-1))
	_root.add_child(pb)
	U.place(pb, Vector2(0, 0), Vector2(20, 782), Vector2(120, 80))
	var nb := U.button("▶", U.BLUE, Vector2(120, 80), 52, func() -> void: _move_track(1))
	_root.add_child(nb)
	U.place(nb, Vector2(0, 0), Vector2(540, 782), Vector2(120, 80))
	# opções à direita
	var x: float = 760.0
	var y: float = 150.0
	_laps_l = _row(U.t("Voltas", "Laps"), x, y, func() -> void: _laps = maxi(1, _laps - 1); _refresh(), func() -> void: _laps = mini(5, _laps + 1); _refresh())
	y += 130.0
	_opp_l = _row(U.t("Adversários", "Opponents"), x, y, func() -> void: _opp = maxi(1, _opp - 1); _refresh(), func() -> void: _opp = mini(11, _opp + 1); _refresh())
	y += 130.0
	_diff_l = _row(U.t("Dificuldade", "Difficulty"), x, y, func() -> void: _diff = (_diff + 3) % 4; _refresh(), func() -> void: _diff = (_diff + 1) % 4; _refresh())
	y += 130.0
	_car_l = U.label("", 40, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
	_root.add_child(_car_l)
	U.place(_car_l, Vector2(0, 0), Vector2(x, y), Vector2(700, 60))
	var start := U.button(U.t("COMEÇAR!", "START!"), U.RED, Vector2(560, 120), 58, _start)
	_root.add_child(start)
	U.place(start, Vector2(1, 1), Vector2(10, 10), Vector2(560, 120))
	# "Garagem" fica por baixo à esquerda do botão "Começar!" (mais pequeno, um pouco mais baixo).
	var gb := U.button(U.t("GARAGEM", "GARAGE"), Color(0.08, 0.20, 0.50, 0.95), Vector2(300, 90), 36, func() -> void: _save(); Game.go_garage())
	_root.add_child(gb)
	U.place(gb, Vector2(1, 1), Vector2(10 + 560 + 24, 10), Vector2(300, 90))
	var back := U.button(U.t("VOLTAR", "BACK"), U.GRAY, Vector2(320, 100), 42, func() -> void: _save(); Game.go_menu())
	_root.add_child(back)
	U.place(back, Vector2(0, 1), Vector2(20, 10), Vector2(320, 100))


func _row(text: String, x: float, y: float, minus: Callable, plus: Callable) -> Label:
	var l := U.label(text, 40, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT)
	_root.add_child(l)
	U.place(l, Vector2(0, 0), Vector2(x, y), Vector2(700, 56))
	var b1 := U.button("−", U.BLUE, Vector2(110, 80), 56, minus)
	_root.add_child(b1)
	U.place(b1, Vector2(0, 0), Vector2(x, y + 56), Vector2(110, 80))
	var v := U.label("", 46, Color(1, 0.85, 0.2), HORIZONTAL_ALIGNMENT_CENTER)
	_root.add_child(v)
	U.place(v, Vector2(0, 0), Vector2(x + 120, y + 56), Vector2(420, 80))
	var b2 := U.button("+", U.BLUE, Vector2(110, 80), 56, plus)
	_root.add_child(b2)
	U.place(b2, Vector2(0, 0), Vector2(x + 550, y + 56), Vector2(110, 80))
	return v


func _move_track(d: int) -> void:
	_track_i = (_track_i + d + TrackData.ALL.size()) % TrackData.ALL.size()
	_refresh()


func _refresh() -> void:
	var td: Dictionary = TrackData.ALL[_track_i]
	_name_l.text = TrackData.tname(td)
	_laps_l.text = str(_laps)
	_opp_l.text = str(_opp)
	_diff_l.text = [U.t("Fácil", "Easy"), U.t("Normal", "Normal"), U.t("Difícil", "Hard"), U.t("Super Difícil", "Super Hard")][_diff]
	var def: Dictionary = CarData.by_id(str(Game.save["selected"]))
	_car_l.text = U.t("O teu carro: ", "Your car: ") + str(def["name"])
	var c := Circuit.new()
	c.def = td
	c._centerline()
	_info_l.text = "%s  ·  %.1f km  ·  %d/%d" % [TrackData.level_name(td), c.length / 1000.0, _track_i + 1, TrackData.ALL.size()]
	var lo := Vector2(1e9, 1e9)
	var hi := Vector2(-1e9, -1e9)
	for i in range(0, c.N, 4):
		lo.x = minf(lo.x, c.P[i].x)
		lo.y = minf(lo.y, c.P[i].z)
		hi.x = maxf(hi.x, c.P[i].x)
		hi.y = maxf(hi.y, c.P[i].z)
	var span: float = maxf(hi.x - lo.x, hi.y - lo.y)
	var off := Vector2((span - (hi.x - lo.x)) * 0.5, (span - (hi.y - lo.y)) * 0.5)
	_prev.pts = PackedVector2Array()
	for i in range(0, c.N, 4):
		_prev.pts.append((Vector2(c.P[i].x, c.P[i].z) - lo + off) / span * 0.84 * 640.0 + Vector2(52, 52))
	_prev.col = (td["horizon"] as Color).lerp(Color(1, 1, 1), 0.5)
	_prev.queue_redraw()
	c.free()


func _save() -> void:
	Game.save["setup"] = {"track": _track_i, "laps": _laps, "opp": _opp, "diff": _diff}
	Game.save_game()


func _start() -> void:
	_save()
	Game.go_race({"mode": "quick", "track": TrackData.ALL[_track_i]["id"], "laps": _laps, "opponents": _opp, "difficulty": _diff})
