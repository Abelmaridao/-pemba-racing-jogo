extends Node
## NetworkManager (autoload "Net")
## Rede local SEM Internet: um telemóvel cria a sala (servidor ENet) e os outros entram pelo endereço IP (Wi-Fi ou hotspot).
## Também anuncia a sala por "broadcast" UDP para os outros a verem na lista sem digitar o IP (se o router permitir).

const PORT := 24680
const DISC_PORT := 24681
const MAX_PLAYERS := 8

signal rooms_changed
signal connected_ok
signal connect_failed
signal server_lost

var hosting: bool = false
var joined: bool = false
var rooms: Dictionary = {}          # ip -> {name, players, t}
var _announcer: PacketPeerUDP = null
var _listener: PacketPeerUDP = null
var _ann_t: float = 0.0
var host_name: String = ""


func _ready() -> void:
	multiplayer.connected_to_server.connect(func() -> void:
		joined = true
		connected_ok.emit())
	multiplayer.connection_failed.connect(func() -> void:
		leave()
		connect_failed.emit())
	multiplayer.server_disconnected.connect(func() -> void:
		var was: bool = joined
		leave()
		if was:
			server_lost.emit())


func has_peer() -> bool:
	return multiplayer.multiplayer_peer != null and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer)


func host(name: String) -> int:
	leave()
	var peer := ENetMultiplayerPeer.new()
	var err: int = peer.create_server(PORT, MAX_PLAYERS - 1)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	hosting = true
	host_name = name
	_announcer = PacketPeerUDP.new()
	_announcer.set_broadcast_enabled(true)
	_announcer.set_dest_address("255.255.255.255", DISC_PORT)
	return OK


func join(ip: String) -> int:
	leave()
	var peer := ENetMultiplayerPeer.new()
	var err: int = peer.create_client(ip.strip_edges(), PORT)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	return OK


func leave() -> void:
	hosting = false
	joined = false
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
		multiplayer.multiplayer_peer = null
	if _announcer != null:
		_announcer.close()
		_announcer = null


func start_scan() -> void:
	stop_scan()
	rooms.clear()
	_listener = PacketPeerUDP.new()
	if _listener.bind(DISC_PORT) != OK:
		_listener = null


func stop_scan() -> void:
	if _listener != null:
		_listener.close()
		_listener = null


## Endereços IPv4 deste telemóvel na rede local (o que os outros têm de escrever).
func local_ips() -> Array:
	var out: Array = []
	for a in IP.get_local_addresses():
		var s: String = str(a)
		if s.count(".") != 3 or s.begins_with("127.") or s.begins_with("169.254."):
			continue
		out.append(s)
	out.sort_custom(func(x: String, y: String) -> bool:
		return _rank_ip(x) < _rank_ip(y))
	return out


func _rank_ip(s: String) -> int:
	if s.begins_with("192.168."):
		return 0
	if s.begins_with("10."):
		return 1
	if s.begins_with("172."):
		return 2
	return 3


func _process(delta: float) -> void:
	if hosting and _announcer != null:
		_ann_t += delta
		if _ann_t >= 1.0:
			_ann_t = 0.0
			var count: int = multiplayer.get_peers().size() + 1
			_announcer.put_packet(("PEMBA|%s|%d|%d" % [host_name, count, MAX_PLAYERS]).to_utf8_buffer())
	if _listener != null:
		var changed: bool = false
		while _listener.get_available_packet_count() > 0:
			var pkt: PackedByteArray = _listener.get_packet()
			var ip: String = _listener.get_packet_ip()
			var parts: PackedStringArray = pkt.get_string_from_utf8().split("|")
			if parts.size() >= 4 and parts[0] == "PEMBA":
				rooms[ip] = {"name": parts[1], "players": int(parts[2]), "max": int(parts[3]), "t": Time.get_ticks_msec()}
				changed = true
		var now: int = Time.get_ticks_msec()
		for k in rooms.keys():
			if now - int(rooms[k]["t"]) > 4000:
				rooms.erase(k)
				changed = true
		if changed:
			rooms_changed.emit()
