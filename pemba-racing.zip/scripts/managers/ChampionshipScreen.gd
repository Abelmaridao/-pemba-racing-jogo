class_name ChampionshipScreen
extends Node
## Ecrã do campeonato: etapas, classificação geral e botão para a próxima corrida.

var _ui: CanvasLayer
var _root: Control


func _ready() -> void:
	_build()


func _build() -> void:
	_ui = CanvasLayer.new()
	add_child(_ui)
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.04, 0.10)
	_ui.add_child(bg)
	U.full(bg)
	var host := Control.new()
	host.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui.add_child(host)
	U.full(host)
	_root = U.safe_root(host)
	var title := U.label(U.t("CAMPEONATO", "CHAMPIONSHIP"), 78, Color.WHITE)
	_root.add_child(title)
	U.place(title, Vector2(0, 0), Vector2(20, 4), Vector2(1200, 100))
	if not Championship.active():
		_build_start()
	else:
		_build_status()
	var back := U.button(U.t("VOLTAR", "BACK"), U.GRAY, Vector2(320, 100), 42, func() -> void: Game.go_menu())
	_root.add_child(back)
	U.place(back, Vector2(0, 1), Vector2(20, 10), Vector2(320, 100))


func _build_start() -> void:
	var t := Label.new()
	t.text = U.t("5 corridas, uma em cada pista, contra 7 adversários.\nGanhas pontos por posição (25, 18, 15, 12, 10, 8, 6, 4).\nNo fim recebes um prémio em moedas conforme a classificação final.\n\nEscolhe a dificuldade para começar:",
		"5 races, one on each track, against 7 opponents.\nYou earn points per position (25, 18, 15, 12, 10, 8, 6, 4).\nAt the end you get a coin prize based on the final standings.\n\nPick a difficulty to begin:")
	t.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	t.add_theme_font_size_override("font_size", 40)
	_root.add_child(t)
	U.place(t, Vector2(0, 0), Vector2(30, 150), Vector2(1500, 330))
	var names := [U.t("FÁCIL", "EASY"), U.t("NORMAL", "NORMAL"), U.t("DIFÍCIL", "HARD")]
	for i in 3:
		var b := U.button(names[i], [Color(0.1, 0.5, 0.2, 0.95), U.BLUE, U.RED][i], Vector2(420, 120), 52, func() -> void:
			Championship.start_new(i)
			Game.go_champ())
		_root.add_child(b)
		U.place(b, Vector2(0, 0), Vector2(30 + i * 460, 520), Vector2(420, 120))


func _build_status() -> void:
	var st: Dictionary = Championship.state()
	var ri: int = Championship.round_index()
	# etapas
	for i in Championship.rounds():
		var td: Dictionary = TrackData.ALL[i]
		var p := Panel.new()
		var col := Color(0.1, 0.45, 0.2, 0.8) if i < ri else (Color(0.9, 0.13, 0.17, 0.8) if i == ri else Color(1, 1, 1, 0.08))
		p.add_theme_stylebox_override("panel", U.box(col, 14))
		_root.add_child(p)
		U.place(p, Vector2(0, 0), Vector2(20, 130 + i * 96), Vector2(760, 84))
		var l := U.label("%d.  %s%s" % [i + 1, TrackData.tname(td), "  ✓" if i < ri else ""], 36, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT, false)
		p.add_child(l)
		U.place(l, Vector2(0, 0.5), Vector2(20, 0), Vector2(720, 70))
	# classificação
	var panel := U.panel(Color(0.04, 0.08, 0.18, 0.92), 20)
	_root.add_child(panel)
	U.place(panel, Vector2(1, 0), Vector2(20, 130), Vector2(900, 700))
	var h := U.label(U.t("CLASSIFICAÇÃO GERAL", "OVERALL STANDINGS"), 40, Color(1, 0.85, 0.2), HORIZONTAL_ALIGNMENT_CENTER)
	panel.add_child(h)
	U.place(h, Vector2(0.5, 0), Vector2(0, 10), Vector2(860, 60))
	var s: Array = Championship.standings()
	for i in s.size():
		var me: bool = s[i]["name"] == "TU"
		var row := Panel.new()
		row.add_theme_stylebox_override("panel", U.box(Color(0.9, 0.13, 0.17, 0.5) if me else Color(1, 1, 1, 0.06), 12))
		panel.add_child(row)
		U.place(row, Vector2(0.5, 0), Vector2(0, 80 + i * 76), Vector2(860, 68))
		var a := U.label("%d.  %s" % [i + 1, s[i]["name"]], 34, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT, false)
		row.add_child(a)
		U.place(a, Vector2(0, 0.5), Vector2(20, 0), Vector2(560, 60))
		var b := U.label(str(s[i]["pts"]) + " pts", 34, Color(1, 0.9, 0.5), HORIZONTAL_ALIGNMENT_RIGHT, false)
		row.add_child(b)
		U.place(b, Vector2(1, 0.5), Vector2(20, 0), Vector2(260, 60))
	if Championship.finished():
		var pos: int = Championship.position_of("TU")
		var msg: String = U.t("CAMPEONATO TERMINADO! Ficaste em %dº lugar. Prémio: +%d moedas" % [pos, int(st.get("prize", 0))],
			"CHAMPIONSHIP OVER! You finished %d. Prize: +%d coins" % [pos, int(st.get("prize", 0))])
		var m := U.label(msg, 40, Color(1, 0.85, 0.2), HORIZONTAL_ALIGNMENT_LEFT, true)
		m.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_root.add_child(m)
		U.place(m, Vector2(0, 0), Vector2(20, 640), Vector2(800, 150))
		var nb := U.button(U.t("NOVO CAMPEONATO", "NEW CHAMPIONSHIP"), U.RED, Vector2(560, 110), 46, func() -> void:
			Championship.reset()
			Game.go_champ())
		_root.add_child(nb)
		U.place(nb, Vector2(1, 1), Vector2(10, 10), Vector2(560, 110))
	else:
		var nb2 := U.button(U.t("CORRIDA %d" % (ri + 1), "RACE %d" % (ri + 1)), U.RED, Vector2(560, 110), 50, func() -> void: Game.go_race(Championship.next_cfg()))
		_root.add_child(nb2)
		U.place(nb2, Vector2(1, 1), Vector2(10, 10), Vector2(560, 110))
		var rb := U.button(U.t("REINICIAR", "RESET"), Color(0.45, 0.07, 0.10, 0.95), Vector2(300, 90), 36, func() -> void:
			Championship.reset()
			Game.go_champ())
		_root.add_child(rb)
		U.place(rb, Vector2(1, 1), Vector2(600, 20), Vector2(300, 90))
