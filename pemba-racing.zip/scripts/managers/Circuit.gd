class_name Circuit
extends Node3D
## Circuit: constrói UMA pista com voltas a partir de TrackData (estrada, bermas, barreiras com colisão, linha de partida,
## cenário) e responde às perguntas da corrida: onde está cada carro na pista, está fora da estrada, onde fica cada lugar da grelha.
## Tudo é feito com poucas malhas (leve para telemóveis fracos). A estrada é plana; a colisão do chão é um plano único.

const DS := 5.0           # distância (m) entre pontos da linha central

var def: Dictionary
var P := PackedVector3Array()   # linha central
var T := PackedVector3Array()   # direção (tangente)
var R := PackedVector3Array()   # direita
var K := PackedFloat32Array()   # curvatura (1/m)
var N: int = 0
var length: float = 0.0
var hw: float = 8.0             # meia-largura da estrada
var wall_off: float = 15.0      # distância das barreiras à linha central
var ds: float = DS


func build(d: Dictionary) -> void:
	def = d
	hw = float(d["width"]) * 0.5
	wall_off = hw + 7.0
	_centerline()
	_ground()
	_road()
	_walls()
	_props()


# ---------- Linha central ----------
static func _cr(p0: Vector2, p1: Vector2, p2: Vector2, p3: Vector2, t: float) -> Vector2:
	var t2: float = t * t
	var t3: float = t2 * t
	return 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2 + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3)


func _centerline() -> void:
	var n: int = 28
	var base: float = float(def["base"])
	var sx: float = float(def["sx"])
	var sz: float = float(def["sz"])
	var ctrl: Array = []
	for i in n:
		var a: float = TAU * i / n
		var r: float = 1.0
		for h in def["shape"]:
			r += float(h[1]) * sin(float(h[0]) * a + float(h[2]))
		ctrl.append(Vector2(cos(a) * base * r * sx, sin(a) * base * r * sz))
	var dense: Array = []
	for i in n:
		for s in 20:
			dense.append(_cr(ctrl[(i - 1 + n) % n], ctrl[i], ctrl[(i + 1) % n], ctrl[(i + 2) % n], s / 20.0))
	# comprimento total e reamostragem uniforme
	var total: float = 0.0
	for i in dense.size():
		total += (dense[i] as Vector2).distance_to(dense[(i + 1) % dense.size()])
	N = int(round(total / DS))
	ds = total / N
	length = total
	var acc: Array = [0.0]
	for i in dense.size():
		acc.append(acc[i] + (dense[i] as Vector2).distance_to(dense[(i + 1) % dense.size()]))
	var j: int = 0
	P.resize(N)
	for i in N:
		var target: float = i * ds
		while j < dense.size() - 1 and float(acc[j + 1]) < target:
			j += 1
		var seg: float = float(acc[j + 1]) - float(acc[j])
		var f: float = (target - float(acc[j])) / maxf(seg, 0.0001)
		var a2: Vector2 = dense[j]
		var b2: Vector2 = dense[(j + 1) % dense.size()]
		var p2: Vector2 = a2.lerp(b2, clampf(f, 0.0, 1.0))
		P[i] = Vector3(p2.x, 0.0, p2.y)
	T.resize(N)
	R.resize(N)
	K.resize(N)
	for i in N:
		var t: Vector3 = (P[(i + 1) % N] - P[(i - 1 + N) % N]).normalized()
		T[i] = t
		R[i] = t.cross(Vector3.UP).normalized()
	for i in N:
		var t0: Vector3 = T[(i - 2 + N) % N]
		var t1: Vector3 = T[(i + 2) % N]
		K[i] = t0.angle_to(t1) / (4.0 * ds)


# ---------- Malhas ----------
func _mat_node(parent: Node, kit: MeshKit, emissive: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = kit.commit()
	mi.material_override = MeshKit.vc_material(emissive)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


func _ground() -> void:
	var body := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(5000, 2, 5000)
	cs.shape = shape
	cs.position = Vector3(0, -1.0, 0)
	body.add_child(cs)
	add_child(body)
	var mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(5000, 5000)
	mi.mesh = pm
	var m := StandardMaterial3D.new()
	m.albedo_color = def["ground"]
	m.roughness = 1.0
	if Settings.quality == 0:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
	mi.material_override = m
	mi.position = Vector3(0, -0.02, 0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


func _road() -> void:
	var k := MeshKit.new()
	var road: Color = def["road"]
	var up := Vector3.UP
	for i in N:
		var j: int = (i + 1) % N
		var shade: float = 1.0 if (i / 3) % 2 == 0 else 0.90
		var rc := Color(road.r * shade, road.g * shade, road.b * shade)
		var l0: Vector3 = P[i] - R[i] * hw + up * 0.03
		var r0: Vector3 = P[i] + R[i] * hw + up * 0.03
		var l1: Vector3 = P[j] - R[j] * hw + up * 0.03
		var r1: Vector3 = P[j] + R[j] * hw + up * 0.03
		var below: Vector3 = (l0 + r1) * 0.5 - up
		k.quad(l0, r0, r1, l1, rc, below)
		# bermas (vermelho/branco)
		var kc: Color = Color(0.85, 0.1, 0.1) if (i / 2) % 2 == 0 else Color(0.95, 0.95, 0.95)
		for s in [-1.0, 1.0]:
			var a0: Vector3 = P[i] + R[i] * s * hw + up * 0.035
			var b0: Vector3 = P[i] + R[i] * s * (hw + 1.5) + up * 0.035
			var a1: Vector3 = P[j] + R[j] * s * hw + up * 0.035
			var b1: Vector3 = P[j] + R[j] * s * (hw + 1.5) + up * 0.035
			k.quad(a0, b0, b1, a1, kc, (a0 + b1) * 0.5 - up)
		# linha central tracejada
		if i % 4 < 2:
			var c0: Vector3 = P[i] + up * 0.04
			var c1: Vector3 = P[j] + up * 0.04
			var w0: Vector3 = R[i] * 0.18
			var w1: Vector3 = R[j] * 0.18
			k.quad(c0 - w0, c0 + w0, c1 + w1, c1 - w1, Color(0.9, 0.9, 0.9), (c0 + c1) * 0.5 - up)
	# linha de partida/chegada axadrezada (entre os pontos 0 e 1)
	var cells: int = 10
	for row in 2:
		for c in cells:
			var f0: float = -1.0 + 2.0 * c / cells
			var f1: float = -1.0 + 2.0 * (c + 1) / cells
			var za: Vector3 = P[0] + T[0] * (row * 1.2 - 1.2)
			var zb: Vector3 = P[0] + T[0] * (row * 1.2)
			var col: Color = Color(1, 1, 1) if (c + row) % 2 == 0 else Color(0.05, 0.05, 0.05)
			var a: Vector3 = za + R[0] * hw * f0 + up * 0.05
			var b: Vector3 = za + R[0] * hw * f1 + up * 0.05
			var cc: Vector3 = zb + R[0] * hw * f1 + up * 0.05
			var dd: Vector3 = zb + R[0] * hw * f0 + up * 0.05
			k.quad(a, b, cc, dd, col, (a + cc) * 0.5 - up)
	_mat_node(self, k)


func _walls() -> void:
	var k := MeshKit.new()
	var h: float = 1.3
	var up := Vector3.UP
	for i in N:
		var j: int = (i + 1) % N
		var col: Color = Color(0.88, 0.12, 0.12) if (i / 4) % 2 == 0 else Color(0.95, 0.95, 0.95)
		for s in [-1.0, 1.0]:
			var a: Vector3 = P[i] + R[i] * s * wall_off
			var b: Vector3 = P[j] + R[j] * s * wall_off
			var road_side: Vector3 = (a + b) * 0.5 - R[i] * s * 3.0 + up * h * 0.5
			var far_side: Vector3 = (a + b) * 0.5 + R[i] * s * 3.0 + up * h * 0.5
			k.quad(a, b, b + up * h, a + up * h, col, road_side)     # face virada para a pista
			k.quad(a, b, b + up * h, a + up * h, col, far_side)      # face de trás (colisão dos dois lados)
	var mesh: ArrayMesh = k.commit()
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = MeshKit.vc_material(false)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	var body := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var shape: ConcavePolygonShape3D = mesh.create_trimesh_shape()
	shape.backface_collision = true
	cs.shape = shape
	body.add_child(cs)
	var pmat := PhysicsMaterial.new()
	pmat.friction = 0.0
	pmat.bounce = 0.1
	body.physics_material_override = pmat
	add_child(body)


func _props() -> void:
	var kind: String = str(def["props"])
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(str(def["id"]))
	var pk := MeshKit.new()
	var gk := MeshKit.new()
	var count: int = 150 if Settings.quality >= 1 else 90
	if kind == "city":
		count = 70 if Settings.quality >= 1 else 45
	for n in count:
		var i: int = rng.randi_range(0, N - 1)
		var s: float = -1.0 if rng.randf() < 0.5 else 1.0
		var dist: float = wall_off + 9.0 + rng.randf() * (30.0 if kind != "city" else 18.0) + (10.0 if kind == "city" else 0.0)
		var pos: Vector3 = P[i] + R[i] * s * dist
		if _near_track(pos) < wall_off + 6.0:
			continue
		var yaw: float = rng.randf() * TAU
		match kind:
			"trees":
				var th: float = 2.2 + rng.randf() * 1.5
				pk.box(pos + Vector3(0, th * 0.5, 0), Vector3(0.7, th, 0.7), Color(0.38, 0.24, 0.12), Vector3(0, yaw, 0))
				pk.box(pos + Vector3(0, th + 1.3, 0), Vector3(4.2, 2.6, 4.2), Color(0.12, 0.45, 0.14), Vector3(0, yaw, 0))
				pk.box(pos + Vector3(0, th + 3.2, 0), Vector3(2.8, 2.2, 2.8), Color(0.16, 0.55, 0.18), Vector3(0, yaw + 0.5, 0))
			"cacti":
				var ch: float = 3.0 + rng.randf() * 2.5
				pk.box(pos + Vector3(0, ch * 0.5, 0), Vector3(0.9, ch, 0.9), Color(0.20, 0.50, 0.22), Vector3(0, yaw, 0))
				pk.box(pos + Vector3(0.9, ch * 0.6, 0), Vector3(0.6, 0.6, 0.6), Color(0.20, 0.50, 0.22), Vector3(0, yaw, 0))
				pk.box(pos + Vector3(0.9, ch * 0.6 + 0.9, 0), Vector3(0.55, 1.4, 0.55), Color(0.20, 0.50, 0.22), Vector3(0, yaw, 0))
			"pines":
				pk.box(pos + Vector3(0, 0.8, 0), Vector3(0.6, 1.6, 0.6), Color(0.3, 0.2, 0.1), Vector3(0, yaw, 0))
				pk.box(pos + Vector3(0, 2.6, 0), Vector3(4.6, 2.2, 4.6), Color(0.08, 0.30, 0.16), Vector3(0, yaw, 0))
				pk.box(pos + Vector3(0, 4.6, 0), Vector3(3.4, 2.0, 3.4), Color(0.10, 0.36, 0.18), Vector3(0, yaw, 0))
				pk.box(pos + Vector3(0, 6.3, 0), Vector3(2.0, 1.8, 2.0), Color(0.92, 0.95, 1.0), Vector3(0, yaw, 0))
			"rocks":
				var rs: float = 3.0 + rng.randf() * 6.0
				pk.box(pos + Vector3(0, rs * 0.35, 0), Vector3(rs, rs * 0.7, rs * 0.8), Color(0.38, 0.30, 0.26), Vector3(rng.randf() * 0.4, yaw, rng.randf() * 0.4))
			"city":
				var bw: float = 10.0 + rng.randf() * 10.0
				var bh: float = 14.0 + rng.randf() * 46.0
				pk.box(pos + Vector3(0, bh * 0.5, 0), Vector3(bw, bh, bw), Color(0.12 + rng.randf() * 0.08, 0.13 + rng.randf() * 0.08, 0.20 + rng.randf() * 0.10), Vector3(0, yaw, 0))
				for w in 8:
					var wy: float = 3.0 + rng.randf() * (bh - 5.0)
					var face: Vector3 = Vector3(sin(yaw), 0, cos(yaw)) * (bw * 0.5 + 0.05)
					var off: Vector3 = Vector3(cos(yaw), 0, -sin(yaw)) * (rng.randf() - 0.5) * (bw * 0.7)
					gk.box(pos + Vector3(0, wy, 0) + face + off, Vector3(1.6, 1.1, 1.6), Color(1.0, 0.85, 0.45) if rng.randf() < 0.6 else Color(0.4, 0.8, 1.0), Vector3(0, yaw, 0))
	# candeeiros ao longo da pista (cidade)
	if kind == "city":
		for i in range(0, N, 10):
			for s in [-1.0, 1.0]:
				var base: Vector3 = P[i] + R[i] * s * (wall_off + 1.5)
				pk.box(base + Vector3(0, 3.5, 0), Vector3(0.25, 7.0, 0.25), Color(0.2, 0.2, 0.24))
				gk.box(base + Vector3(-R[i].x * s * 0.8, 7.1, -R[i].z * s * 0.8), Vector3(1.4, 0.2, 0.6), Color(1.0, 0.95, 0.7), Vector3(0, atan2(R[i].x, R[i].z), 0))
	if not pk.is_empty():
		_mat_node(self, pk)
	if not gk.is_empty():
		_mat_node(self, gk, true)


func _near_track(p: Vector3) -> float:
	var best: float = 1e12
	for i in range(0, N, 2):
		var d: float = Vector2(P[i].x - p.x, P[i].z - p.z).length_squared()
		if d < best:
			best = d
	return sqrt(best)


# ---------- Consultas para a corrida ----------
## Índice do ponto da linha central mais próximo (procura perto de "hint": rápido e sem saltos).
func nearest(pos: Vector3, hint: int) -> int:
	var best: int = hint
	var bd: float = 1e12
	for o in range(-10, 16):
		var i: int = (hint + o + N * 4) % N
		var dx: float = P[i].x - pos.x
		var dz: float = P[i].z - pos.z
		var d: float = dx * dx + dz * dz
		if d < bd:
			bd = d
			best = i
	return best


func nearest_global(pos: Vector3) -> int:
	var best: int = 0
	var bd: float = 1e12
	for i in N:
		var dx: float = P[i].x - pos.x
		var dz: float = P[i].z - pos.z
		var d: float = dx * dx + dz * dz
		if d < bd:
			bd = d
			best = i
	return best


func lateral(pos: Vector3, idx: int) -> float:
	return (pos - P[idx]).dot(R[idx])


## 1 = na estrada (ou berma), desce até 0 fora dela. Usado pelo CarController.
func surface(pos: Vector3, idx: int) -> float:
	var lat: float = absf(lateral(pos, idx))
	return 1.0 - clampf((lat - (hw + 1.5)) / 2.5, 0.0, 1.0)


## Posição e orientação a "s" metros ao longo da pista (negativo = antes da meta), deslocada "lat" para a direita.
func frame_at(s: float, lat: float) -> Transform3D:
	var f: float = fposmod(s, length) / ds
	var i0: int = int(floor(f)) % N
	var i1: int = (i0 + 1) % N
	var fr: float = f - floor(f)
	var pos: Vector3 = P[i0].lerp(P[i1], fr)
	var t: Vector3 = T[i0].lerp(T[i1], fr).normalized()
	var r: Vector3 = t.cross(Vector3.UP).normalized()
	pos += r * lat + Vector3.UP * 0.25
	var yaw: float = atan2(-t.x, -t.z)
	return Transform3D(Basis(Vector3.UP, yaw), pos)


## Lugar da grelha n (0 = pole): filas de 2, a começar 9 m antes da linha.
func grid_slot(n: int) -> Transform3D:
	var row: int = n / 2
	var left: bool = n % 2 == 0
	return frame_at(-(9.0 + row * 9.0 + (4.0 if not left else 0.0)), (-3.6 if left else 3.6))
