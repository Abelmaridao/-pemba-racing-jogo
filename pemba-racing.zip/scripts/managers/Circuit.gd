class_name Circuit
extends Node3D
## Circuit: constrói UMA pista com voltas a partir de TrackData (estrada, bermas, barreiras com colisão, linha de partida,
## cenário) e responde às perguntas da corrida: onde está cada carro na pista, está fora da estrada, onde fica cada lugar da grelha.
## Tudo é feito com poucas malhas (leve para telemóveis fracos). A estrada é plana; a colisão do chão é um plano único.

const DS := 5.0           # distância (m) entre pontos da linha central

var def: Dictionary
var P := PackedVector3Array()   # linha central
var T := PackedVector3Array()   # direção (tangente)
var R := PackedVector3Array()   # direita
var K := PackedFloat32Array()   # curvatura (1/m)
var N: int = 0
var length: float = 0.0
var hw: float = 8.0             # meia-largura da estrada
var wall_off: float = 15.0      # distância das barreiras à linha central
var ds: float = DS


func build(d: Dictionary) -> void:
	def = d
	hw = float(d["width"]) * 0.5
	wall_off = hw + 7.0
	_centerline()
	_ground()
	_road()
	_walls()
	_props()
	_venue()


# ---------- Linha central ----------
static func _cr(p0: Vector2, p1: Vector2, p2: Vector2, p3: Vector2, t: float) -> Vector2:
	var t2: float = t * t
	var t3: float = t2 * t
	return 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2 + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3)


func _centerline() -> void:
	var n: int = 28
	var base: float = float(def["base"])
	var sx: float = float(def["sx"])
	var sz: float = float(def["sz"])
	var ctrl: Array = []
	for i in n:
		var a: float = TAU * i / n
		var r: float = 1.0
		for h in def["shape"]:
			r += float(h[1]) * sin(float(h[0]) * a + float(h[2]))
		ctrl.append(Vector2(cos(a) * base * r * sx, sin(a) * base * r * sz))
	var dense: Array = []
	for i in n:
		for s in 20:
			dense.append(_cr(ctrl[(i - 1 + n) % n], ctrl[i], ctrl[(i + 1) % n], ctrl[(i + 2) % n], s / 20.0))
	# comprimento total e reamostragem uniforme
	var total: float = 0.0
	for i in dense.size():
		total += (dense[i] as Vector2).distance_to(dense[(i + 1) % dense.size()])
	N = int(round(total / DS))
	ds = total / N
	length = total
	var acc: Array = [0.0]
	for i in dense.size():
		acc.append(acc[i] + (dense[i] as Vector2).distance_to(dense[(i + 1) % dense.size()]))
	var j: int = 0
	P.resize(N)
	for i in N:
		var target: float = i * ds
		while j < dense.size() - 1 and float(acc[j + 1]) < target:
			j += 1
		var seg: float = float(acc[j + 1]) - float(acc[j])
		var f: float = (target - float(acc[j])) / maxf(seg, 0.0001)
		var a2: Vector2 = dense[j]
		var b2: Vector2 = dense[(j + 1) % dense.size()]
		var p2: Vector2 = a2.lerp(b2, clampf(f, 0.0, 1.0))
		P[i] = Vector3(p2.x, 0.0, p2.y)
	T.resize(N)
	R.resize(N)
	K.resize(N)
	for i in N:
		var t: Vector3 = (P[(i + 1) % N] - P[(i - 1 + N) % N]).normalized()
		T[i] = t
		R[i] = t.cross(Vector3.UP).normalized()
	for i in N:
		var t0: Vector3 = T[(i - 2 + N) % N]
		var t1: Vector3 = T[(i + 2) % N]
		K[i] = t0.angle_to(t1) / (4.0 * ds)


# ---------- Malhas ----------
func _mat_node(parent: Node, kit: MeshKit, emissive: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = kit.commit()
	mi.material_override = MeshKit.vc_material(emissive)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


func _ground() -> void:
	var body := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(5000, 2, 5000)
	cs.shape = shape
	cs.position = Vector3(0, -1.0, 0)
	body.add_child(cs)
	add_child(body)
	var mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(5000, 5000)
	mi.mesh = pm
	var m := StandardMaterial3D.new()
	m.albedo_color = def["ground"]
	m.roughness = 1.0
	if Settings.quality == 0:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
	mi.material_override = m
	mi.position = Vector3(0, -0.02, 0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


func _road() -> void:
	var k := MeshKit.new()
	var road: Color = def["road"]
	var up := Vector3.UP
	for i in N:
		var j: int = (i + 1) % N
		var shade: float = 1.0 if (i / 3) % 2 == 0 else 0.90
		var rc := Color(road.r * shade, road.g * shade, road.b * shade)
		var l0: Vector3 = P[i] - R[i] * hw + up * 0.03
		var r0: Vector3 = P[i] + R[i] * hw + up * 0.03
		var l1: Vector3 = P[j] - R[j] * hw + up * 0.03
		var r1: Vector3 = P[j] + R[j] * hw + up * 0.03
		var below: Vector3 = (l0 + r1) * 0.5 - up
		k.quad(l0, r0, r1, l1, rc, below)
		# bermas (vermelho/branco)
		var kc: Color = Color(0.85, 0.1, 0.1) if (i / 2) % 2 == 0 else Color(0.95, 0.95, 0.95)
		for s in [-1.0, 1.0]:
			var a0: Vector3 = P[i] + R[i] * s * hw + up * 0.035
			var b0: Vector3 = P[i] + R[i] * s * (hw + 1.5) + up * 0.035
			var a1: Vector3 = P[j] + R[j] * s * hw + up * 0.035
			var b1: Vector3 = P[j] + R[j] * s * (hw + 1.5) + up * 0.035
			k.quad(a0, b0, b1, a1, kc, (a0 + b1) * 0.5 - up)
		# linha central tracejada
		if i % 4 < 2:
			var c0: Vector3 = P[i] + up * 0.04
			var c1: Vector3 = P[j] + up * 0.04
			var w0: Vector3 = R[i] * 0.18
			var w1: Vector3 = R[j] * 0.18
			k.quad(c0 - w0, c0 + w0, c1 + w1, c1 - w1, Color(0.9, 0.9, 0.9), (c0 + c1) * 0.5 - up)
	# linha de partida/chegada axadrezada (entre os pontos 0 e 1)
	var cells: int = 10
	for row in 2:
		for c in cells:
			var f0: float = -1.0 + 2.0 * c / cells
			var f1: float = -1.0 + 2.0 * (c + 1) / cells
			var za: Vector3 = P[0] + T[0] * (row * 1.2 - 1.2)
			var zb: Vector3 = P[0] + T[0] * (row * 1.2)
			var col: Color = Color(1, 1, 1) if (c + row) % 2 == 0 else Color(0.05, 0.05, 0.05)
			var a: Vector3 = za + R[0] * hw * f0 + up * 0.05
			var b: Vector3 = za + R[0] * hw * f1 + up * 0.05
			var cc: Vector3 = zb + R[0] * hw * f1 + up * 0.05
			var dd: Vector3 = zb + R[0] * hw * f0 + up * 0.05
			k.quad(a, b, cc, dd, col, (a + cc) * 0.5 - up)
	_mat_node(self, k)


func _walls() -> void:
	var k := MeshKit.new()
	var h: float = 1.3
	var up := Vector3.UP
	for i in N:
		var j: int = (i + 1) % N
		var col: Color = Color(0.88, 0.12, 0.12) if (i / 4) % 2 == 0 else Color(0.95, 0.95, 0.95)
		for s in [-1.0, 1.0]:
			var a: Vector3 = P[i] + R[i] * s * wall_off
			var b: Vector3 = P[j] + R[j] * s * wall_off
			var road_side: Vector3 = (a + b) * 0.5 - R[i] * s * 3.0 + up * h * 0.5
			var far_side: Vector3 = (a + b) * 0.5 + R[i] * s * 3.0 + up * h * 0.5
			k.quad(a, b, b + up * h, a + up * h, col, road_side)     # face virada para a pista
			k.quad(a, b, b + up * h, a + up * h, col, far_side)      # face de trás (colisão dos dois lados)
	var mesh: ArrayMesh = k.commit()
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = MeshKit.vc_material(false)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	var body := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var shape: ConcavePolygonShape3D = mesh.create_trimesh_shape()
	shape.backface_collision = true
	cs.shape = shape
	body.add_child(cs)
	var pmat := PhysicsMaterial.new()
	pmat.friction = 0.0
	pmat.bounce = 0.1
	body.physics_material_override = pmat
	add_child(body)


func _props() -> void:
	var kind: String = str(def["props"])
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(str(def["id"]))
	var pk := MeshKit.new()
	var gk := MeshKit.new()
	var count: int = 150 if Settings.quality >= 1 else 90
	if kind == "city":
		count = 70 if Settings.quality >= 1 else 45
	for n in count:
		var i: int = rng.randi_range(0, N - 1)
		var s: float = -1.0 if rng.randf() < 0.5 else 1.0
		var dist: float = wall_off + 9.0 + rng.randf() * (30.0 if kind != "city" else 18.0) + (10.0 if kind == "city" else 0.0)
		var pos: Vector3 = P[i] + R[i] * s * dist
		if _near_track(pos) < wall_off + 6.0:
			continue
		var yaw: float = rng.randf() * TAU
		match kind:
			"trees":
				_palm(pk, pos, rng)
			"trees_old":
				var th: float = 2.2 + rng.randf() * 1.5
				pk.box(pos + Vector3(0, th * 0.5, 0), Vector3(0.7, th, 0.7), Color(0.38, 0.24, 0.12), Vector3(0, yaw, 0))
				pk.box(pos + Vector3(0, th + 1.3, 0), Vector3(4.2, 2.6, 4.2), Color(0.12, 0.45, 0.14), Vector3(0, yaw, 0))
				pk.box(pos + Vector3(0, th + 3.2, 0), Vector3(2.8, 2.2, 2.8), Color(0.16, 0.55, 0.18), Vector3(0, yaw + 0.5, 0))
			"cacti":
				var ch: float = 3.0 + rng.randf() * 2.5
				pk.frustum(pos, 0.5, 0.45, ch, Color(0.20, 0.50, 0.22), 7)
				pk.ellipsoid(pos + Vector3(0, ch, 0), Vector3(0.45, 0.45, 0.45), Color(0.24, 0.56, 0.26), 3, 7)
				pk.frustum(pos + Vector3(0.45, ch * 0.55, 0), 0.28, 0.25, 1.4, Color(0.20, 0.50, 0.22), 6, Vector3(0, 0, -1.2))
				pk.frustum(pos + Vector3(1.3, ch * 0.55 + 0.1, 0), 0.26, 0.22, 1.2, Color(0.20, 0.50, 0.22), 6)
			"pines":
				pk.frustum(pos, 0.35, 0.28, 1.6, Color(0.3, 0.2, 0.1), 6)
				pk.frustum(pos + Vector3(0, 1.2, 0), 2.6, 0.0, 3.2, Color(0.08, 0.30, 0.16), 8)
				pk.frustum(pos + Vector3(0, 3.2, 0), 2.0, 0.0, 3.0, Color(0.10, 0.36, 0.18), 8)
				pk.frustum(pos + Vector3(0, 5.0, 0), 1.3, 0.0, 2.6, Color(0.92, 0.95, 1.0), 8)
			"rocks":
				var rs: float = 3.0 + rng.randf() * 6.0
				pk.ellipsoid(pos + Vector3(0, rs * 0.3, 0), Vector3(rs * 0.6, rs * 0.42, rs * 0.5), Color(0.38, 0.30, 0.26), 4, 7, Vector3(rng.randf() * 0.3, yaw, rng.randf() * 0.3))
			"city":
				var bw: float = 10.0 + rng.randf() * 10.0
				var bh: float = 14.0 + rng.randf() * 46.0
				pk.box(pos + Vector3(0, bh * 0.5, 0), Vector3(bw, bh, bw), Color(0.12 + rng.randf() * 0.08, 0.13 + rng.randf() * 0.08, 0.20 + rng.randf() * 0.10), Vector3(0, yaw, 0))
				for w in 8:
					var wy: float = 3.0 + rng.randf() * (bh - 5.0)
					var face: Vector3 = Vector3(sin(yaw), 0, cos(yaw)) * (bw * 0.5 + 0.05)
					var off: Vector3 = Vector3(cos(yaw), 0, -sin(yaw)) * (rng.randf() - 0.5) * (bw * 0.7)
					gk.box(pos + Vector3(0, wy, 0) + face + off, Vector3(1.6, 1.1, 1.6), Color(1.0, 0.85, 0.45) if rng.randf() < 0.6 else Color(0.4, 0.8, 1.0), Vector3(0, yaw, 0))
	# candeeiros ao longo da pista (cidade)
	if kind == "city":
		for i in range(0, N, 10):
			for s in [-1.0, 1.0]:
				var base: Vector3 = P[i] + R[i] * s * (wall_off + 1.5)
				pk.box(base + Vector3(0, 3.5, 0), Vector3(0.25, 7.0, 0.25), Color(0.2, 0.2, 0.24))
				gk.box(base + Vector3(-R[i].x * s * 0.8, 7.1, -R[i].z * s * 0.8), Vector3(1.4, 0.2, 0.6), Color(1.0, 0.95, 0.7), Vector3(0, atan2(R[i].x, R[i].z), 0))
	if not pk.is_empty():
		_mat_node(self, pk)
	if not gk.is_empty():
		_mat_node(self, gk, true)


func _near_track(p: Vector3) -> float:
	var best: float = 1e12
	for i in range(0, N, 2):
		var d: float = Vector2(P[i].x - p.x, P[i].z - p.z).length_squared()
		if d < best:
			best = d
	return sqrt(best)


# ---------- Consultas para a corrida ----------
## Índice do ponto da linha central mais próximo (procura perto de "hint": rápido e sem saltos).
func nearest(pos: Vector3, hint: int) -> int:
	var best: int = hint
	var bd: float = 1e12
	for o in range(-10, 16):
		var i: int = (hint + o + N * 4) % N
		var dx: float = P[i].x - pos.x
		var dz: float = P[i].z - pos.z
		var d: float = dx * dx + dz * dz
		if d < bd:
			bd = d
			best = i
	return best


func nearest_global(pos: Vector3) -> int:
	var best: int = 0
	var bd: float = 1e12
	for i in N:
		var dx: float = P[i].x - pos.x
		var dz: float = P[i].z - pos.z
		var d: float = dx * dx + dz * dz
		if d < bd:
			bd = d
			best = i
	return best


func lateral(pos: Vector3, idx: int) -> float:
	return (pos - P[idx]).dot(R[idx])


## 1 = na estrada (ou berma), desce até 0 fora dela. Usado pelo CarController.
func surface(pos: Vector3, idx: int) -> float:
	var lat: float = absf(lateral(pos, idx))
	return 1.0 - clampf((lat - (hw + 1.5)) / 2.5, 0.0, 1.0)


## Posição e orientação a "s" metros ao longo da pista (negativo = antes da meta), deslocada "lat" para a direita.
func frame_at(s: float, lat: float) -> Transform3D:
	var f: float = fposmod(s, length) / ds
	var i0: int = int(floor(f)) % N
	var i1: int = (i0 + 1) % N
	var fr: float = f - floor(f)
	var pos: Vector3 = P[i0].lerp(P[i1], fr)
	var t: Vector3 = T[i0].lerp(T[i1], fr).normalized()
	var r: Vector3 = t.cross(Vector3.UP).normalized()
	pos += r * lat + Vector3.UP * 0.02
	var yaw: float = atan2(-t.x, -t.z)
	return Transform3D(Basis(Vector3.UP, yaw), pos)


## Lugar da grelha n (0 = pole): filas de 2, a começar 9 m antes da linha.
func grid_slot(n: int) -> Transform3D:
	var row: int = n / 2
	var left: bool = n % 2 == 0
	return frame_at(-(9.0 + row * 9.0 + (4.0 if not left else 0.0)), (-3.6 if left else 3.6))


# ---------- Ambiente do circuito (pórtico, bancadas, torre, pneus, painéis, montanhas, nuvens) ----------
func _basis_at(i: int) -> Basis:
	var t: Vector3 = T[i]
	return Basis(Vector3.UP, atan2(-t.x, -t.z))


func _palm(k: MeshKit, pos: Vector3, rng: RandomNumberGenerator) -> void:
	var h: float = 7.0 + rng.randf() * 4.0
	var lean: float = rng.randf() * TAU
	var cur: Vector3 = pos
	var segs: int = 5
	for j in segs:
		var f: float = float(j) / segs
		var seg_h: float = h / segs
		k.frustum(cur, 0.42 - f * 0.18, 0.42 - (f + 1.0 / segs) * 0.18, seg_h * 1.05, Color(0.55, 0.40, 0.22).lerp(Color(0.42, 0.30, 0.16), f), 7)
		cur += Vector3(sin(lean) * 0.28, seg_h, cos(lean) * 0.28)
	for j in 8:
		var an: float = TAU * j / 8.0 + rng.randf() * 0.25
		var dir := Vector3(sin(an), 0, cos(an))
		k.ellipsoid(cur + dir * 1.7 + Vector3(0, -0.5, 0), Vector3(0.55, 0.14, 1.9), Color(0.12, 0.58, 0.16) if j % 2 == 0 else Color(0.20, 0.70, 0.22), 3, 6, Vector3(0.45, an, 0))
	k.ellipsoid(cur + Vector3(0, 0.2, 0), Vector3(0.5, 0.5, 0.5), Color(0.45, 0.30, 0.12), 3, 6)


func _venue() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(str(def["id"])) + 7
	var vk := MeshKit.new()    # peças com cor
	var gk := MeshKit.new()    # peças luminosas
	var night: bool = bool(def.get("night", false))
	# --- pórtico de partida com painel axadrezado e semáforo ---
	var b0: Basis = _basis_at(0)
	var c0: Vector3 = P[0]
	var gx: float = hw + 2.6
	for sgn in [-1.0, 1.0]:
		var base: Vector3 = c0 + b0 * Vector3(sgn * gx, 0, 0)
		for lvl in 8:
			vk.box(base + Vector3(0, 0.9 + lvl * 1.7, 0), Vector3(1.6, 0.25, 1.6), Color(0.10, 0.10, 0.12), b0.get_euler())
		for cx in [-0.7, 0.7]:
			for cz in [-0.7, 0.7]:
				vk.frustum(base + b0 * Vector3(cx, 0, cz), 0.12, 0.1, 14.8, Color(0.12, 0.12, 0.14), 6)
		vk.box(base + b0 * Vector3(-sgn * 0.0, 5.0, 0.0) + b0 * Vector3(sgn * 1.4, 0, 0), Vector3(0.12, 5.0, 2.4), Color(0.85, 0.10, 0.12), b0.get_euler())   # bandeira vermelha
		vk.box(base + b0 * Vector3(sgn * 1.4, 5.0, 1.25), Vector3(0.14, 1.6, 0.5), Color.WHITE, b0.get_euler())
	var beam_y: float = 14.2
	vk.box(c0 + Vector3(0, beam_y, 0), Vector3(gx * 2.0 + 1.6, 3.4, 1.4), Color(0.08, 0.08, 0.10), b0.get_euler())
	# xadrez nas duas pontas do painel
	for side in [-1.0, 1.0]:
		for cx in 6:
			for cy in 3:
				if (cx + cy) % 2 == 0:
					vk.box(c0 + b0 * Vector3(side * (gx - 1.1 - cx * 1.0), beam_y - 1.0 + cy * 1.0, 0.76), Vector3(1.0, 1.0, 0.1), Color.WHITE, b0.get_euler())
	vk.box(c0 + b0 * Vector3(0, beam_y, 0.76), Vector3(gx * 2.0 - 14.0, 2.4, 0.1), Color(0.95, 0.95, 0.97), b0.get_euler())   # faixa branca do nome
	vk.box(c0 + b0 * Vector3(0, beam_y, 0.82), Vector3(gx * 2.0 - 15.0, 0.5, 0.06), Color(0.85, 0.10, 0.12), b0.get_euler())
	# semáforo
	vk.box(c0 + b0 * Vector3(0, beam_y - 2.7, 0.0), Vector3(7.6, 1.4, 0.8), Color(0.08, 0.08, 0.10), b0.get_euler())
	for j in 5:
		gk.box(c0 + b0 * Vector3(-3.0 + j * 1.5, beam_y - 2.7, 0.45), Vector3(1.0, 1.0, 0.2), Color(1.0, 0.10, 0.10), b0.get_euler())
	# --- bancada com público, junto à meta (lado esquerdo) ---
	var side: float = -1.0
	var ib: int = 6
	var bb: Basis = _basis_at(ib)
	var bc: Vector3 = P[ib] + R[ib] * side * (wall_off + 16.0)
	for row in 7:
		vk.box(bc + bb * Vector3(side * row * 2.2, 1.0 + row * 1.2, 0), Vector3(2.2, 2.0 + row * 2.4, 54.0), Color(0.62, 0.64, 0.68), bb.get_euler())
		for q in 18:
			var colr: Color = [Color(0.9, 0.2, 0.2), Color(0.2, 0.4, 0.9), Color(0.95, 0.8, 0.2), Color(0.95, 0.95, 0.95), Color(0.2, 0.7, 0.3)][rng.randi_range(0, 4)]
			vk.box(bc + bb * Vector3(side * row * 2.2 - side * 0.6, 2.3 + row * 2.4 + row * 0.0, -25.0 + q * 2.9), Vector3(0.8, 1.2, 1.2), colr, bb.get_euler())
	vk.box(bc + bb * Vector3(side * 8.0, 20.0, 0), Vector3(20.0, 0.5, 58.0), Color(0.30, 0.32, 0.38), bb.get_euler())   # tecto
	for z in [-26.0, 0.0, 26.0]:
		vk.box(bc + bb * Vector3(side * 1.0, 10.0, z), Vector3(0.5, 20.0, 0.5), Color(0.2, 0.2, 0.24), bb.get_euler())
	# --- torre de controlo (lado direito) ---
	var it: int = 14
	var tb: Basis = _basis_at(it)
	var tc: Vector3 = P[it] + R[it] * (wall_off + 20.0)
	vk.frustum(tc, 5.2, 4.2, 22.0, Color(0.88, 0.89, 0.92), 14)
	vk.frustum(tc + Vector3(0, 21.9, 0), 7.2, 7.6, 3.4, Color(0.20, 0.45, 0.65), 14)
	vk.frustum(tc + Vector3(0, 25.3, 0), 8.2, 7.0, 1.3, Color(0.85, 0.12, 0.12), 14)
	vk.box(tc + Vector3(0, 29.0, 0), Vector3(0.3, 6.0, 0.3), Color(0.3, 0.3, 0.34), tb.get_euler())
	# mastro com bandeira axadrezada
	var mc: Vector3 = tc + tb * Vector3(14.0, 0, 0)
	vk.box(mc + Vector3(0, 9.0, 0), Vector3(0.35, 18.0, 0.35), Color(0.5, 0.5, 0.55))
	for cx in 4:
		for cy in 3:
			vk.box(mc + tb * Vector3(1.0 + cx * 0.9, 17.0 - cy * 0.9, 0), Vector3(0.9, 0.9, 0.1), Color.WHITE if (cx + cy) % 2 == 0 else Color(0.08, 0.08, 0.1), tb.get_euler())
	# --- painéis de publicidade e pilhas de pneus junto às barreiras ---
	for i in range(3, N, 6):
		var bi: Basis = _basis_at(i)
		for sg in [-1.0, 1.0]:
			var pp: Vector3 = P[i] + R[i] * sg * (wall_off + 0.9)
			var rot: Vector3 = bi.get_euler()
			if (i / 6) % 3 == 0:
				vk.box(pp + Vector3(0, 0.9, 0), Vector3(0.5, 1.8, 5.2), Color(0.09, 0.09, 0.11), rot)
				vk.box(pp - R[i] * sg * 0.28 + Vector3(0, 1.2, 0), Vector3(0.08, 0.35, 3.6), Color.WHITE, rot)
				vk.box(pp - R[i] * sg * 0.28 + bi * Vector3(0, 0.55, -2.2), Vector3(0.09, 0.9, 0.5), Color(0.85, 0.12, 0.12), rot)
			elif (i / 6) % 3 == 1:
				for lv in 3:
					for cc in 2:
						vk.frustum(pp + bi * Vector3(0, lv * 0.5, -0.6 + cc * 1.2), 0.62, 0.62, 0.5, Color(0.85, 0.12, 0.12) if lv != 1 else Color(0.95, 0.95, 0.95), 10)
	# --- montanhas ao longe e nuvens ---
	var far_r: float = float(def["base"]) * maxf(float(def["sx"]), float(def["sz"])) * 1.0 + 330.0
	var mcol: Color = Color(0.42, 0.55, 0.70) if not night else Color(0.08, 0.09, 0.16)
	if str(def["props"]) == "pines":
		mcol = Color(0.70, 0.78, 0.90)
	for j in 9:
		var a: float = TAU * j / 9.0 + rng.randf() * 0.4
		var mh: float = 70.0 + rng.randf() * 90.0
		var mp := Vector3(cos(a) * far_r, 0, sin(a) * far_r)
		vk.frustum(mp, mh * 1.3, mh * 0.12, mh, mcol, 9)
		vk.frustum(mp + Vector3(0, mh * 0.6, 0), mh * 0.62, 0.0, mh * 0.55, mcol.lightened(0.22), 9)
	if not night:
		var ck := MeshKit.new()
		for j in 16:
			var a2: float = rng.randf() * TAU
			var cp := Vector3(cos(a2) * (far_r * 0.7), 130.0 + rng.randf() * 60.0, sin(a2) * (far_r * 0.7))
			for q in 3:
				ck.ellipsoid(cp + Vector3(rng.randf_range(-18, 18), rng.randf_range(-3, 4), rng.randf_range(-12, 12)), Vector3(rng.randf_range(14, 24), 6.0, rng.randf_range(9, 15)), Color(1, 1, 1), 3, 8)
		_mat_node(self, ck, true)
	if not vk.is_empty():
		_mat_node(self, vk)
	if not gk.is_empty():
		_mat_node(self, gk, true)
