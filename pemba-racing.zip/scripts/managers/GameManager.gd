extends Node
## GameManager (autoload "Game")
## Maestro do jogo: guarda o progresso (moedas, carros) e troca entre ecrãs (menu, garagem, corrida).
## Cada ecrã constrói o seu mundo 3D e a sua interface por código.

const SAVE_PATH := "user://pemba_save.json"

var save: Dictionary = {}
var state: String = "none"
var screen: Node = null
var race_cfg: Dictionary = {"mode": "test"}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().set_auto_accept_quit(false)
	_load()
	call_deferred("go_menu")


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		get_tree().quit()
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		back()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		back()


## Botão "voltar" do Android (e Esc no computador).
func back() -> void:
	match state:
		"race":
			screen.toggle_pause()
		"garage", "setup", "champ":
			go_menu()
		"lobby":
			screen.on_back()
		"menu":
			screen.on_back()


# ---------- Progresso guardado ----------
func _load() -> void:
	save = {"version": 1, "coins": 3000, "selected": "pemba_gt", "cars": {}}
	if FileAccess.file_exists(SAVE_PATH):
		var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
		if f:
			var parsed: Variant = JSON.parse_string(f.get_as_text())
			if typeof(parsed) == TYPE_DICTIONARY:
				for k in parsed.keys():
					save[k] = parsed[k]
	if typeof(save["cars"]) != TYPE_DICTIONARY:
		save["cars"] = {}


func save_game() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(save))


func reset_save() -> void:
	save = {"version": 1, "coins": 3000, "selected": "pemba_gt", "cars": {}}
	save_game()


# ---------- Troca de ecrãs ----------
func _swap(new_state: String, node: Node) -> void:
	if screen != null:
		screen.queue_free()
		screen = null
	Engine.time_scale = 1.0
	get_tree().paused = false
	state = new_state
	screen = node
	add_child(node)


func go_menu() -> void:
	_swap("menu", MainMenuManager.new())


func go_garage() -> void:
	_swap("garage", GarageManager.new())


func go_race(cfg: Dictionary = {"mode": "test"}) -> void:
	race_cfg = cfg.duplicate(true)
	_swap("race", RaceManager.new())


func go_setup() -> void:
	_swap("setup", RaceSetupManager.new())


func go_champ() -> void:
	_swap("champ", ChampionshipScreen.new())


func go_lobby() -> void:
	_swap("lobby", LobbyScreen.new())


func quit_game() -> void:
	get_tree().quit()
