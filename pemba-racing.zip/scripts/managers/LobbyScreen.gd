class_name LobbyScreen
extends Node
## Ecrã do multiplayer offline: criar sala, entrar numa sala (lista automática ou IP) e sala de espera com a escolha da pista.

var _ui: CanvasLayer
var _root: Control
var _view: String = "menu"      # menu / join / room
var _status: Label = null
var _ip_edit: LineEdit = null
var _name_edit: LineEdit = null


func _ready() -> void:
	MP.players_changed.connect(_on_players)
	MP.host_lost.connect(_on_lost)
	Net.rooms_changed.connect(_on_rooms)
	Net.connect_failed.connect(func() -> void:
		_set_status(U.t("Não foi possível ligar. Confirma o IP e se estão na mesma rede.", "Could not connect. Check the IP and that you are on the same network.")))
	MP.in_race = false
	if Net.has_peer() and not MP.players.is_empty():
		_view = "room"
	_build()


func _exit_tree() -> void:
	Net.stop_scan()


func on_back() -> void:
	if _view == "menu":
		Game.go_menu()
	else:
		MP.leave()
		Net.stop_scan()
		_view = "menu"
		_build()


func _on_players() -> void:
	if _view == "join" and not MP.players.is_empty():
		_view = "room"
		Net.stop_scan()
	if _view == "room":
		_build()


func _on_rooms() -> void:
	if _view == "join":
		_build()


func _on_lost() -> void:
	_view = "menu"
	_build()
	_set_status(MP.last_error if MP.last_error != "" else U.t("A ligação ao anfitrião perdeu-se.", "Connection to the host was lost."))
	MP.last_error = ""


func _set_status(t: String) -> void:
	if _status != null:
		_status.text = t


func _build() -> void:
	if _ui != null:
		_ui.queue_free()
	_ui = CanvasLayer.new()
	add_child(_ui)
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.04, 0.10)
	_ui.add_child(bg)
	U.full(bg)
	var host := Control.new()
	host.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui.add_child(host)
	U.full(host)
	_root = U.safe_root(host)
	var title := U.label(U.t("MULTIPLAYER OFFLINE", "OFFLINE MULTIPLAYER"), 72, Color.WHITE)
	_root.add_child(title)
	U.place(title, Vector2(0, 0), Vector2(20, 4), Vector2(1500, 100))
	_status = U.label("", 32, Color(1, 0.7, 0.3), HORIZONTAL_ALIGNMENT_LEFT, false)
	_root.add_child(_status)
	U.place(_status, Vector2(0, 1), Vector2(360, 30), Vector2(1400, 50))
	var back := U.button(U.t("VOLTAR", "BACK"), U.GRAY, Vector2(320, 100), 42, on_back)
	_root.add_child(back)
	U.place(back, Vector2(0, 1), Vector2(20, 10), Vector2(320, 100))
	match _view:
		"menu":
			_build_menu()
		"join":
			_build_join()
		"room":
			_build_room()


func _text(t: String, y: float, h: float, fs: int = 36) -> void:
	var l := Label.new()
	l.text = t
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", fs)
	_root.add_child(l)
	U.place(l, Vector2(0, 0), Vector2(30, y), Vector2(1560, h))


func _build_menu() -> void:
	_text(U.t("Até 8 jogadores, SEM Internet. Liga todos os telemóveis ao mesmo Wi-Fi, ou liga o hotspot (ponto de acesso) num dos telemóveis e liga os outros a ele.\n1) Um jogador toca em CRIAR SALA.   2) Os outros tocam em ENTRAR NA SALA.   3) O anfitrião escolhe a pista e começa.",
		"Up to 8 players, NO Internet. Connect all phones to the same Wi-Fi, or turn on the hotspot on one phone and connect the others to it.\n1) One player taps CREATE ROOM.   2) The others tap JOIN ROOM.   3) The host picks the track and starts."), 120, 260)
	_text(U.t("O teu nome:", "Your name:"), 400, 50, 38)
	_name_edit = LineEdit.new()
	_name_edit.text = str(MP.my_info()["name"])
	_name_edit.max_length = 14
	_name_edit.add_theme_font_size_override("font_size", 44)
	_name_edit.text_changed.connect(func(t: String) -> void:
		Game.save["pname"] = t.strip_edges()
		Game.save_game())
	_root.add_child(_name_edit)
	U.place(_name_edit, Vector2(0, 0), Vector2(30, 450), Vector2(620, 84))
	var def: Dictionary = CarData.by_id(str(Game.save["selected"]))
	_text(U.t("O teu carro: ", "Your car: ") + str(def["name"]) + U.t("  (muda na Garagem)", "  (change it in the Garage)"), 550, 56, 36)
	var create := U.button(U.t("CRIAR SALA", "CREATE ROOM"), U.RED, Vector2(620, 120), 54, _on_create)
	_root.add_child(create)
	U.place(create, Vector2(0, 0), Vector2(30, 640), Vector2(620, 120))
	var join := U.button(U.t("ENTRAR NA SALA", "JOIN ROOM"), U.BLUE, Vector2(620, 120), 54, _on_join_menu)
	_root.add_child(join)
	U.place(join, Vector2(0, 0), Vector2(700, 640), Vector2(620, 120))


func _on_create() -> void:
	var err: int = MP.create_room()
	if err != OK:
		_set_status(U.t("Não foi possível criar a sala (erro %d)." % err, "Could not create the room (error %d)." % err))
		return
	_view = "room"
	_build()


func _on_join_menu() -> void:
	_view = "join"
	Net.start_scan()
	_build()


func _build_join() -> void:
	_text(U.t("Salas encontradas na rede (toca para entrar):", "Rooms found on the network (tap to join):"), 120, 56, 38)
	var y: float = 190.0
	var any: bool = false
	for ip in Net.rooms.keys():
		var r: Dictionary = Net.rooms[ip]
		var b := U.button("%s   ·   %d/%d   ·   %s" % [r["name"], r["players"], r["max"], ip], U.BLUE, Vector2(1000, 84), 38, func() -> void: _do_join(str(ip)))
		_root.add_child(b)
		U.place(b, Vector2(0, 0), Vector2(30, y), Vector2(1000, 84))
		y += 96.0
		any = true
		if y > 480.0:
			break
	if not any:
		_text(U.t("A procurar salas...  (se não aparecer nenhuma, escreve o IP abaixo)", "Searching for rooms...  (if none shows up, type the IP below)"), 190, 56, 34)
	_text(U.t("Ou escreve o IP que aparece no telemóvel do anfitrião:", "Or type the IP shown on the host's phone:"), 520, 56, 36)
	_ip_edit = LineEdit.new()
	_ip_edit.placeholder_text = "192.168.43.1"
	_ip_edit.add_theme_font_size_override("font_size", 48)
	_ip_edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	_ip_edit.text = str(Game.save.get("last_ip", ""))
	_root.add_child(_ip_edit)
	U.place(_ip_edit, Vector2(0, 0), Vector2(30, 585), Vector2(620, 90))
	var go := U.button(U.t("ENTRAR", "JOIN"), U.RED, Vector2(360, 90), 48, func() -> void: _do_join(_ip_edit.text))
	_root.add_child(go)
	U.place(go, Vector2(0, 0), Vector2(670, 585), Vector2(360, 90))


func _do_join(ip: String) -> void:
	ip = ip.strip_edges()
	if ip == "":
		_set_status(U.t("Escreve o IP do anfitrião.", "Type the host's IP."))
		return
	Game.save["last_ip"] = ip
	Game.save_game()
	var err: int = MP.join_room(ip)
	if err != OK:
		_set_status(U.t("Endereço inválido.", "Invalid address."))
	else:
		_set_status(U.t("A ligar a %s ..." % ip, "Connecting to %s ..." % ip))


func _build_room() -> void:
	# jogadores
	var panel := U.panel(Color(0.04, 0.08, 0.18, 0.92), 20)
	_root.add_child(panel)
	U.place(panel, Vector2(0, 0), Vector2(30, 120), Vector2(900, 720))
	var h := U.label(U.t("JOGADORES  %d/%d" % [MP.players.size(), Net.MAX_PLAYERS], "PLAYERS  %d/%d" % [MP.players.size(), Net.MAX_PLAYERS]), 38, Color(1, 0.85, 0.2), HORIZONTAL_ALIGNMENT_CENTER)
	panel.add_child(h)
	U.place(h, Vector2(0.5, 0), Vector2(0, 8), Vector2(860, 56))
	var ids: Array = MP.players.keys()
	ids.sort()
	for i in ids.size():
		var info: Dictionary = MP.players[ids[i]]
		var row := Panel.new()
		row.add_theme_stylebox_override("panel", U.box(Color(0.9, 0.13, 0.17, 0.5) if int(ids[i]) == MP.my_id() else Color(1, 1, 1, 0.07), 12))
		panel.add_child(row)
		U.place(row, Vector2(0.5, 0), Vector2(0, 70 + i * 79), Vector2(860, 70))
		var nm: String = str(info["name"]) + ("  ★" if int(ids[i]) == 1 else "")
		var l1 := U.label(nm, 34, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT, false)
		row.add_child(l1)
		U.place(l1, Vector2(0, 0.5), Vector2(20, 0), Vector2(480, 60))
		var l2 := U.label(str(CarData.by_id(str(info["car"]))["name"]), 30, Color(0.7, 0.85, 1.0), HORIZONTAL_ALIGNMENT_RIGHT, false)
		row.add_child(l2)
		U.place(l2, Vector2(1, 0.5), Vector2(20, 0), Vector2(340, 60))
	# definições da corrida
	var x: float = 980.0
	var td: Dictionary = TrackData.by_id(MP.track)
	var tl := U.label(U.t("Pista: ", "Track: ") + TrackData.tname(td), 42, Color.WHITE)
	_root.add_child(tl)
	U.place(tl, Vector2(0, 0), Vector2(x, 130), Vector2(900, 60))
	var ll := U.label(U.t("Voltas: ", "Laps: ") + str(MP.laps), 42, Color.WHITE)
	_root.add_child(ll)
	U.place(ll, Vector2(0, 0), Vector2(x, 200), Vector2(900, 60))
	if Net.hosting:
		var pb := U.button("◀", U.BLUE, Vector2(110, 80), 50, func() -> void: _track(-1))
		_root.add_child(pb)
		U.place(pb, Vector2(0, 0), Vector2(x, 270), Vector2(110, 80))
		var nb := U.button("▶", U.BLUE, Vector2(110, 80), 50, func() -> void: _track(1))
		_root.add_child(nb)
		U.place(nb, Vector2(0, 0), Vector2(x + 130, 270), Vector2(110, 80))
		var m := U.button("−", U.BLUE, Vector2(110, 80), 50, func() -> void: MP.set_laps(MP.laps - 1))
		_root.add_child(m)
		U.place(m, Vector2(0, 0), Vector2(x + 300, 270), Vector2(110, 80))
		var p := U.button("+", U.BLUE, Vector2(110, 80), 50, func() -> void: MP.set_laps(MP.laps + 1))
		_root.add_child(p)
		U.place(p, Vector2(0, 0), Vector2(x + 430, 270), Vector2(110, 80))
		var ips: Array = Net.local_ips()
		var iptxt: String = ", ".join(ips) if not ips.is_empty() else U.t("(sem rede: liga o Wi-Fi ou o hotspot)", "(no network: turn on Wi-Fi or hotspot)")
		var il := Label.new()
		il.text = U.t("Os outros jogadores entram pela lista ou escrevem este IP:\n", "The others join from the list or type this IP:\n") + iptxt
		il.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		il.add_theme_font_size_override("font_size", 38)
		il.add_theme_color_override("font_color", Color(0.6, 0.95, 0.6))
		_root.add_child(il)
		U.place(il, Vector2(0, 0), Vector2(x, 400), Vector2(900, 200))
		var ok: bool = MP.players.size() >= 2
		var st := U.button(U.t("COMEÇAR CORRIDA", "START RACE") if ok else U.t("À ESPERA DE JOGADORES...", "WAITING FOR PLAYERS..."), U.RED if ok else Color(0.3, 0.3, 0.35, 0.9), Vector2(900, 120), 46, func() -> void:
			if not MP.start_race():
				_set_status(U.t("Precisas de pelo menos 2 jogadores.", "You need at least 2 players.")))
		_root.add_child(st)
		U.place(st, Vector2(1, 1), Vector2(10, 10), Vector2(900, 120))
	else:
		var wl := U.label(U.t("À espera que o anfitrião comece a corrida...", "Waiting for the host to start the race..."), 40, Color(1, 0.85, 0.2))
		_root.add_child(wl)
		U.place(wl, Vector2(0, 0), Vector2(x, 300), Vector2(900, 70))


func _track(d: int) -> void:
	var i: int = TrackData.index_of(MP.track)
	i = (i + d + TrackData.ALL.size()) % TrackData.ALL.size()
	MP.set_track(str(TrackData.ALL[i]["id"]))
