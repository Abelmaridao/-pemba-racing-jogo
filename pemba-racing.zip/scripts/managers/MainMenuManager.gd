class_name MainMenuManager
extends Node
## MainMenuManager: menu principal com fundo 3D animado (carros desportivos a rodar, luzes vermelhas e azuis),
## logótipo, botões animados e os painéis de Configurações e de informação.

var _world: Node3D
var _cam: CameraManager
var _cars: Array = []
var _lights: Dictionary = {}
var _ui: CanvasLayer
var _root: Control
var _logo: Control
var _buttons: Array = []
var _overlay: Control = null
var _t: float = 0.0


func _ready() -> void:
	_build_world()
	_build_ui()
	Audio.play_music(true)


func _exit_tree() -> void:
	Audio.play_music(false)


func on_back() -> void:
	if _overlay != null:
		_close_overlay()
	else:
		Game.quit_game()


# ---------- Mundo 3D ----------
func _build_world() -> void:
	_world = Node3D.new()
	add_child(_world)
	_lights = Showroom.build(_world)
	_cam = CameraManager.new()
	_world.add_child(_cam)
	var picks := [9, 6, 8]
	var colors := [0, 1, 3]
	var n_show: int = 3 if Settings.quality >= 1 else 1
	for i in n_show:
		var def: Dictionary = CarData.ALL[picks[i]]
		var sv := {"color": colors[i], "rim": (i + 1) % 5, "finish": [0, 2, 3][i], "up_speed": 0, "up_accel": 0, "up_brake": 0}
		var car := ProceduralCar.build(def, sv)
		var ang: float = TAU * i / float(n_show)
		car.position = Vector3(cos(ang) * (5.0 if n_show > 1 else 0.0), 0, sin(ang) * (5.0 if n_show > 1 else 0.0))
		car.rotation.y = -ang
		_world.add_child(car)
		_cars.append(car)


func _process(delta: float) -> void:
	_t += delta
	var a: float = _t * 0.14
	_cam.cam.global_position = Vector3(cos(a) * 12.5, 2.6 + sin(_t * 0.4) * 0.4, sin(a) * 12.5)
	_cam.cam.look_at(Vector3(2.5, 0.9, 0), Vector3.UP)
	for i in _cars.size():
		(_cars[i] as Node3D).rotation.y += delta * 0.25
	if _lights.has("red"):
		(_lights["red"] as Node3D).position = Vector3(cos(_t * 0.9) * 9.0, 4.0, sin(_t * 0.9) * 9.0)
		(_lights["blue"] as Node3D).position = Vector3(cos(_t * 0.9 + PI) * 9.0, 4.0, sin(_t * 0.9 + PI) * 9.0)
	if _logo != null:
		var s: float = 1.0 + sin(_t * 2.0) * 0.015
		_logo.scale = Vector2(s, s)


# ---------- Interface ----------
func _build_ui() -> void:
	if _ui != null:
		_ui.queue_free()
	_buttons.clear()
	_overlay = null
	_ui = CanvasLayer.new()
	add_child(_ui)
	var host := Control.new()
	host.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui.add_child(host)
	U.full(host)
	_root = U.safe_root(host)

	# Logótipo
	var logo := RichTextLabel.new()
	logo.bbcode_enabled = true
	logo.fit_content = false
	logo.scroll_active = false
	logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	logo.text = "[b][color=#ffffff]Pemba[/color] [color=#e5232b]Racing[/color][/b]"
	logo.add_theme_font_size_override("bold_font_size", 130)
	logo.add_theme_font_size_override("normal_font_size", 130)
	logo.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	logo.add_theme_constant_override("outline_size", 14)
	_root.add_child(logo)
	U.place(logo, Vector2(0, 0), Vector2(40, 10), Vector2(1100, 170))
	logo.pivot_offset = Vector2(0, 60)
	_logo = logo
	var tag := U.label(U.t("CORRIDAS 3D  ·  MULTIPLAYER OFFLINE", "3D RACING  ·  OFFLINE MULTIPLAYER"), 34, Color(0.7, 0.8, 1.0))
	_root.add_child(tag)
	U.place(tag, Vector2(0, 0), Vector2(48, 175), Vector2(900, 50))

	# Botões
	var items: Array = [
		[U.t("JOGAR", "PLAY"), U.RED, _on_play],
		[U.t("MULTIPLAYER OFFLINE", "OFFLINE MULTIPLAYER"), U.BLUE, _on_multi],
		[U.t("GARAGEM", "GARAGE"), Color(0.08, 0.20, 0.50, 0.95), _on_garage],
		[U.t("CAMPEONATO", "CHAMPIONSHIP"), Color(0.16, 0.18, 0.28, 0.95), _on_champ],
		[U.t("CONFIGURAÇÕES", "SETTINGS"), U.GRAY, _on_settings],
		[U.t("SAIR", "QUIT"), Color(0.45, 0.07, 0.10, 0.95), _on_quit],
	]
	for i in items.size():
		var b := U.button(items[i][0], items[i][1], Vector2(640, 96), 44, items[i][2])
		_root.add_child(b)
		U.place(b, Vector2(0, 0), Vector2(40, 250 + i * 112), Vector2(640, 96))
		b.modulate.a = 0.0
		_buttons.append(b)
		var tw := create_tween()
		tw.tween_interval(0.08 * i + 0.1)
		tw.tween_property(b, "modulate:a", 1.0, 0.35)
		b.pivot_offset = Vector2(0, 48)
		b.scale = Vector2(0.85, 1.0)
		tw.parallel().tween_property(b, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

	# Moedas e versão
	var coins := U.panel(U.DARK, 20)
	_root.add_child(coins)
	U.place(coins, Vector2(1, 0), Vector2(10, 10), Vector2(380, 80))
	var cl := U.label(U.t("MOEDAS  ", "COINS  ") + str(int(Game.save["coins"])), 38, Color(1, 0.85, 0.2), HORIZONTAL_ALIGNMENT_CENTER)
	coins.add_child(cl)
	U.full(cl)
	var ver := U.label("v1.0", 26, Color(1, 1, 1, 0.55))
	_root.add_child(ver)
	U.place(ver, Vector2(1, 1), Vector2(10, 6), Vector2(300, 40))


func _on_play() -> void:
	Game.go_setup()


func _on_garage() -> void:
	Game.go_garage()


func _on_quit() -> void:
	Game.quit_game()


func _on_multi() -> void:
	Game.go_lobby()


func _on_champ() -> void:
	Game.go_champ()


# ---------- Painéis ----------
func _new_overlay() -> Control:
	_close_overlay()
	_overlay = Control.new()
	_ui.add_child(_overlay)
	U.full(_overlay)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.78)
	_overlay.add_child(dim)
	U.full(dim)
	return _overlay


func _close_overlay() -> void:
	if _overlay != null:
		_overlay.queue_free()
		_overlay = null


func _info(title: String, body: String) -> void:
	var o := _new_overlay()
	var p := U.panel(Color(0.05, 0.09, 0.19, 0.98), 30)
	o.add_child(p)
	U.place(p, Vector2(0.5, 0.5), Vector2.ZERO, Vector2(1300, 640))
	var t := U.label(title, 56, Color(1, 0.3, 0.3), HORIZONTAL_ALIGNMENT_CENTER)
	p.add_child(t)
	U.place(t, Vector2(0.5, 0), Vector2(0, 30), Vector2(1200, 80))
	var b := Label.new()
	b.text = body
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.add_theme_font_size_override("font_size", 36)
	p.add_child(b)
	U.place(b, Vector2(0.5, 0), Vector2(0, 130), Vector2(1180, 380))
	var close := U.button(U.t("VOLTAR", "BACK"), U.RED, Vector2(360, 90), 42, _close_overlay)
	p.add_child(close)
	U.place(close, Vector2(0.5, 1), Vector2(0, 28), Vector2(360, 90))


func _on_settings() -> void:
	var o := _new_overlay()
	var p := U.panel(Color(0.05, 0.09, 0.19, 0.98), 30)
	o.add_child(p)
	U.place(p, Vector2(0.5, 0.5), Vector2.ZERO, Vector2(1400, 860))
	var t := U.label(U.t("CONFIGURAÇÕES", "SETTINGS"), 56, Color(1, 0.3, 0.3), HORIZONTAL_ALIGNMENT_CENTER)
	p.add_child(t)
	U.place(t, Vector2(0.5, 0), Vector2(0, 24), Vector2(1200, 80))

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 40)
	grid.add_theme_constant_override("v_separation", 22)
	p.add_child(grid)
	U.place(grid, Vector2(0.5, 0), Vector2(0, 130), Vector2(1280, 560))

	var qn := [U.t("Baixa", "Low"), U.t("Média", "Medium"), U.t("Alta", "High")]
	var cn := [U.t("Botões", "Buttons"), U.t("Volante", "Wheel"), U.t("Inclinação", "Tilt")]
	var ln := ["Português", "English"]

	_row(grid, U.t("Qualidade gráfica", "Graphics quality"))
	var qb := U.button(qn[Settings.quality], U.BLUE, Vector2(560, 80), 38)
	qb.pressed.connect(func() -> void:
		Settings.quality = (Settings.quality + 1) % 3
		Settings.apply()
		Settings.save()
		qb.text = qn[Settings.quality])
	grid.add_child(qb)

	_row(grid, U.t("Volume da música", "Music volume"))
	grid.add_child(_slider(0.0, 1.0, Settings.music_vol, func(v: float) -> void:
		Settings.music_vol = v
		Settings.apply()
		Settings.save()))

	_row(grid, U.t("Volume dos efeitos", "Effects volume"))
	grid.add_child(_slider(0.0, 1.0, Settings.sfx_vol, func(v: float) -> void:
		Settings.sfx_vol = v
		Settings.apply()
		Settings.save()
		Audio.click()))

	_row(grid, U.t("Sensibilidade da direção", "Steering sensitivity"))
	grid.add_child(_slider(0.5, 1.5, Settings.sensitivity, func(v: float) -> void:
		Settings.sensitivity = v
		Settings.save()))

	_row(grid, U.t("Tipo de controlo", "Control type"))
	var cb := U.button(cn[Settings.control_type], U.BLUE, Vector2(560, 80), 38)
	cb.pressed.connect(func() -> void:
		Settings.control_type = (Settings.control_type + 1) % 3
		Settings.save()
		cb.text = cn[Settings.control_type])
	grid.add_child(cb)

	_row(grid, U.t("Botões de controlo", "Control buttons"))
	var eb := U.button(U.t("Editar / Mostrar", "Edit / Show"), U.BLUE, Vector2(560, 80), 34, func() -> void:
		_close_overlay()
		_on_edit_controls())
	grid.add_child(eb)

	_row(grid, U.t("Idioma", "Language"))
	var lb := U.button(ln[Settings.language], U.BLUE, Vector2(560, 80), 38)
	lb.pressed.connect(func() -> void:
		Settings.language = (Settings.language + 1) % 2
		Settings.save()
		_build_ui()
		_on_settings())
	grid.add_child(lb)

	var close := U.button(U.t("FECHAR", "CLOSE"), U.RED, Vector2(360, 90), 42, _close_overlay)
	p.add_child(close)
	U.place(close, Vector2(0.5, 1), Vector2(0, 26), Vector2(360, 90))


## Ecrã para arrastar os botões de controlo para nova posição e escolher quais aparecem numa corrida
## (só os necessários para a partida). As mudanças ficam guardadas logo (Settings.save()).
var _edit_controls: MobileControls = null

func _on_edit_controls() -> void:
	var o := _new_overlay()
	o.mouse_filter = Control.MOUSE_FILTER_PASS
	var tip := U.panel(Color(0.05, 0.09, 0.19, 0.92), 24)
	o.add_child(tip)
	U.place(tip, Vector2(0.5, 0), Vector2(0, 20), Vector2(1300, 70))
	var tl := U.label(U.t("Arrasta um botão para o mover. Desliga os que não precisas.", "Drag a button to move it. Turn off the ones you don't need."), 26, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, false)
	tip.add_child(tl)
	U.full(tl)

	_edit_controls = MobileControls.new()
	_edit_controls.edit_mode = true
	o.add_child(_edit_controls)

	var strip := U.panel(Color(0.05, 0.09, 0.19, 0.95), 24)
	o.add_child(strip)
	U.place(strip, Vector2(0.5, 1), Vector2(0, 110), Vector2(1700, 190))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	strip.add_child(row)
	U.place(row, Vector2(0.5, 0.5), Vector2.ZERO, Vector2(1660, 150))
	var names := {"gas": U.t("Acelerar", "Gas"), "brake": U.t("Travar", "Brake"), "rev": U.t("Marcha-atrás", "Reverse"),
		"hand": U.t("Travão de mão", "Handbrake"), "nitro": "Nitro", "cam": U.t("Câmara", "Cam"), "pause": U.t("Pausa", "Pause")}
	for id in Settings.EDITABLE_BUTTONS:
		var on: bool = bool(Settings.button_enabled.get(id, true))
		var tb := U.button((U.t("✔ ", "✔ ") if on else U.t("✘ ", "✘ ")) + str(names.get(id, id)), U.BLUE if on else U.GRAY, Vector2(220, 120), 24)
		tb.pressed.connect(func() -> void:
			Settings.button_enabled[id] = not bool(Settings.button_enabled.get(id, true))
			Settings.save()
			_on_edit_controls())
		row.add_child(tb)

	var reset := U.button(U.t("REPOR", "RESET"), U.RED, Vector2(260, 90), 34, func() -> void:
		Settings.reset_buttons()
		_on_edit_controls())
	o.add_child(reset)
	U.place(reset, Vector2(0.0, 1), Vector2(40, 320), Vector2(260, 90))

	var done := U.button(U.t("CONCLUÍDO", "DONE"), U.BLUE, Vector2(300, 90), 36, _close_overlay)
	o.add_child(done)
	U.place(done, Vector2(1.0, 1), Vector2(40, 320), Vector2(300, 90))


func _row(grid: GridContainer, text: String) -> void:
	var l := U.label(text, 38, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT, false)
	l.custom_minimum_size = Vector2(640, 80)
	grid.add_child(l)


func _slider(minv: float, maxv: float, val: float, cb: Callable) -> HSlider:
	var s := HSlider.new()
	s.min_value = minv
	s.max_value = maxv
	s.step = 0.01
	s.value = val
	s.custom_minimum_size = Vector2(560, 80)
	s.focus_mode = Control.FOCUS_NONE
	var track := U.box(Color(1, 1, 1, 0.18), 10)
	track.content_margin_top = 8
	track.content_margin_bottom = 8
	s.add_theme_stylebox_override("slider", track)
	s.add_theme_stylebox_override("grabber_area", U.box(U.RED, 10))
	s.add_theme_stylebox_override("grabber_area_highlight", U.box(U.RED.lightened(0.2), 10))
	var gtex := U.circle_tex(64, Color.WHITE)
	s.add_theme_icon_override("grabber", gtex)
	s.add_theme_icon_override("grabber_highlight", gtex)
	s.add_theme_icon_override("grabber_disabled", gtex)
	s.value_changed.connect(cb)
	return s
