extends Node
## ChampionshipManager (autoload "Championship")
## Campeonato: 5 corridas (uma em cada pista) contra 7 adversários. Pontos por posição, classificação geral e prémio final.
## O estado fica guardado em Game.save["champ"] e continua mesmo se fechares o jogo.

const POINTS := [25, 18, 15, 12, 10, 8, 6, 4]
const FINAL_PRIZE := [3000, 1800, 1200, 800, 500, 300, 200, 100]
const AI_NAMES := ["Nzinga", "Kimbo", "Zé Carlos", "Mwana", "Tandala", "Bento", "Luzia"]


func state() -> Dictionary:
	if not Game.save.has("champ") or typeof(Game.save["champ"]) != TYPE_DICTIONARY:
		Game.save["champ"] = {}
	return Game.save["champ"]


func active() -> bool:
	return state().has("round")


func rounds() -> int:
	return TrackData.ALL.size()


func round_index() -> int:
	return int(state().get("round", 0))


func finished() -> bool:
	return active() and round_index() >= rounds()


func start_new(difficulty: int) -> void:
	var pts: Dictionary = {"TU": 0}
	for n in AI_NAMES:
		pts[n] = 0
	Game.save["champ"] = {"round": 0, "points": pts, "difficulty": difficulty, "prize": 0, "last": []}
	Game.save_game()


func reset() -> void:
	Game.save.erase("champ")
	Game.save_game()


## Configuração da próxima corrida do campeonato.
func next_cfg() -> Dictionary:
	var st: Dictionary = state()
	var td: Dictionary = TrackData.ALL[mini(round_index(), rounds() - 1)]
	return {"mode": "champ", "track": td["id"], "laps": 3, "opponents": 7, "difficulty": int(st.get("difficulty", 1)), "names": AI_NAMES.duplicate()}


## Chamado no fim de cada corrida do campeonato com as linhas dos resultados (ordenadas por posição).
func record_race(rows: Array) -> void:
	var st: Dictionary = state()
	if not st.has("points") or finished():
		return
	var pts: Dictionary = st["points"]
	for i in rows.size():
		var nm: String = str(rows[i]["name"])
		pts[nm] = int(pts.get(nm, 0)) + (int(POINTS[i]) if i < POINTS.size() else 0)
	st["last"] = rows
	st["round"] = round_index() + 1
	if st["round"] >= rounds():
		var pos: int = position_of("TU")
		var prize: int = int(FINAL_PRIZE[clampi(pos - 1, 0, FINAL_PRIZE.size() - 1)])
		st["prize"] = prize
		Game.save["coins"] = int(Game.save["coins"]) + prize
	Game.save_game()


func standings() -> Array:
	var out: Array = []
	var pts: Dictionary = state().get("points", {})
	for k in pts.keys():
		out.append({"name": str(k), "pts": int(pts[k])})
	out.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		if a["pts"] != b["pts"]:
			return a["pts"] > b["pts"]
		return a["name"] == "TU")
	return out


func position_of(nm: String) -> int:
	var s: Array = standings()
	for i in s.size():
		if s[i]["name"] == nm:
			return i + 1
	return s.size()
