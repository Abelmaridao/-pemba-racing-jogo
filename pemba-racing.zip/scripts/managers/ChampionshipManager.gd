extends Node
## ChampionshipManager (autoload "Championship")
## Campeonato por eliminação, 5 corridas (uma em cada pista), começa com 8 pilotos:
##   Corrida 1: 8 pilotos, os 2 últimos são eliminados
##   Corrida 2: 6 pilotos, os 2 últimos são eliminados
##   Corrida 3: 4 pilotos, o último é eliminado
##   Corrida 4: 3 pilotos, o último é eliminado
##   Corrida 5: FINAL entre os 2 que restam; quem ganha é o campeão
## Se fores eliminado, o campeonato acaba para ti e recebes o prémio do lugar em que ficaste.
## O estado fica guardado em Game.save["champ"] e continua mesmo se fechares o jogo.

const POINTS := [25, 18, 15, 12, 10, 8, 6, 4]
const ELIMINATE := [2, 2, 1, 1, 0]                 # quantos saem em cada corrida (na final decide-se o campeão)
const PRIZE_BY_PLACE := [3000, 1800, 1200, 800, 500, 500, 200, 200]
const AI_NAMES := ["Nzinga", "Kimbo", "Zé Carlos", "Mwana", "Tandala", "Bento", "Luzia"]


func state() -> Dictionary:
	if not Game.save.has("champ") or typeof(Game.save["champ"]) != TYPE_DICTIONARY:
		Game.save["champ"] = {}
	return Game.save["champ"]


func active() -> bool:
	return state().has("round")


func rounds() -> int:
	return ELIMINATE.size()


func round_index() -> int:
	return int(state().get("round", 0))


## O campeonato acabou (final disputada ou eliminado).
func finished() -> bool:
	return active() and (bool(state().get("over", false)) or round_index() >= rounds())


func alive() -> Array:
	return (state().get("alive", []) as Array)


func player_out() -> bool:
	return bool(state().get("player_out", false))


func start_new(difficulty: int) -> void:
	var pts: Dictionary = {"TU": 0}
	var al: Array = ["TU"]
	for n in AI_NAMES:
		pts[n] = 0
		al.append(n)
	Game.save["champ"] = {"round": 0, "points": pts, "difficulty": difficulty, "prize": 0, "last": [], "alive": al, "out": {}, "over": false, "player_out": false, "place": 0}
	Game.save_game()


func reset() -> void:
	Game.save.erase("champ")
	Game.save_game()


## Quantos saem na corrida "r" (0..4).
func eliminated_in(r: int) -> int:
	return int(ELIMINATE[clampi(r, 0, ELIMINATE.size() - 1)])


## Configuração da próxima corrida do campeonato: só correm os pilotos que ainda estão vivos.
func next_cfg() -> Dictionary:
	var st: Dictionary = state()
	var td: Dictionary = TrackData.ALL[mini(round_index(), rounds() - 1)]
	var names: Array = []
	for n in alive():
		if str(n) != "TU":
			names.append(str(n))
	return {"mode": "champ", "track": td["id"], "laps": 3, "opponents": names.size(), "difficulty": int(st.get("difficulty", 1)), "names": names}


## Chamado no fim de cada corrida do campeonato com as linhas dos resultados (ordenadas por posição).
## Marca nas linhas "elim": true para quem sai nesta corrida.
func record_race(rows: Array) -> void:
	var st: Dictionary = state()
	if not st.has("points") or finished():
		return
	var pts: Dictionary = st["points"]
	var r: int = round_index()
	for i in rows.size():
		var nm: String = str(rows[i]["name"])
		pts[nm] = int(pts.get(nm, 0)) + (int(POINTS[i]) if i < POINTS.size() else 0)
	var n: int = rows.size()
	var out_n: int = eliminated_in(r)
	var al: Array = st["alive"]
	var outs: Dictionary = st["out"]
	for i in range(n - out_n, n):
		if i < 0:
			continue
		var nm2: String = str(rows[i]["name"])
		rows[i]["elim"] = true
		al.erase(nm2)
		outs[nm2] = r + 1
		if nm2 == "TU":
			st["player_out"] = true
			st["place"] = i + 1
	if r == rounds() - 1:
		# final: 1º é o campeão, o outro fica em 2º
		st["champion"] = str(rows[0]["name"])
		if str(rows[0]["name"]) == "TU":
			st["place"] = 1
		elif str(rows[n - 1]["name"]) == "TU":
			st["place"] = 2
			st["player_out"] = true
	st["last"] = rows
	st["round"] = r + 1
	if bool(st.get("player_out", false)) or st["round"] >= rounds():
		st["over"] = true
		var place: int = int(st.get("place", 1))
		var prize: int = int(PRIZE_BY_PLACE[clampi(place - 1, 0, PRIZE_BY_PLACE.size() - 1)])
		st["prize"] = prize
		Game.save["coins"] = int(Game.save["coins"]) + prize
	Game.save_game()


## Classificação geral: os vivos primeiro (por pontos) e depois os eliminados (os que saíram mais tarde primeiro).
func standings() -> Array:
	var out: Array = []
	var st: Dictionary = state()
	var pts: Dictionary = st.get("points", {})
	var outs: Dictionary = st.get("out", {})
	for k in pts.keys():
		out.append({"name": str(k), "pts": int(pts[k]), "out_round": int(outs.get(k, 0))})
	out.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		var ao: bool = int(a["out_round"]) > 0
		var bo: bool = int(b["out_round"]) > 0
		if ao != bo:
			return not ao
		if ao and a["out_round"] != b["out_round"]:
			return int(a["out_round"]) > int(b["out_round"])
		if a["pts"] != b["pts"]:
			return a["pts"] > b["pts"]
		return a["name"] == "TU")
	return out


func position_of(nm: String) -> int:
	var s: Array = standings()
	for i in s.size():
		if s[i]["name"] == nm:
			return i + 1
	return s.size()


## Texto curto sobre o que acontece em cada corrida.
func round_rule(r: int) -> String:
	var n: int = alive().size() if r == round_index() else 0
	match r:
		0:
			return U.t("8 pilotos · saem os 2 últimos", "8 racers · last 2 out")
		1:
			return U.t("6 pilotos · saem os 2 últimos", "6 racers · last 2 out")
		2:
			return U.t("4 pilotos · sai o último", "4 racers · last one out")
		3:
			return U.t("3 pilotos · sai o último", "3 racers · last one out")
		_:
			return U.t("FINAL · os 2 últimos pilotos", "FINAL · last 2 racers")
