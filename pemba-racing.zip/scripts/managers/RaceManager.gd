class_name RaceManager
extends Node
## RaceManager: a corrida. Modos (Game.race_cfg["mode"]):
##   "test"  = teste de condução numa arena aberta (Etapa 1)
##   "quick" = corrida rápida: pista, voltas, adversários (IA) e dificuldade à escolha
##   "champ" = uma corrida do campeonato
##   "mp"    = corrida multiplayer por Wi-Fi/hotspot (outros jogadores são carros remotos)
## Tem contagem 3-2-1, voltas, posição, tempos, minimapa, "sentido errado", resultados e prémio em moedas.

const IDLE := {"throttle": 0.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": false}
const NAMES := ["Nzinga", "Kimbo", "Zé Carlos", "Mwana", "Tandala", "Bento", "Luzia", "Sanjo", "Makeba", "Dino", "Cuca", "Nandi"]
const PRIZE := [600, 420, 300, 220, 160, 120, 90, 60]

var cfg: Dictionary = {}
var mode: String = "test"
var _world: Node3D
var _track: TrackManager
var circuit: Circuit = null
var _cam: CameraManager
var car: CarController
var controls: MobileControls
var racers: Array = []
var me: Racer = null
var _ui: CanvasLayer
var _speed_l: Label
var _time_l: Label
var _cam_l: Label
var _pos_l: Label
var _lap_l: Label
var _best_l: Label
var _way_l: Label
var _all_cars: Array = []
var _count_l: Label
var _skip_btn: Button = null
var _gauge: ProgressBar
var _mini: MiniMap = null
var _pause_panel: Control = null
var _results: Control = null
var _t: float = 0.0              # tempo de corrida (desde o GO)
var _count: float = 4.0          # contagem decrescente
var state: String = "countdown"  # waiting / countdown / racing / done
var paused: bool = false
var total_laps: int = 3
var _finish_wait: float = 0.0
var _result_rows: Array = []
var _reward: int = 0
var _state_t: float = 0.0
var _net_t: float = 0.0
var _count_shown: int = 99


class MiniMap extends Control:
	var pts := PackedVector2Array()
	var dots: Array = []        # [Vector2 (0..1), Color, bool player]
	func _draw() -> void:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.03, 0.06, 0.14, 0.7), true)
		if pts.size() > 2:
			var closed := PackedVector2Array(pts)
			closed.append(pts[0])
			draw_polyline(closed, Color(1, 1, 1, 0.85), 5.0, true)
		for d in dots:
			var p: Vector2 = (d[0] as Vector2) * size
			draw_circle(p, 11.0 if d[2] else 7.0, Color.WHITE if d[2] else Color(0, 0, 0, 0.6))
			draw_circle(p, 8.0 if d[2] else 5.0, d[1])


func _ready() -> void:
	cfg = Game.race_cfg.duplicate(true)
	mode = str(cfg.get("mode", "test"))
	_world = Node3D.new()
	add_child(_world)
	_track = TrackManager.new()
	_world.add_child(_track)
	var def: Dictionary = CarData.by_id(str(Game.save["selected"]))
	var sv: Dictionary = CarSelection.get_car(def["id"])
	if mode == "test":
		_track.build_test_arena()
		car = _make_car(def, sv)
		car.transform = _track.spawn_transform
		me = Racer.new()
		me.name = "TU"
		me.car = car
		me.is_player = true
		racers.append(me)
		state = "racing"
	else:
		_setup_circuit(def, sv)
	_cam = CameraManager.new()
	_world.add_child(_cam)
	_cam.set_target(car)
	_cam.set_mode(CameraManager.Mode.REAR)
	_ui = CanvasLayer.new()
	add_child(_ui)
	controls = MobileControls.new()
	_ui.add_child(controls)
	controls.camera_pressed.connect(_on_camera)
	controls.pause_pressed.connect(toggle_pause)
	_build_hud()
	if mode == "mp":
		state = "waiting"
		MP.race_ready()


func _exit_tree() -> void:
	Audio.set_engine(false, 0.0, 0.0)
	get_tree().paused = false


func _make_car(def: Dictionary, sv: Dictionary) -> CarController:
	var c := CarController.new()
	c.setup(def, sv, ProceduralCar.build(def, sv))
	_world.add_child(c)
	return c


# ---------- Montagem da corrida ----------
func _setup_circuit(def: Dictionary, sv: Dictionary) -> void:
	var td: Dictionary = TrackData.by_id(str(cfg.get("track", "savana")))
	total_laps = int(cfg.get("laps", td["laps"]))
	_world.add_child(TrackManager.make_environment(td["sky_top"], td["horizon"], float(td["ambient"]), true))
	var sun := TrackManager.make_sun(float(td["sun"]))
	_world.add_child(sun)
	circuit = Circuit.new()
	_world.add_child(circuit)
	circuit.build(td)
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	if mode == "mp":
		var plist: Array = cfg.get("players", [])
		var my_id: int = MP.my_id()
		for p in plist:
			var r := Racer.new()
			r.name = str(p["name"])
			r.peer = int(p["peer"])
			r.car_id = str(p["car"])
			var d: Dictionary = CarData.by_id(r.car_id)
			var v: Dictionary = {"color": int(p["color"]), "rim": int(p["rim"]), "finish": int(p["finish"]), "up_speed": int(p["up_speed"]), "up_accel": int(p["up_accel"]), "up_brake": int(p["up_brake"])}
			r.car = _make_car(d, v)
			r.car.transform = circuit.grid_slot(int(p["slot"]))
			r.color = CarSelection.COLORS[int(p["color"])]
			if r.peer == my_id:
				r.is_player = true
				me = r
				car = r.car
			else:
				r.remote = true
				r.car.puppet = true
				r.car.controllable = false
				r.car.freeze = true
				r.car.freeze_mode = RigidBody3D.FREEZE_MODE_KINEMATIC
			r.car.player_name = r.name
			racers.append(r)
		if me == null:
			me = racers[0]
			car = me.car
	else:
		var n_opp: int = clampi(int(cfg.get("opponents", 5)), 0, 7)
		var diff: int = clampi(int(cfg.get("difficulty", 1)), 0, 2)
		var base_skill: float = [0.70, 0.80, 0.95][diff]
		var slot_me: int = n_opp if diff > 0 else n_opp / 2
		var slot: int = 0
		var names: Array = (cfg["names"] as Array).duplicate() if cfg.has("names") else NAMES.duplicate()
		if not cfg.has("names"):
			names.shuffle()
		for i in n_opp + 1:
			var r := Racer.new()
			if i == slot_me:
				r.name = "TU"
				r.is_player = true
				r.car_id = str(def["id"])
				r.car = _make_car(def, sv)
				r.color = CarSelection.COLORS[int(sv["color"])]
				me = r
				car = r.car
			else:
				var d: Dictionary = _ai_car_data(rng, float(def["kmh"]))
				var cidx: int = rng.randi_range(0, CarSelection.COLORS.size() - 1)
				var v: Dictionary = {"color": cidx, "rim": rng.randi_range(0, 4), "finish": rng.randi_range(0, 3), "up_speed": 0, "up_accel": 0, "up_brake": 0}
				r.name = str(names.pop_back())
				r.car_id = str(d["id"])
				r.car = _make_car(d, v)
				r.color = CarSelection.COLORS[cidx]
				var ai := AIController.new()
				var lane: float = (-1.0 if (slot % 2 == 0) else 1.0) * (2.0 + rng.randf() * 3.5)
				ai.setup(r.car, circuit, clampf(base_skill + rng.randf_range(-0.03, 0.02), 0.7, 0.99), lane, rng.randf() * TAU)
				r.ai = ai
				ai.others = _all_cars
			r.car.transform = circuit.grid_slot(slot)
			r.car.player_name = r.name
			racers.append(r)
			_all_cars.append(r.car)
			slot += 1
	for r in racers:
		var rr: Racer = r
		rr.idx = circuit.nearest_global(rr.car.global_position)
		rr.dist = _grid_dist(rr)
		(rr.car as CarController).controllable = false
	# minimapa: pontos da pista em 0..1
	var lo := Vector2(1e9, 1e9)
	var hi := Vector2(-1e9, -1e9)
	for i in range(0, circuit.N, 3):
		lo.x = minf(lo.x, circuit.P[i].x)
		lo.y = minf(lo.y, circuit.P[i].z)
		hi.x = maxf(hi.x, circuit.P[i].x)
		hi.y = maxf(hi.y, circuit.P[i].z)
	_mini_lo = lo
	_mini_span = maxf(hi.x - lo.x, hi.y - lo.y)
	_mini_off = Vector2((_mini_span - (hi.x - lo.x)) * 0.5, (_mini_span - (hi.y - lo.y)) * 0.5)


var _mini_lo := Vector2.ZERO
var _mini_span: float = 1.0
var _mini_off := Vector2.ZERO


func _mini_pt(p: Vector3) -> Vector2:
	return (Vector2(p.x, p.z) - _mini_lo + _mini_off) / _mini_span * 0.88 + Vector2(0.06, 0.06)


## Posição inicial em pontos: a grelha está atrás da linha de meta (progresso negativo).
func _grid_dist(r: Racer) -> float:
	var i: int = r.idx
	var d: int = i - circuit.N
	if i < circuit.N / 2:
		d = i
	return float(d)


# ---------- Interface ----------
func _label_box(root: Control, anchor: Vector2, pos: Vector2, size: Vector2) -> Panel:
	var p := U.panel(U.DARK, 20)
	root.add_child(p)
	U.place(p, anchor, pos, size)
	return p


func _build_hud() -> void:
	var host := Control.new()
	host.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui.add_child(host)
	U.full(host)
	var root := U.safe_root(host)
	var tp := _label_box(root, Vector2(0, 0), Vector2(0, 0), Vector2(340, 80))
	_time_l = U.label("00:00.0", 44, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	tp.add_child(_time_l)
	U.full(_time_l)
	_cam_l = U.label("", 26, Color(0.6, 0.8, 1.0))
	root.add_child(_cam_l)
	U.place(_cam_l, Vector2(0, 0), Vector2(8, 88), Vector2(340, 34))
	if mode == "test":
		var title := U.label(U.t("PISTA DE TESTES  ·  ETAPA 1", "TEST TRACK  ·  STAGE 1"), 30, Color(1, 1, 1, 0.7))
		root.add_child(title)
		U.place(title, Vector2(0.5, 0), Vector2(0, 8), Vector2(700, 40))
	else:
		var pp := _label_box(root, Vector2(0.5, 0), Vector2(0, 0), Vector2(620, 92))
		_pos_l = U.label("1/1", 58, Color(1, 0.85, 0.2), HORIZONTAL_ALIGNMENT_CENTER)
		pp.add_child(_pos_l)
		U.place(_pos_l, Vector2(0, 0.5), Vector2(10, 0), Vector2(250, 80))
		_lap_l = U.label("", 40, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
		pp.add_child(_lap_l)
		U.place(_lap_l, Vector2(1, 0.5), Vector2(10, 0), Vector2(340, 80))
		_best_l = U.label("", 26, Color(0.7, 0.9, 1.0))
		root.add_child(_best_l)
		U.place(_best_l, Vector2(0, 0), Vector2(8, 122), Vector2(340, 34))
		_way_l = U.label(U.t("SENTIDO ERRADO!", "WRONG WAY!"), 64, Color(1, 0.2, 0.2), HORIZONTAL_ALIGNMENT_CENTER)
		root.add_child(_way_l)
		U.place(_way_l, Vector2(0.5, 0), Vector2(0, 110), Vector2(900, 90))
		_way_l.visible = false
		_count_l = U.label("", 220, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER)
		root.add_child(_count_l)
		U.place(_count_l, Vector2(0.5, 0.5), Vector2(0, -40), Vector2(900, 300))
		_mini = MiniMap.new()
		_mini.mouse_filter = Control.MOUSE_FILTER_IGNORE
		root.add_child(_mini)
		U.place(_mini, Vector2(1, 0), Vector2(0, 0), Vector2(230, 230))
		_mini.pts = PackedVector2Array()
		for i in range(0, circuit.N, 4):
			_mini.pts.append(_mini_pt(circuit.P[i]))
	# Velocímetro
	var sp := _label_box(root, Vector2(0.5, 1), Vector2(0, 0), Vector2(380, 170))
	_speed_l = U.label("0", 90, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	sp.add_child(_speed_l)
	U.place(_speed_l, Vector2(0.5, 0), Vector2(0, 6), Vector2(360, 100))
	var unit := U.label("km/h", 30, Color(0.7, 0.8, 1.0), HORIZONTAL_ALIGNMENT_CENTER, false)
	sp.add_child(unit)
	U.place(unit, Vector2(0.5, 0), Vector2(0, 100), Vector2(360, 36))
	_gauge = ProgressBar.new()
	_gauge.show_percentage = false
	_gauge.min_value = 0.0
	_gauge.max_value = 1.0
	_gauge.add_theme_stylebox_override("background", U.box(Color(1, 1, 1, 0.12), 8))
	_gauge.add_theme_stylebox_override("fill", U.box(U.RED, 8))
	sp.add_child(_gauge)
	U.place(_gauge, Vector2(0.5, 1), Vector2(0, 14), Vector2(340, 18))
	_update_cam_label()


func _update_cam_label() -> void:
	_cam_l.text = U.t("Câmara: ", "Camera: ") + _cam.mode_name()


func _on_camera() -> void:
	if paused:
		return
	_cam.cycle()
	_update_cam_label()
	Audio.click()


# ---------- Ciclo principal ----------
func _process(delta: float) -> void:
	if paused and mode != "mp":
		return
	_state_t += delta
	match state:
		"waiting":
			if _state_t > 10.0 or MP.countdown_go:
				_begin_countdown()
		"countdown":
			_count -= delta
			var n: int = int(ceil(_count - 1.0))
			if n != _count_shown and n >= 1 and n <= 3:
				_count_shown = n
				_count_l.text = str(n)
				Audio.beep(false)
			if _count <= 1.0:
				_go()
		"racing", "done":
			_t += delta
	if state == "racing" or state == "done":
		_update_progress()
	_update_drive_input(delta)
	_update_hud()
	if state == "racing" and me != null and me.finished:
		_finish_wait += delta
		if _finish_wait > 2.0 and _all_done_or_timeout():
			_finish_race()
	if mode == "mp" and state != "waiting":
		_net_tick(delta)


func _begin_countdown() -> void:
	state = "countdown"
	_count = 4.0
	_state_t = 0.0
	_count_shown = 99


func _go() -> void:
	state = "racing"
	_t = 0.0
	_count_l.text = U.t("JÁ!", "GO!")
	Audio.beep(true)
	var tw := create_tween()
	tw.tween_interval(0.8)
	tw.tween_callback(func() -> void: _count_l.text = "")
	for r in racers:
		var rr: Racer = r
		if not rr.remote:
			rr.car.controllable = true
		rr.lap_start = 0.0


func _update_drive_input(delta: float) -> void:
	if me == null:
		return
	var inp: Dictionary = controls.read(delta)
	var can_drive: bool = (state == "racing" or mode == "test") and not paused
	for r in racers:
		var rr: Racer = r
		if rr.remote:
			continue
		if rr.is_player and not rr.finished:
			rr.car.drive = inp if can_drive else IDLE.duplicate()
		elif rr.ai != null:
			if state == "racing" or state == "done":
				if not rr.is_player:
					rr.ai.rubber = _rubber_for(rr)
				rr.ai.update(delta)
			else:
				rr.car.drive = IDLE.duplicate()


func _update_progress() -> void:
	if circuit == null:
		return
	var n: int = circuit.N
	for r in racers:
		var rr: Racer = r
		var c: CarController = rr.car
		var p: Vector3 = c.global_position
		if rr.remote:
			continue   # o progresso dos remotos vem pela rede
		var ni: int = circuit.nearest(p, rr.idx)
		var d: int = ni - rr.idx
		if d > n / 2:
			d -= n
		elif d < -n / 2:
			d += n
		rr.idx = ni
		rr.dist += float(d)
		rr.frac = clampf((p - circuit.P[ni]).dot(circuit.T[ni]) / circuit.ds, -0.5, 0.5)
		c.surf = circuit.surface(p, ni)
		var done_laps: int = maxi(0, int(floor(rr.dist / float(n))))
		if done_laps > rr.laps:
			var lt: float = _t - rr.lap_start
			rr.lap_times.append(lt)
			if rr.best_lap <= 0.0 or lt < rr.best_lap:
				rr.best_lap = lt
			rr.lap_start = _t
			rr.laps = done_laps
			if rr.laps >= total_laps and not rr.finished:
				rr.finished = true
				rr.finish_time = _t
				if rr.is_player:
					Audio.win()
					# o carro continua sozinho depois de acabares (volta de vitória)
					var ai := AIController.new()
					ai.setup(rr.car, circuit, 0.6, 0.0, 0.0)
					ai.others = _all_cars
					rr.ai = ai
	if mode == "mp":
		for r in racers:
			var rr2: Racer = r
			if rr2.remote:
				var s: Dictionary = MP.states.get(rr2.peer, {})
				if not s.is_empty():
					rr2.dist = float(s.get("dist", rr2.dist))
					rr2.laps = int(s.get("laps", rr2.laps))
					if bool(s.get("fin", false)) and not rr2.finished:
						rr2.finished = true
						rr2.finish_time = float(s.get("ft", _t))
	_rank()


func _rank() -> void:
	var arr: Array = racers.duplicate()
	arr.sort_custom(func(a: Racer, b: Racer) -> bool:
		if a.finished != b.finished:
			return a.finished
		if a.finished and b.finished:
			return a.finish_time < b.finish_time
		return a.progress() > b.progress())
	for i in arr.size():
		(arr[i] as Racer).rank = i + 1


## Adversários com carros de classe parecida à do jogador (os 4 mais próximos em velocidade máxima), para a corrida ser equilibrada.
func _ai_car_data(rng: RandomNumberGenerator, mine: float) -> Dictionary:
	var arr: Array = CarData.ALL.duplicate()
	arr.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return absf(float(a["kmh"]) - mine) < absf(float(b["kmh"]) - mine))
	return arr[rng.randi_range(0, mini(3, arr.size() - 1))]


## Elástico suave: quem vai muito atrás acelera um pouco, quem vai muito à frente alivia, para o pelotão ficar junto.
func _rubber_for(rr: Racer) -> float:
	if me == null or mode == "mp":
		return 1.0
	var gap_m: float = (me.progress() - rr.progress()) * circuit.ds   # >0: o jogador está à frente
	return clampf(1.0 + gap_m * 0.0009, 0.88, 1.08)


func _all_done_or_timeout() -> bool:
	var all_fin: bool = true
	for r in racers:
		if not (r as Racer).finished:
			all_fin = false
	return all_fin or _finish_wait > 90.0


func _update_hud() -> void:
	if me == null:
		return
	_time_l.text = U.fmt_time(_t)
	_speed_l.text = str(int(round(car.speed_kmh)))
	var maxkmh: float = float(car.stats["max_ms"]) * 3.6
	var ratio: float = clampf(car.speed_kmh / maxkmh, 0.0, 1.0)
	_gauge.value = ratio
	_gauge.add_theme_stylebox_override("fill", U.box(Color(0.25, 0.65, 1.0) if car.nitro_on else U.RED, 8))
	controls.set_nitro(car.nitro, car.nitro_on)
	Audio.set_engine(true, ratio, float(car.drive["throttle"]))
	Audio.set_brake(car.slip if car.grounded else 0.0)
	if circuit == null:
		return
	if me.finished and state == "racing":
		_count_l.add_theme_font_size_override("font_size", 90)
		_count_l.text = U.t("TERMINASTE! %dº", "FINISHED! #%d") % me.rank
		if _skip_btn == null:
			_skip_btn = U.button(U.t("VER RESULTADOS", "SEE RESULTS"), U.RED, Vector2(520, 90), 42, func() -> void: _finish_race())
			_count_l.get_parent().add_child(_skip_btn)
			U.place(_skip_btn, Vector2(0.5, 0.5), Vector2(0, 170), Vector2(520, 90))
	_pos_l.text = "%d/%d" % [me.rank if me.rank > 0 else 1, racers.size()]
	_lap_l.text = U.t("VOLTA ", "LAP ") + "%d/%d" % [mini(me.laps + 1, total_laps), total_laps]
	_best_l.text = (U.t("Melhor volta  ", "Best lap  ") + U.fmt_time(me.best_lap)) if me.best_lap > 0.0 else ""
	var wrong: bool = false
	if state == "racing" and not me.finished and car.speed_kmh > 8.0:
		wrong = (-car.global_transform.basis.z).dot(circuit.T[me.idx]) < -0.3 and car.forward_speed > 0.0
	_way_l.visible = wrong
	_mini.dots.clear()
	for r in racers:
		var rr: Racer = r
		_mini.dots.append([_mini_pt(rr.car.global_position), rr.color, rr.is_player])
	_mini.queue_redraw()


# ---------- Multiplayer ----------
func _net_tick(delta: float) -> void:
	_net_t += delta
	# receber: mover carros remotos suavemente
	for r in racers:
		var rr: Racer = r
		if not rr.remote:
			continue
		var s: Dictionary = MP.states.get(rr.peer, {})
		if s.is_empty():
			continue
		var c: CarController = rr.car
		var target := Transform3D(Basis(Vector3.UP, float(s["yaw"])), s["pos"])
		c.global_transform = c.global_transform.interpolate_with(target, clampf(delta * 14.0, 0.0, 1.0))
		c.forward_speed = float(s["fs"])
		c.speed_kmh = absf(float(s["fs"])) * 3.6
		c.drive = {"throttle": 0.0, "brake": 0.0, "steer": float(s["steer"]), "reverse": false, "handbrake": false}
	# enviar o meu estado ~20 vezes por segundo
	if _net_t >= 0.05 and me != null:
		_net_t = 0.0
		MP.send_state({"pos": car.global_position, "yaw": car.global_rotation.y, "fs": car.forward_speed, "steer": float(car.drive["steer"]),
			"dist": me.dist, "laps": me.laps, "fin": me.finished, "ft": me.finish_time})


# ---------- Resultados ----------
func _finish_race() -> void:
	if state == "done":
		return
	state = "done"
	_rank()
	var arr: Array = racers.duplicate()
	arr.sort_custom(func(a: Racer, b: Racer) -> bool: return a.rank < b.rank)
	_result_rows = []
	for r in arr:
		var rr: Racer = r
		_result_rows.append({"name": rr.name, "time": rr.finish_time if rr.finished else -1.0, "me": rr.is_player, "car": rr.car_id, "best": rr.best_lap})
	var diff_mul: float = [0.8, 1.0, 1.3][clampi(int(cfg.get("difficulty", 1)), 0, 2)]
	var idx_p: int = clampi(me.rank - 1, 0, PRIZE.size() - 1)
	_reward = int(round(float(PRIZE[idx_p]) * float(total_laps) / 3.0 * diff_mul))
	if mode == "mp":
		_reward = int(round(float(PRIZE[idx_p]) * float(total_laps) / 3.0))
	Game.save["coins"] = int(Game.save["coins"]) + _reward
	Game.save_game()
	if mode == "champ":
		Championship.record_race(_result_rows)
	_show_results()


func _show_results() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 6
	add_child(layer)
	_results = Control.new()
	layer.add_child(_results)
	U.full(_results)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.72)
	_results.add_child(dim)
	U.full(dim)
	var p := U.panel(Color(0.05, 0.09, 0.19, 0.98), 30)
	_results.add_child(p)
	U.place(p, Vector2(0.5, 0.5), Vector2.ZERO, Vector2(1100, 900))
	var t := U.label(U.t("RESULTADOS", "RESULTS") + "  ·  " + TrackData.tname(circuit.def), 50, Color(1, 0.3, 0.3), HORIZONTAL_ALIGNMENT_CENTER)
	p.add_child(t)
	U.place(t, Vector2(0.5, 0), Vector2(0, 20), Vector2(1040, 76))
	var y: float = 110.0
	var shown: int = 0
	for row in _result_rows:
		if shown >= 8:
			break
		var is_me: bool = bool(row["me"])
		var line := Panel.new()
		line.add_theme_stylebox_override("panel", U.box(Color(0.9, 0.13, 0.17, 0.55) if is_me else Color(1, 1, 1, 0.07), 14))
		p.add_child(line)
		U.place(line, Vector2(0.5, 0), Vector2(0, y), Vector2(1000, 66))
		var tm: String = U.fmt_time(float(row["time"])) if float(row["time"]) >= 0.0 else "—"
		var l1 := U.label("%d.  %s" % [shown + 1, str(row["name"])], 36, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT, false)
		line.add_child(l1)
		U.place(l1, Vector2(0, 0.5), Vector2(20, 0), Vector2(560, 60))
		var l2 := U.label(tm, 36, Color(1, 0.9, 0.5), HORIZONTAL_ALIGNMENT_RIGHT, false)
		line.add_child(l2)
		U.place(l2, Vector2(1, 0.5), Vector2(20, 0), Vector2(360, 60))
		y += 72.0
		shown += 1
	var rw := U.label(U.t("Prémio: +%d moedas" % _reward, "Prize: +%d coins" % _reward), 44, Color(1, 0.85, 0.2), HORIZONTAL_ALIGNMENT_CENTER)
	p.add_child(rw)
	U.place(rw, Vector2(0.5, 1), Vector2(0, 150), Vector2(900, 60))
	var b1: Button
	if mode == "champ":
		b1 = U.button(U.t("CONTINUAR", "CONTINUE"), U.RED, Vector2(440, 90), 42, func() -> void: Game.go_champ())
	elif mode == "mp":
		b1 = U.button(U.t("VOLTAR À SALA", "BACK TO LOBBY"), U.RED, Vector2(440, 90), 42, func() -> void: Game.go_lobby())
	else:
		b1 = U.button(U.t("CORRER DE NOVO", "RACE AGAIN"), U.RED, Vector2(440, 90), 42, func() -> void: Game.go_race(cfg))
	p.add_child(b1)
	U.place(b1, Vector2(0, 1), Vector2(50, 36), Vector2(440, 90))
	var b2 := U.button(U.t("MENU", "MENU"), U.GRAY, Vector2(440, 90), 42, func() -> void: _leave())
	p.add_child(b2)
	U.place(b2, Vector2(1, 1), Vector2(50, 36), Vector2(440, 90))


func _leave() -> void:
	if mode == "mp":
		MP.leave()
	Game.go_menu()


# ---------- Pausa ----------
func toggle_pause() -> void:
	if state == "done":
		return
	paused = not paused
	if mode != "mp":
		get_tree().paused = paused
	if paused:
		Audio.set_engine(false, 0.0, 0.0)
		_show_pause()
	elif _pause_panel != null:
		_pause_panel.queue_free()
		_pause_panel = null


func _show_pause() -> void:
	_pause_panel = Control.new()
	_pause_panel.process_mode = Node.PROCESS_MODE_ALWAYS
	var layer := CanvasLayer.new()
	layer.layer = 5
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(layer)
	layer.add_child(_pause_panel)
	U.full(_pause_panel)
	_pause_panel.tree_exited.connect(func() -> void: layer.queue_free())
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.7)
	_pause_panel.add_child(dim)
	U.full(dim)
	var p := U.panel(Color(0.05, 0.09, 0.19, 0.98), 30)
	_pause_panel.add_child(p)
	U.place(p, Vector2(0.5, 0.5), Vector2.ZERO, Vector2(700, 640))
	var t := U.label(U.t("PAUSA", "PAUSED"), 64, Color(1, 0.3, 0.3), HORIZONTAL_ALIGNMENT_CENTER)
	p.add_child(t)
	U.place(t, Vector2(0.5, 0), Vector2(0, 24), Vector2(600, 90))
	var b1 := U.button(U.t("CONTINUAR", "RESUME"), U.RED, Vector2(560, 100), 44, toggle_pause)
	p.add_child(b1)
	U.place(b1, Vector2(0.5, 0), Vector2(0, 150), Vector2(560, 100))
	if mode != "mp":
		var b2 := U.button(U.t("REINICIAR", "RESTART"), U.BLUE, Vector2(560, 100), 44, _restart)
		p.add_child(b2)
		U.place(b2, Vector2(0.5, 0), Vector2(0, 275), Vector2(560, 100))
	var b3 := U.button(U.t("MENU PRINCIPAL", "MAIN MENU"), U.GRAY, Vector2(560, 100), 44, _leave)
	p.add_child(b3)
	U.place(b3, Vector2(0.5, 0), Vector2(0, 400), Vector2(560, 100))


func _restart() -> void:
	if mode == "test":
		toggle_pause()
		_t = 0.0
		car.transform = _track.spawn_transform
		car.linear_velocity = Vector3.ZERO
		car.angular_velocity = Vector3.ZERO
		_cam.snap()
	else:
		get_tree().paused = false
		Game.go_race(cfg)
