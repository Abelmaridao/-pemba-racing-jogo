class_name Showroom
extends RefCounted
## Cenário de exposição (usado no menu e na garagem): já não é um fundo preto/vazio — tem um céu com
## cor (gradiente roxo/magenta "de vida"), chão digno de um showroom (disco brilhante com um holofote
## dourado por baixo do carro + anéis de néon) e luzes vermelha/azul a rodar.


static func build(parent: Node3D) -> Dictionary:
	# Fundo com cor em vez de quase-preto: gradiente roxo/magenta, mais "vivo".
	parent.add_child(TrackManager.make_environment(Color(0.09, 0.06, 0.20), Color(0.46, 0.22, 0.55), 0.55, false))

	var ring_mat := StandardMaterial3D.new()
	ring_mat.albedo_color = Color(0.05, 0.3, 0.9)
	ring_mat.emission_enabled = true
	ring_mat.emission = Color(0.1, 0.45, 1.0)
	ring_mat.emission_energy_multiplier = 2.0
	var ring := MeshInstance3D.new()
	var rm := CylinderMesh.new()
	rm.top_radius = 15.5
	rm.bottom_radius = 15.5
	rm.height = 0.02
	rm.radial_segments = 48
	ring.mesh = rm
	ring.material_override = ring_mat
	ring.position.y = -0.011
	parent.add_child(ring)

	# Chão digno: disco claro e polido (em vez de quase-preto) com reflexo.
	var floor_mat := StandardMaterial3D.new()
	floor_mat.albedo_color = Color(0.14, 0.13, 0.19)
	floor_mat.roughness = 0.18
	floor_mat.metallic = 0.85
	var fl := MeshInstance3D.new()
	var fm := CylinderMesh.new()
	fm.top_radius = 14.5
	fm.bottom_radius = 14.5
	fm.height = 0.02
	fm.radial_segments = 48
	fl.mesh = fm
	fl.material_override = floor_mat
	parent.add_child(fl)

	# Holofote dourado no chão, mesmo debaixo do carro — dá cor e vida ao centro do chão.
	var spot_mat := StandardMaterial3D.new()
	spot_mat.albedo_color = Color(0.9, 0.7, 0.25)
	spot_mat.emission_enabled = true
	spot_mat.emission = Color(1.0, 0.78, 0.30)
	spot_mat.emission_energy_multiplier = 0.9
	var spot := MeshInstance3D.new()
	var sm := CylinderMesh.new()
	sm.top_radius = 5.2
	sm.bottom_radius = 5.2
	sm.height = 0.02
	sm.radial_segments = 40
	spot.mesh = sm
	spot.material_override = spot_mat
	spot.position.y = 0.001
	parent.add_child(spot)

	# Anel fino de néon a meio do chão (detalhe de "showroom", não um vazio liso).
	var detail_mat := StandardMaterial3D.new()
	detail_mat.albedo_color = Color(0.95, 0.95, 1.0)
	detail_mat.emission_enabled = true
	detail_mat.emission = Color(0.8, 0.85, 1.0)
	detail_mat.emission_energy_multiplier = 1.4
	var detail := MeshInstance3D.new()
	var dm := TorusMesh.new()
	dm.inner_radius = 9.6
	dm.outer_radius = 9.9
	dm.rings = 48
	dm.ring_segments = 6
	detail.mesh = dm
	detail.material_override = detail_mat
	detail.position.y = 0.01
	parent.add_child(detail)

	# Paredes e teto: para parecer o interior de uma oficina de carros, não um vazio infinito a céu aberto.
	# São cilindros normais vistos de dentro (cull_mode FRONT mostra a face de trás, a que fica visível
	# de dentro da "sala"), por isso são leves (2 meshes só) e não têm colisão — é só cenário.
	var wall_mat := StandardMaterial3D.new()
	wall_mat.albedo_color = Color(0.13, 0.12, 0.17)
	wall_mat.roughness = 0.8
	wall_mat.cull_mode = BaseMaterial3D.CULL_FRONT
	var wall := MeshInstance3D.new()
	var wm := CylinderMesh.new()
	wm.top_radius = 42.0
	wm.bottom_radius = 42.0
	wm.height = 20.0
	wm.radial_segments = 28
	wall.mesh = wm
	wall.material_override = wall_mat
	wall.position.y = 9.0
	parent.add_child(wall)

	var ceil_mat := StandardMaterial3D.new()
	ceil_mat.albedo_color = Color(0.09, 0.09, 0.12)
	ceil_mat.roughness = 0.9
	ceil_mat.cull_mode = BaseMaterial3D.CULL_FRONT
	var ceil_mi := MeshInstance3D.new()
	var cm2 := CylinderMesh.new()
	cm2.top_radius = 42.0
	cm2.bottom_radius = 42.0
	cm2.height = 0.05
	cm2.radial_segments = 28
	ceil_mi.mesh = cm2
	ceil_mi.material_override = ceil_mat
	ceil_mi.position.y = 19.0
	parent.add_child(ceil_mi)

	# Tiras de luz fluorescente no teto, como numa oficina de verdade.
	var strip_mat := StandardMaterial3D.new()
	strip_mat.albedo_color = Color(0.85, 0.92, 1.0)
	strip_mat.emission_enabled = true
	strip_mat.emission = Color(0.85, 0.92, 1.0)
	strip_mat.emission_energy_multiplier = 2.4
	for i in 6:
		var ang: float = i * TAU / 6.0
		var strip := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(11.0, 0.12, 1.3)
		strip.mesh = bm
		strip.material_override = strip_mat
		strip.position = Vector3(cos(ang) * 23.0, 18.7, sin(ang) * 23.0)
		strip.rotation.y = ang
		parent.add_child(strip)

	var key := DirectionalLight3D.new()
	key.rotation_degrees = Vector3(-45, 30, 0)
	key.light_energy = 0.6
	key.shadow_enabled = Settings.shadows_enabled()
	parent.add_child(key)

	var out := {}
	if Settings.quality >= 1:
		var red := OmniLight3D.new()
		red.light_color = Color(1.0, 0.1, 0.15)
		red.light_energy = 4.0
		red.omni_range = 26.0
		parent.add_child(red)
		var blue := OmniLight3D.new()
		blue.light_color = Color(0.1, 0.4, 1.0)
		blue.light_energy = 4.0
		blue.omni_range = 26.0
		parent.add_child(blue)
		out = {"red": red, "blue": blue}
	return out
