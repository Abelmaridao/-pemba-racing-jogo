class_name GarageManager
extends Node
## GarageManager: garagem 3D. Rodar o carro (arrastar), aproximar/afastar (botões, roda do rato ou pinça),
## escolher veículo, ver características, mudar cor / jantes / pintura e comprar melhorias com moedas.

var _world: Node3D
var _cam: CameraManager
var _pivot: Node3D
var _visual: CarVisual = null
var _lights: Dictionary = {}
var _ui: CanvasLayer
var _root: Control
var _idx: int = 0
var _yaw: float = 2.6
var _zoom: float = 6.4
var _idle: float = 0.0
var _t: float = 0.0
var _dragging: bool = false

# referências de interface
var _name_l: Label
var _tag_l: Label
var _coins_l: Label
var _bars: Array = []
var _vals: Array = []
var _up_btns: Array = []
var _action: Button
var _rim_btn: Button
var _fin_btn: Button
var _toast: Label
var _swatches: Array = []


func _ready() -> void:
	_idx = CarData.index_of(str(Game.save["selected"]))
	_world = Node3D.new()
	add_child(_world)
	_lights = Showroom.build(_world)
	_pivot = Node3D.new()
	_world.add_child(_pivot)
	_cam = CameraManager.new()
	_world.add_child(_cam)
	_build_ui()
	_rebuild_car()
	_refresh()


func _process(delta: float) -> void:
	_t += delta
	_idle += delta
	if not _dragging and _idle > 2.0:
		_yaw += delta * 0.35
	_pivot.rotation.y = _yaw
	_zoom = clampf(_zoom, 4.5, 12.0)
	_cam.cam.global_position = Vector3(0, 1.5 + (_zoom - 6.4) * 0.1, _zoom)
	_cam.cam.look_at(Vector3(0, 0.7, 0), Vector3.UP)
	if _lights.has("red"):
		(_lights["red"] as Node3D).position = Vector3(cos(_t * 0.8) * 8.0, 4.0, sin(_t * 0.8) * 8.0)
	if _lights.has("blue"):
		(_lights["blue"] as Node3D).position = Vector3(cos(_t * 0.8 + PI) * 8.0, 4.0, sin(_t * 0.8 + PI) * 8.0)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenDrag and event.index == 0:
		_yaw += event.relative.x * 0.012
		_idle = 0.0
		_dragging = true
	elif event is InputEventScreenTouch and not event.pressed:
		_dragging = false
	elif event is InputEventMouseMotion and (event.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0 and not event.is_echo():
		# no computador (sem toque emulado a duplicar)
		if not Input.is_emulating_touch_from_mouse():
			_yaw += event.relative.x * 0.012
			_idle = 0.0
	elif event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			_zoom -= 0.6
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_zoom += 0.6
	elif event is InputEventMagnifyGesture:
		_zoom /= maxf(0.2, event.factor)


# ---------- Carro em exposição ----------
func _def() -> Dictionary:
	return CarData.ALL[_idx]


func _rebuild_car() -> void:
	if _visual != null:
		_visual.queue_free()
	var sv := CarSelection.get_car(_def()["id"])
	_visual = ProceduralCar.build(_def(), sv)
	_pivot.add_child(_visual)


# ---------- Interface ----------
func _build_ui() -> void:
	_ui = CanvasLayer.new()
	add_child(_ui)
	var host := Control.new()
	host.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui.add_child(host)
	U.full(host)
	_root = U.safe_root(host)
	var TL := Vector2(0, 0)
	var TR := Vector2(1, 0)
	var BC := Vector2(0.5, 1)

	var back := U.button("< " + U.t("MENU", "MENU"), U.GRAY, Vector2(240, 80), 36, func() -> void: Game.go_menu())
	_root.add_child(back)
	U.place(back, TL, Vector2(0, 0), Vector2(240, 80))

	var cp := U.panel(U.DARK, 20)
	_root.add_child(cp)
	U.place(cp, TR, Vector2(0, 0), Vector2(380, 80))
	_coins_l = U.label("", 36, Color(1, 0.85, 0.2), HORIZONTAL_ALIGNMENT_CENTER)
	cp.add_child(_coins_l)
	U.full(_coins_l)

	# Painel esquerdo: características e melhorias
	var lp := U.panel(U.DARK, 24)
	_root.add_child(lp)
	U.place(lp, TL, Vector2(0, 100), Vector2(560, 700))
	var st := U.label(U.t("CARACTERÍSTICAS", "STATS"), 34, Color(0.7, 0.8, 1.0))
	lp.add_child(st)
	U.place(st, TL, Vector2(24, 12), Vector2(500, 50))
	var names := [U.t("VELOCIDADE", "SPEED"), U.t("ACELERAÇÃO", "ACCELERATION"), U.t("TRAVAGEM", "BRAKING"), U.t("DIREÇÃO", "STEERING")]
	for i in 4:
		var l := U.label(names[i], 28, Color.WHITE, HORIZONTAL_ALIGNMENT_LEFT, false)
		lp.add_child(l)
		U.place(l, TL, Vector2(24, 70 + i * 82), Vector2(300, 36))
		var v := U.label("", 28, Color(1, 0.85, 0.2), HORIZONTAL_ALIGNMENT_RIGHT, false)
		lp.add_child(v)
		U.place(v, TL, Vector2(300, 70 + i * 82), Vector2(236, 36))
		_vals.append(v)
		var bar := ProgressBar.new()
		bar.show_percentage = false
		bar.min_value = 0.0
		bar.max_value = 1.0
		bar.add_theme_stylebox_override("background", U.box(Color(1, 1, 1, 0.12), 8))
		bar.add_theme_stylebox_override("fill", U.box([U.BLUE, U.RED, Color(1, 0.6, 0.1), Color(0.2, 0.8, 0.4)][i], 8))
		lp.add_child(bar)
		U.place(bar, TL, Vector2(24, 108 + i * 82), Vector2(512, 22))
		_bars.append(bar)
	var ut := U.label(U.t("MELHORIAS (moedas)", "UPGRADES (coins)"), 30, Color(0.7, 0.8, 1.0))
	lp.add_child(ut)
	U.place(ut, TL, Vector2(24, 400), Vector2(500, 44))
	var un := [U.t("VELOCIDADE", "SPEED"), U.t("ACELERAÇÃO", "ACCEL."), U.t("TRAVAGEM", "BRAKING")]
	for k in 3:
		var kk: int = k
		var ub := U.button("", U.BLUE, Vector2(512, 66), 28, func() -> void: _on_upgrade(kk))
		lp.add_child(ub)
		U.place(ub, TL, Vector2(24, 452 + k * 76), Vector2(512, 66))
		_up_btns.append(ub)
	_up_btns[0].set_meta("n", un[0])
	_up_btns[1].set_meta("n", un[1])
	_up_btns[2].set_meta("n", un[2])

	# Painel direito: personalização
	var rp := U.panel(U.DARK, 24)
	_root.add_child(rp)
	U.place(rp, TR, Vector2(0, 100), Vector2(560, 700))
	var ct := U.label(U.t("COR", "COLOR"), 32, Color(0.7, 0.8, 1.0))
	rp.add_child(ct)
	U.place(ct, TL, Vector2(24, 14), Vector2(400, 44))
	for i in CarSelection.COLORS.size():
		var ii: int = i
		var sb := Button.new()
		sb.focus_mode = Control.FOCUS_NONE
		var c: Color = CarSelection.COLORS[i]
		sb.add_theme_stylebox_override("normal", U.box(c, 16, Color(1, 1, 1, 0.25), 3))
		sb.add_theme_stylebox_override("hover", U.box(c.lightened(0.15), 16, Color(1, 1, 1, 0.6), 3))
		sb.add_theme_stylebox_override("pressed", U.box(c.darkened(0.2), 16, Color(1, 1, 1, 1), 4))
		sb.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
		sb.pressed.connect(func() -> void: _on_color(ii))
		rp.add_child(sb)
		U.place(sb, TL, Vector2(24 + (i % 5) * 102, 64 + (i / 5) * 100), Vector2(92, 92))
		_swatches.append(sb)
	var jt := U.label(U.t("JANTES", "RIMS"), 32, Color(0.7, 0.8, 1.0))
	rp.add_child(jt)
	U.place(jt, TL, Vector2(24, 280), Vector2(400, 44))
	_rim_btn = U.button("", U.BLUE, Vector2(512, 76), 34, func() -> void: _on_rim())
	rp.add_child(_rim_btn)
	U.place(_rim_btn, TL, Vector2(24, 326), Vector2(512, 76))
	var pt := U.label(U.t("PINTURA", "PAINT"), 32, Color(0.7, 0.8, 1.0))
	rp.add_child(pt)
	U.place(pt, TL, Vector2(24, 416), Vector2(400, 44))
	_fin_btn = U.button("", U.BLUE, Vector2(512, 76), 34, func() -> void: _on_finish())
	rp.add_child(_fin_btn)
	U.place(_fin_btn, TL, Vector2(24, 462), Vector2(512, 76))
	_action = U.button("", U.RED, Vector2(512, 100), 40, func() -> void: _on_action())
	rp.add_child(_action)
	U.place(_action, TL, Vector2(24, 574), Vector2(512, 100))

	# Rodapé: nome e setas
	_name_l = U.label("", 58, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	_root.add_child(_name_l)
	U.place(_name_l, BC, Vector2(0, 100), Vector2(800, 80))
	_tag_l = U.label("", 30, Color(0.75, 0.85, 1.0), HORIZONTAL_ALIGNMENT_CENTER, false)
	_root.add_child(_tag_l)
	U.place(_tag_l, BC, Vector2(0, 62), Vector2(800, 40))
	var prev := U.button("<", U.BLUE, Vector2(120, 110), 70, func() -> void: _step(-1))
	_root.add_child(prev)
	U.place(prev, BC, Vector2(-520, 20), Vector2(120, 110))
	var nxt := U.button(">", U.BLUE, Vector2(120, 110), 70, func() -> void: _step(1))
	_root.add_child(nxt)
	U.place(nxt, BC, Vector2(520, 20), Vector2(120, 110))
	var zin := U.button("+", U.GRAY, Vector2(90, 90), 54, func() -> void: _zoom -= 1.0)
	_root.add_child(zin)
	U.place(zin, Vector2(0.5, 0), Vector2(-60, 0), Vector2(90, 90))
	var zout := U.button("-", U.GRAY, Vector2(90, 90), 54, func() -> void: _zoom += 1.0)
	_root.add_child(zout)
	U.place(zout, Vector2(0.5, 0), Vector2(60, 0), Vector2(90, 90))

	_toast = U.label("", 40, Color(1, 0.9, 0.3), HORIZONTAL_ALIGNMENT_CENTER)
	_root.add_child(_toast)
	U.place(_toast, Vector2(0.5, 0.5), Vector2(0, -200), Vector2(1000, 60))


func _say(msg: String) -> void:
	_toast.text = msg
	_toast.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_interval(1.4)
	tw.tween_property(_toast, "modulate:a", 0.0, 0.5)


# ---------- Acções ----------
func _step(d: int) -> void:
	_idx = (_idx + d + CarData.ALL.size()) % CarData.ALL.size()
	_idle = 0.0
	_rebuild_car()
	_refresh()


func _owned() -> bool:
	return bool(CarSelection.get_car(_def()["id"])["owned"])


func _on_color(i: int) -> void:
	if not _owned():
		_say(U.t("Compra o carro primeiro.", "Buy the car first."))
		return
	CarSelection.get_car(_def()["id"])["color"] = i
	Game.save_game()
	_rebuild_car()
	_refresh()


func _on_rim() -> void:
	if not _owned():
		_say(U.t("Compra o carro primeiro.", "Buy the car first."))
		return
	var sv := CarSelection.get_car(_def()["id"])
	sv["rim"] = (int(sv["rim"]) + 1) % CarSelection.RIM_NAMES.size()
	Game.save_game()
	_rebuild_car()
	_refresh()


func _on_finish() -> void:
	if not _owned():
		_say(U.t("Compra o carro primeiro.", "Buy the car first."))
		return
	var sv := CarSelection.get_car(_def()["id"])
	sv["finish"] = (int(sv["finish"]) + 1) % CarSelection.FINISH_NAMES.size()
	Game.save_game()
	_rebuild_car()
	_refresh()


func _on_upgrade(kind: int) -> void:
	if not _owned():
		_say(U.t("Compra o carro primeiro.", "Buy the car first."))
		return
	if CarSelection.try_upgrade(_def(), kind):
		Audio.win()
		_say(U.t("Melhoria comprada!", "Upgrade bought!"))
	else:
		var key: String = ["up_speed", "up_accel", "up_brake"][kind]
		if int(CarSelection.get_car(_def()["id"])[key]) >= CarSelection.MAX_UPGRADE:
			_say(U.t("Nível máximo.", "Max level."))
		else:
			_say(U.t("Moedas insuficientes.", "Not enough coins."))
	_refresh()


func _on_action() -> void:
	var d := _def()
	if _owned():
		CarSelection.select(d)
		_say(U.t("Carro selecionado!", "Car selected!"))
	elif CarSelection.try_buy(d):
		CarSelection.select(d)
		Audio.win()
		_say(U.t("Carro comprado!", "Car bought!"))
	else:
		_say(U.t("Moedas insuficientes.", "Not enough coins."))
	_refresh()


func _refresh() -> void:
	var d := _def()
	var sv := CarSelection.get_car(d["id"])
	var s := CarSelection.stats(d, sv)
	_name_l.text = str(d["name"])
	_tag_l.text = CarData.tag(d)
	_coins_l.text = U.t("MOEDAS  ", "COINS  ") + str(int(Game.save["coins"]))
	(_bars[0] as ProgressBar).value = float(s["max_ms"]) * 3.6 / CarData.MAX_KMH
	(_bars[1] as ProgressBar).value = float(s["accel"]) / CarData.MAX_ACCEL
	(_bars[2] as ProgressBar).value = float(s["brake"]) / CarData.MAX_BRAKE
	(_bars[3] as ProgressBar).value = float(s["steer"]) / CarData.MAX_STEER
	(_vals[0] as Label).text = "%d km/h" % int(round(float(s["max_ms"]) * 3.6))
	(_vals[1] as Label).text = "%.1f m/s²" % float(s["accel"])
	(_vals[2] as Label).text = "%.1f m/s²" % float(s["brake"])
	(_vals[3] as Label).text = "%d °/s" % int(round(float(s["steer"])))
	var keys := ["up_speed", "up_accel", "up_brake"]
	for k in 3:
		var lvl: int = int(sv[keys[k]])
		var b: Button = _up_btns[k]
		var n: String = b.get_meta("n")
		if lvl >= CarSelection.MAX_UPGRADE:
			b.text = "%s  %d/%d  MAX" % [n, lvl, CarSelection.MAX_UPGRADE]
			b.disabled = true
		else:
			b.text = "+ %s  %d/%d  (%d)" % [n, lvl, CarSelection.MAX_UPGRADE, CarSelection.upgrade_cost(lvl)]
			b.disabled = not bool(sv["owned"])
	_rim_btn.text = CarSelection.rim_name(int(sv["rim"]))
	_fin_btn.text = CarSelection.finish_name(int(sv["finish"]))
	if not bool(sv["owned"]):
		_action.text = U.t("COMPRAR  ", "BUY  ") + str(int(d["price"]))
		_action.disabled = false
	elif str(Game.save["selected"]) == str(d["id"]):
		_action.text = U.t("SELECIONADO", "SELECTED")
		_action.disabled = true
	else:
		_action.text = U.t("SELECIONAR", "SELECT")
		_action.disabled = false
