class_name Racer
extends RefCounted
## Dados de um piloto na corrida (jogador, adversário da IA ou jogador remoto).

var name: String = ""
var car: CarController
var is_player: bool = false          # o carro controlado neste telemóvel
var remote: bool = false             # jogador de outro telemóvel (multiplayer)
var ai: AIController = null
var peer: int = 0
var car_id: String = ""
var color: Color = Color.WHITE
var idx: int = 0
var dist: float = 0.0                # progresso em pontos da pista (negativo = antes da meta)
var frac: float = 0.0
var laps: int = 0                    # voltas completas
var finished: bool = false
var finish_time: float = 0.0
var lap_start: float = 0.0
var best_lap: float = 0.0
var lap_times: Array = []
var rank: int = 0
var dnf: bool = false


func progress() -> float:
	return dist + frac
