class_name MeshKit
extends RefCounted
## Construtor de malhas leves: junta caixas, "lofts" (carroçarias) e cilindros numa única malha com cores por vértice.
## Um carro inteiro passa de dezenas de objectos para poucas malhas, o que poupa muito o processador do telemóvel.

var _v := PackedVector3Array()
var _n := PackedVector3Array()
var _c := PackedColorArray()


func _tri(a: Vector3, b: Vector3, c: Vector3, nrm: Vector3, col: Color) -> void:
	# O Godot usa triângulos no sentido dos ponteiros do relógio (visto de fora).
	_v.append(a); _v.append(c); _v.append(b)
	_n.append(nrm); _n.append(nrm); _n.append(nrm)
	_c.append(col); _c.append(col); _c.append(col)


## Quadrilátero com a normal virada para fora do ponto "center".
func quad(a: Vector3, b: Vector3, c: Vector3, d: Vector3, col: Color, center: Vector3) -> void:
	var nrm: Vector3 = (b - a).cross(c - a)
	if nrm.length_squared() < 1e-10:
		nrm = (c - a).cross(d - a)
	if nrm.dot((a + b + c + d) * 0.25 - center) < 0.0:
		var t: Vector3 = b
		b = d
		d = t
		nrm = -nrm
	nrm = nrm.normalized()
	_tri(a, b, c, nrm, col)
	_tri(a, c, d, nrm, col)


func tri(a: Vector3, b: Vector3, c: Vector3, col: Color, center: Vector3) -> void:
	var nrm: Vector3 = (b - a).cross(c - a)
	if nrm.dot((a + b + c) / 3.0 - center) < 0.0:
		var t: Vector3 = b
		b = c
		c = t
		nrm = -nrm
	_tri(a, b, c, nrm.normalized(), col)


func box(center: Vector3, size: Vector3, col: Color, rot: Vector3 = Vector3.ZERO) -> void:
	var bs := Basis.from_euler(rot)
	var h: Vector3 = size * 0.5
	var p: Array = []
	for i in 8:
		var sx: float = 1.0 if (i & 1) else -1.0
		var sy: float = 1.0 if (i & 2) else -1.0
		var sz: float = 1.0 if (i & 4) else -1.0
		p.append(center + bs * Vector3(h.x * sx, h.y * sy, h.z * sz))
	# índices: bit0 = x, bit1 = y, bit2 = z
	quad(p[0], p[1], p[3], p[2], col, center)  # -Z
	quad(p[4], p[5], p[7], p[6], col, center)  # +Z
	quad(p[0], p[2], p[6], p[4], col, center)  # -X
	quad(p[1], p[3], p[7], p[5], col, center)  # +X
	quad(p[0], p[1], p[5], p[4], col, center)  # -Y
	quad(p[2], p[3], p[7], p[6], col, center)  # +Y


## Carroçaria por secções ao longo de Z. Cada secção: Vector4(z, meia_largura, y_baixo, y_cima). Frente = Z negativo.
func loft(secs: Array, col: Color, xoff: float = 0.0, caps: bool = true) -> void:
	for i in secs.size() - 1:
		var a: Vector4 = secs[i]
		var b: Vector4 = secs[i + 1]
		var a0 := Vector3(xoff - a.y, a.z, a.x)
		var a1 := Vector3(xoff + a.y, a.z, a.x)
		var a2 := Vector3(xoff + a.y, a.w, a.x)
		var a3 := Vector3(xoff - a.y, a.w, a.x)
		var b0 := Vector3(xoff - b.y, b.z, b.x)
		var b1 := Vector3(xoff + b.y, b.z, b.x)
		var b2 := Vector3(xoff + b.y, b.w, b.x)
		var b3 := Vector3(xoff - b.y, b.w, b.x)
		var ctr: Vector3 = (a0 + a1 + a2 + a3 + b0 + b1 + b2 + b3) / 8.0
		quad(a0, a1, b1, b0, col, ctr)  # fundo
		quad(a3, a2, b2, b3, col, ctr)  # topo
		quad(a0, a3, b3, b0, col, ctr)  # lado esquerdo
		quad(a1, a2, b2, b1, col, ctr)  # lado direito
		if caps and i == 0:
			quad(a0, a1, a2, a3, col, ctr)
		if caps and i == secs.size() - 2:
			quad(b0, b1, b2, b3, col, ctr)


## Cilindro com eixo no X (rodas).
func cyl_x(center: Vector3, radius: float, width: float, col: Color, segs: int = 12) -> void:
	var hx: float = width * 0.5
	for i in segs:
		var a0: float = TAU * i / segs
		var a1: float = TAU * (i + 1) / segs
		var p0 := Vector3(-hx, cos(a0) * radius, sin(a0) * radius) + center
		var p1 := Vector3(-hx, cos(a1) * radius, sin(a1) * radius) + center
		var p2 := Vector3(hx, cos(a1) * radius, sin(a1) * radius) + center
		var p3 := Vector3(hx, cos(a0) * radius, sin(a0) * radius) + center
		quad(p0, p1, p2, p3, col, center)
		tri(center + Vector3(-hx, 0, 0), p0, p1, col, center)
		tri(center + Vector3(hx, 0, 0), p3, p2, col, center)


## Fita no chão/estrada: lista de pares (esquerda, direita) já em 3D. Normal para cima.
func ribbon(left: PackedVector3Array, right: PackedVector3Array, col: Color, close: bool = true) -> void:
	var n: int = left.size()
	var last: int = n if close else n - 1
	for i in last:
		var j: int = (i + 1) % n
		quad(left[i], right[i], right[j], left[j], col, (left[i] + right[j]) * 0.5 - Vector3.UP)


func is_empty() -> bool:
	return _v.is_empty()


func vertex_count() -> int:
	return _v.size()


func commit() -> ArrayMesh:
	var m := ArrayMesh.new()
	if _v.is_empty():
		return m
	var arr: Array = []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = _v
	arr[Mesh.ARRAY_NORMAL] = _n
	arr[Mesh.ARRAY_COLOR] = _c
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	return m


## Material partilhado para malhas com cores por vértice.
static var _vc_mat: Dictionary = {}

static func vc_material(emissive: bool = false) -> StandardMaterial3D:
	var key: String = str(Settings.quality) + ("e" if emissive else "n")
	if _vc_mat.has(key):
		return _vc_mat[key]
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 0.6
	m.metallic = 0.1
	if Settings.quality == 0:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
	if emissive:
		m.emission_enabled = true
		m.emission = Color(1, 1, 1)
		m.emission_energy_multiplier = 1.4
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_vc_mat[key] = m
	return m
