class_name MeshKit
extends RefCounted
## Construtor de malhas leves: junta caixas, "lofts" (carroçarias) e cilindros numa única malha com cores por vértice.
## Um carro inteiro passa de dezenas de objectos para poucas malhas, o que poupa muito o processador do telemóvel.

var _v := PackedVector3Array()
var _n := PackedVector3Array()
var _c := PackedColorArray()


func _tri(a: Vector3, b: Vector3, c: Vector3, nrm: Vector3, col: Color) -> void:
	# O Godot usa triângulos no sentido dos ponteiros do relógio (visto de fora).
	_v.append(a); _v.append(c); _v.append(b)
	_n.append(nrm); _n.append(nrm); _n.append(nrm)
	_c.append(col); _c.append(col); _c.append(col)


## Quadrilátero com a normal virada para fora do ponto "center".
func quad(a: Vector3, b: Vector3, c: Vector3, d: Vector3, col: Color, center: Vector3) -> void:
	var nrm: Vector3 = (b - a).cross(c - a)
	if nrm.length_squared() < 1e-10:
		nrm = (c - a).cross(d - a)
	if nrm.dot((a + b + c + d) * 0.25 - center) < 0.0:
		var t: Vector3 = b
		b = d
		d = t
		nrm = -nrm
	nrm = nrm.normalized()
	_tri(a, b, c, nrm, col)
	_tri(a, c, d, nrm, col)


func tri(a: Vector3, b: Vector3, c: Vector3, col: Color, center: Vector3) -> void:
	var nrm: Vector3 = (b - a).cross(c - a)
	if nrm.dot((a + b + c) / 3.0 - center) < 0.0:
		var t: Vector3 = b
		b = c
		c = t
		nrm = -nrm
	_tri(a, b, c, nrm.normalized(), col)


func box(center: Vector3, size: Vector3, col: Color, rot: Vector3 = Vector3.ZERO) -> void:
	var bs := Basis.from_euler(rot)
	var h: Vector3 = size * 0.5
	var p: Array = []
	for i in 8:
		var sx: float = 1.0 if (i & 1) else -1.0
		var sy: float = 1.0 if (i & 2) else -1.0
		var sz: float = 1.0 if (i & 4) else -1.0
		p.append(center + bs * Vector3(h.x * sx, h.y * sy, h.z * sz))
	# índices: bit0 = x, bit1 = y, bit2 = z
	quad(p[0], p[1], p[3], p[2], col, center)  # -Z
	quad(p[4], p[5], p[7], p[6], col, center)  # +Z
	quad(p[0], p[2], p[6], p[4], col, center)  # -X
	quad(p[1], p[3], p[7], p[5], col, center)  # +X
	quad(p[0], p[1], p[5], p[4], col, center)  # -Y
	quad(p[2], p[3], p[7], p[6], col, center)  # +Y


## Carroçaria por secções ao longo de Z. Cada secção: Vector4(z, meia_largura, y_baixo, y_cima). Frente = Z negativo.
## As secções são suavizadas (Catmull-Rom sem ultrapassar os extremos) e a secção transversal é arredondada (10 pontos).
static func _smooth(secs: Array, sub: int) -> Array:
	var out: Array = []
	var n: int = secs.size()
	for i in n - 1:
		var p1: Vector4 = secs[i]
		var p2: Vector4 = secs[i + 1]
		var p0: Vector4 = secs[maxi(i - 1, 0)]
		var p3: Vector4 = secs[mini(i + 2, n - 1)]
		var steps: int = sub if absf(p2.x - p1.x) > 0.05 else 1
		for k in steps:
			var t: float = float(k) / steps
			var t2: float = t * t
			var t3: float = t2 * t
			var c: Vector4 = 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2 + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3)
			c.x = lerpf(p1.x, p2.x, t)
			c.y = clampf(c.y, minf(p1.y, p2.y), maxf(p1.y, p2.y))
			c.z = clampf(c.z, minf(p1.z, p2.z), maxf(p1.z, p2.z))
			c.w = clampf(c.w, minf(p1.w, p2.w), maxf(p1.w, p2.w))
			out.append(c)
	out.append(secs[n - 1])
	return out


static func _ring(sc: Vector4, xoff: float) -> Array:
	var w: float = sc.y
	var yl: float = sc.z
	var yh: float = sc.w
	var h: float = yh - yl
	var r: float = minf(w, h * 0.5)
	return [
		Vector3(xoff - w * 0.86, yl, sc.x), Vector3(xoff + w * 0.86, yl, sc.x),
		Vector3(xoff + w, yl + h * 0.20, sc.x), Vector3(xoff + w, yh - h * 0.36, sc.x),
		Vector3(xoff + w * 0.80, yh - h * 0.07, sc.x), Vector3(xoff + w * 0.42, yh, sc.x),
		Vector3(xoff - w * 0.42, yh, sc.x), Vector3(xoff - w * 0.80, yh - h * 0.07, sc.x),
		Vector3(xoff - w, yh - h * 0.36, sc.x), Vector3(xoff - w, yl + h * 0.20, sc.x)]


func loft(secs: Array, col: Color, xoff: float = 0.0, caps: bool = true) -> void:
	var ss: Array = _smooth(secs, 3)
	var rings: Array = []
	for sc in ss:
		rings.append(_ring(sc, xoff))
	var m: int = (rings[0] as Array).size()
	for i in rings.size() - 1:
		var ra: Array = rings[i]
		var rb: Array = rings[i + 1]
		var ctr := Vector3.ZERO
		for q in m:
			ctr += (ra[q] as Vector3) + (rb[q] as Vector3)
		ctr /= float(m * 2)
		for q in m:
			var q2: int = (q + 1) % m
			quad(ra[q], ra[q2], rb[q2], rb[q], col, ctr)
		if caps and i == 0:
			for q in range(1, m - 1):
				tri(ra[0], ra[q], ra[q + 1], col, ctr)
		if caps and i == rings.size() - 2:
			for q in range(1, m - 1):
				tri(rb[0], rb[q], rb[q + 1], col, ctr)


## Cilindro com eixo no X (rodas).
func cyl_x(center: Vector3, radius: float, width: float, col: Color, segs: int = 12) -> void:
	var hx: float = width * 0.5
	for i in segs:
		var a0: float = TAU * i / segs
		var a1: float = TAU * (i + 1) / segs
		var p0 := Vector3(-hx, cos(a0) * radius, sin(a0) * radius) + center
		var p1 := Vector3(-hx, cos(a1) * radius, sin(a1) * radius) + center
		var p2 := Vector3(hx, cos(a1) * radius, sin(a1) * radius) + center
		var p3 := Vector3(hx, cos(a0) * radius, sin(a0) * radius) + center
		quad(p0, p1, p2, p3, col, center)
		tri(center + Vector3(-hx, 0, 0), p0, p1, col, center)
		tri(center + Vector3(hx, 0, 0), p3, p2, col, center)


## Fita no chão/estrada: lista de pares (esquerda, direita) já em 3D. Normal para cima.
func ribbon(left: PackedVector3Array, right: PackedVector3Array, col: Color, close: bool = true) -> void:
	var n: int = left.size()
	var last: int = n if close else n - 1
	for i in last:
		var j: int = (i + 1) % n
		quad(left[i], right[i], right[j], left[j], col, (left[i] + right[j]) * 0.5 - Vector3.UP)


## Cilindro/cone vertical (raio em baixo e em cima), base em "base".
func frustum(base: Vector3, r0: float, r1: float, h: float, col: Color, segs: int = 8, tilt: Vector3 = Vector3.ZERO) -> void:
	var bs := Basis.from_euler(tilt)
	var center: Vector3 = base + bs * Vector3(0, h * 0.5, 0)
	for i in segs:
		var a0: float = TAU * i / segs
		var a1: float = TAU * (i + 1) / segs
		var b0: Vector3 = base + bs * Vector3(cos(a0) * r0, 0, sin(a0) * r0)
		var b1: Vector3 = base + bs * Vector3(cos(a1) * r0, 0, sin(a1) * r0)
		var t0: Vector3 = base + bs * Vector3(cos(a0) * r1, h, sin(a0) * r1)
		var t1: Vector3 = base + bs * Vector3(cos(a1) * r1, h, sin(a1) * r1)
		if r1 < 0.001:
			tri(b0, b1, t0, col, center)
		else:
			quad(b0, b1, t1, t0, col, center)
		tri(base, b1, b0, col, center)
		if r1 >= 0.001:
			tri(base + bs * Vector3(0, h, 0), t0, t1, col, center)


## Elipsóide (arredondado), com "rings" anéis e "segs" segmentos.
func ellipsoid(center: Vector3, radii: Vector3, col: Color, rings: int = 4, segs: int = 8, rot: Vector3 = Vector3.ZERO) -> void:
	var bs := Basis.from_euler(rot)
	for r in rings:
		var p0: float = PI * r / rings
		var p1: float = PI * (r + 1) / rings
		for i in segs:
			var a0: float = TAU * i / segs
			var a1: float = TAU * (i + 1) / segs
			var v00: Vector3 = center + bs * Vector3(sin(p0) * cos(a0) * radii.x, cos(p0) * radii.y, sin(p0) * sin(a0) * radii.z)
			var v01: Vector3 = center + bs * Vector3(sin(p0) * cos(a1) * radii.x, cos(p0) * radii.y, sin(p0) * sin(a1) * radii.z)
			var v10: Vector3 = center + bs * Vector3(sin(p1) * cos(a0) * radii.x, cos(p1) * radii.y, sin(p1) * sin(a0) * radii.z)
			var v11: Vector3 = center + bs * Vector3(sin(p1) * cos(a1) * radii.x, cos(p1) * radii.y, sin(p1) * sin(a1) * radii.z)
			if r == 0:
				tri(v00, v11, v10, col, center)
			elif r == rings - 1:
				tri(v00, v01, v10, col, center)
			else:
				quad(v00, v01, v11, v10, col, center)


func is_empty() -> bool:
	return _v.is_empty()


func vertex_count() -> int:
	return _v.size()


func commit() -> ArrayMesh:
	var m := ArrayMesh.new()
	if _v.is_empty():
		return m
	var arr: Array = []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = _v
	arr[Mesh.ARRAY_NORMAL] = _n
	arr[Mesh.ARRAY_COLOR] = _c
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	return m


## Material partilhado para malhas com cores por vértice.
static var _vc_mat: Dictionary = {}

static func vc_material(emissive: bool = false) -> StandardMaterial3D:
	var key: String = str(Settings.quality) + ("e" if emissive else "n")
	if _vc_mat.has(key):
		return _vc_mat[key]
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 0.6
	m.metallic = 0.1
	if Settings.quality == 0:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
	if emissive:
		m.emission_enabled = true
		m.emission = Color(1, 1, 1)
		m.emission_energy_multiplier = 1.4
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_vc_mat[key] = m
	return m
