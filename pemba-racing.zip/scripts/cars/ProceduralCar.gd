class_name ProceduralCar
extends RefCounted
## Cria o modelo 3D de cada carro por código. São 10 desenhos diferentes (KINDS): cada um tem silhueta própria
## (cupé, hatchback, muscle, pick-up, SUV, buggy, drift, super-desportivo, fórmula, hiper-carro).
## O carro inteiro é feito de poucas malhas (pintura, detalhes, luzes e 4 rodas) para correr leve em telemóveis fracos.
## Convenção do Godot: a frente do carro aponta para -Z. Secções: [z (fração do comprimento), meia-largura (fração), y_baixo, y_cima].

const KINDS := {
	"gt": {
		"body": [[-0.5, 0.78, 0.25, 0.46], [-0.42, 0.95, 0.22, 0.58], [-0.2, 1.0, 0.20, 0.66], [0.1, 1.0, 0.20, 0.72], [0.38, 1.0, 0.22, 0.74], [0.5, 0.92, 0.26, 0.70]],
		"cab": [[-0.14, 0.78, 0.70, 0.74], [-0.02, 0.70, 0.70, 1.14], [0.18, 0.66, 0.72, 1.12], [0.36, 0.72, 0.72, 0.78]]},
	"hatch": {
		"body": [[-0.5, 0.80, 0.28, 0.55], [-0.40, 0.96, 0.26, 0.68], [-0.2, 1.0, 0.26, 0.78], [0.2, 1.0, 0.26, 0.82], [0.5, 0.96, 0.30, 0.86]],
		"cab": [[-0.22, 0.82, 0.80, 0.84], [-0.12, 0.78, 0.80, 1.42], [0.30, 0.76, 0.82, 1.44], [0.48, 0.84, 0.82, 0.96]]},
	"muscle": {
		"body": [[-0.5, 0.92, 0.30, 0.62], [-0.38, 1.0, 0.28, 0.82], [-0.1, 1.0, 0.28, 0.86], [0.3, 1.0, 0.28, 0.88], [0.5, 0.96, 0.30, 0.86]],
		"cab": [[0.0, 0.82, 0.86, 0.90], [0.10, 0.76, 0.86, 1.34], [0.28, 0.76, 0.86, 1.32], [0.38, 0.84, 0.86, 0.92]]},
	"pickup": {
		"body": [[-0.5, 0.92, 0.46, 0.88], [-0.40, 1.0, 0.42, 1.06], [-0.04, 1.0, 0.42, 1.10], [0.0, 1.0, 0.46, 0.98], [0.5, 1.0, 0.46, 0.98]],
		"cab": [[-0.14, 0.86, 1.10, 1.14], [-0.04, 0.82, 1.10, 1.78], [0.12, 0.82, 1.12, 1.78], [0.19, 0.86, 1.12, 1.18]]},
	"suv": {
		"body": [[-0.5, 0.92, 0.42, 0.96], [-0.42, 1.0, 0.40, 1.14], [0.0, 1.0, 0.40, 1.18], [0.5, 1.0, 0.42, 1.16]],
		"cab": [[-0.30, 0.86, 1.16, 1.22], [-0.22, 0.84, 1.16, 1.96], [0.44, 0.84, 1.16, 1.96], [0.5, 0.86, 1.16, 1.24]]},
	"buggy": {
		"body": [[-0.5, 0.45, 0.50, 0.66], [-0.28, 0.62, 0.46, 0.74], [0.1, 0.70, 0.46, 0.76], [0.5, 0.60, 0.48, 0.80]],
		"cab": []},
	"drift": {
		"body": [[-0.5, 0.86, 0.28, 0.52], [-0.42, 1.0, 0.24, 0.62], [-0.2, 1.0, 0.22, 0.66], [0.25, 1.0, 0.24, 0.70], [0.5, 0.95, 0.28, 0.72]],
		"cab": [[-0.10, 0.78, 0.68, 0.72], [0.0, 0.74, 0.68, 1.14], [0.24, 0.72, 0.70, 1.12], [0.32, 0.78, 0.70, 0.74]]},
	"super": {
		"body": [[-0.5, 0.82, 0.20, 0.34], [-0.38, 1.0, 0.18, 0.46], [-0.1, 1.0, 0.18, 0.60], [0.2, 1.0, 0.20, 0.74], [0.5, 0.90, 0.24, 0.76]],
		"cab": [[-0.18, 0.76, 0.52, 0.56], [-0.04, 0.68, 0.56, 1.02], [0.14, 0.64, 0.72, 1.02], [0.30, 0.70, 0.76, 0.80]]},
	"formula": {
		"body": [[-0.5, 0.10, 0.20, 0.30], [-0.36, 0.16, 0.18, 0.38], [-0.08, 0.26, 0.18, 0.44], [0.18, 0.30, 0.20, 0.52], [0.5, 0.18, 0.24, 0.40]],
		"cab": []},
	"hyper": {
		"body": [[-0.5, 0.86, 0.18, 0.30], [-0.36, 1.0, 0.16, 0.44], [-0.1, 1.0, 0.16, 0.56], [0.25, 0.98, 0.20, 0.62], [0.5, 0.80, 0.26, 0.58]],
		"cab": [[-0.15, 0.72, 0.46, 0.50], [-0.02, 0.62, 0.50, 1.00], [0.2, 0.58, 0.56, 0.94], [0.34, 0.50, 0.58, 0.66]]},
}

const GLASS := Color(0.06, 0.10, 0.16)
const DARKC := Color(0.04, 0.04, 0.05)
const LIGHTC := Color(1, 1, 0.92)
const TAILC := Color(1.0, 0.06, 0.06)
static var _blob_tex: ImageTexture = null


static func _secs(arr: Array, L: float, W: float) -> Array:
	var out: Array = []
	for s in arr:
		out.append(Vector4(float(s[0]) * L, float(s[1]) * W * 0.5, float(s[2]), float(s[3])))
	return out


static func _wing(d: MeshKit, p: MeshKit, x: float, y: float, z: float, width: float, chord: float, stand: float, plates: bool = true) -> void:
	d.box(Vector3(x, y, z), Vector3(width, 0.05, chord), DARKC)
	for sx in [-0.28, 0.28]:
		d.box(Vector3(x + sx * width, y - stand * 0.5, z), Vector3(0.06, stand, 0.10), DARKC)
	if plates:
		for sx in [-0.5, 0.5]:
			d.box(Vector3(x + sx * width, y + 0.04, z), Vector3(0.04, 0.22, chord * 1.05), DARKC)


static func _blob(L: float, W: float) -> MeshInstance3D:
	if _blob_tex == null:
		var img := Image.create(64, 64, false, Image.FORMAT_RGBA8)
		for yy in 64:
			for xx in 64:
				var dd: float = Vector2(xx - 31.5, yy - 31.5).length() / 32.0
				img.set_pixel(xx, yy, Color(0, 0, 0, clampf(1.0 - dd, 0.0, 1.0) * 0.55))
		_blob_tex = ImageTexture.create_from_image(img)
	var mi := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(W * 1.5, L * 1.3)
	q.orientation = PlaneMesh.FACE_Y
	mi.mesh = q
	var m := StandardMaterial3D.new()
	m.albedo_texture = _blob_tex
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	mi.material_override = m
	mi.position = Vector3(0, 0.04, 0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return mi


static func _mesh_node(parent: Node3D, kit: MeshKit, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = kit.commit()
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if Settings.shadows_enabled() else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


static func build(def: Dictionary, sv: Dictionary) -> CarVisual:
	var v := CarVisual.new()
	v.body_root = Node3D.new()
	v.add_child(v.body_root)
	var L: float = def["len"]
	var W: float = def["wid"]
	var R: float = def["wr"]
	var kind: String = str(def["kind"])
	var spec: Dictionary = KINDS[kind]
	v.wheel_radius = R
	var finish: int = int(sv["finish"])
	var color: Color = CarSelection.COLORS[int(sv["color"])]
	var P := MeshKit.new()    # pintura (cor do jogador)
	var D := MeshKit.new()    # detalhes (vidros, preto, riscas)
	var G := MeshKit.new()    # luzes (brilham)
	var white := Color(1, 1, 1)

	# --- Carroçaria e cabine ---
	var body: Array = _secs(spec["body"], L, W)
	P.loft(body, white)
	var top: float = 0.0
	for s in body:
		top = maxf(top, (s as Vector4).w)
	var cab_top: float = top
	var cab_zmin: float = 0.0
	var cab_zmax: float = 0.0
	if not (spec["cab"] as Array).is_empty():
		var cab: Array = _secs(spec["cab"], L, W)
		D.loft(cab, GLASS)
		cab_top = 0.0
		cab_zmin = 1e9
		cab_zmax = -1e9
		for s in cab:
			var c4: Vector4 = s
			cab_top = maxf(cab_top, c4.w)
			cab_zmin = minf(cab_zmin, c4.x)
			cab_zmax = maxf(cab_zmax, c4.x)
		# tejadilho pintado
		var zr0: float = (cab[1] as Vector4).x
		var zr1: float = (cab[cab.size() - 2] as Vector4).x
		P.box(Vector3(0, cab_top + 0.02, (zr0 + zr1) * 0.5), Vector3((cab[1] as Vector4).y * 1.9, 0.06, absf(zr1 - zr0) + 0.1), white)
	# faróis e luzes traseiras
	var nose: Vector4 = body[0]
	var tail: Vector4 = body[body.size() - 1]
	if kind != "formula" and kind != "buggy":
		for sx in [-1.0, 1.0]:
			G.box(Vector3(sx * minf(W * 0.30, nose.y * 0.75), (nose.z + nose.w) * 0.5 + 0.03, nose.x + 0.02), Vector3(0.34, 0.09, 0.06), LIGHTC)
		G.box(Vector3(0, (tail.z + tail.w) * 0.5 + 0.04, tail.x - 0.01), Vector3(tail.y * 1.7, 0.08, 0.05), TAILC)
	# para-choques escuro
	D.box(Vector3(0, nose.z + 0.04, nose.x - 0.02), Vector3(nose.y * 2.05, 0.10, 0.08), DARKC)
	D.box(Vector3(0, tail.z + 0.04, tail.x + 0.02), Vector3(tail.y * 2.05, 0.10, 0.08), DARKC)

	# --- Extras de cada tipo ---
	match kind:
		"gt":
			D.box(Vector3(0, 0.20, -L * 0.5 - 0.06), Vector3(W * 1.0, 0.05, 0.42), DARKC)
			_wing(D, P, 0, top + 0.28, L * 0.5 - 0.25, W * 0.92, 0.42, 0.28, false)
		"hatch":
			D.box(Vector3(0, cab_top + 0.12, L * 0.5 - 0.12), Vector3(W * 0.78, 0.05, 0.30), DARKC)
			D.box(Vector3(0, 0.30, -L * 0.5 - 0.03), Vector3(W * 0.9, 0.05, 0.25), DARKC)
		"muscle":
			D.box(Vector3(0, 0.90, -L * 0.22), Vector3(0.62, 0.14, 0.80), DARKC)
			for sx in [-0.16, 0.16]:
				D.box(Vector3(sx * W, 0.885, -L * 0.1), Vector3(0.20, 0.014, L * 0.9), white)
			D.box(Vector3(0, 0.93, L * 0.5 - 0.15), Vector3(W * 0.9, 0.10, 0.32), DARKC)
		"pickup":
			D.box(Vector3(0, 1.0, L * 0.25), Vector3(W * 0.78, 0.04, L * 0.44), Color(0.12, 0.12, 0.13))
			for sx in [-1.0, 1.0]:
				D.box(Vector3(sx * W * 0.5, 1.06, L * 0.25), Vector3(0.06, 0.16, L * 0.5), DARKC)
				D.box(Vector3(sx * (W * 0.44), 0.62, -L * 0.5 - 0.1), Vector3(0.07, 0.5, 0.07), DARKC)
			D.box(Vector3(0, 0.78, -L * 0.5 - 0.12), Vector3(W * 0.9, 0.08, 0.08), DARKC)
			G.box(Vector3(0, cab_top + 0.1, -L * 0.04), Vector3(W * 0.55, 0.08, 0.10), LIGHTC)
			D.box(Vector3(0, cab_top + 0.04, -L * 0.04), Vector3(W * 0.6, 0.06, 0.16), DARKC)
		"suv":
			for sx in [-0.34, 0.34]:
				D.box(Vector3(sx * W, cab_top + 0.07, L * 0.07), Vector3(0.05, 0.06, L * 0.62), DARKC)
			for k in 4:
				D.box(Vector3(0, cab_top + 0.07, L * (-0.18 + k * 0.17)), Vector3(W * 0.70, 0.04, 0.05), DARKC)
			D.box(Vector3(0, 0.62, -L * 0.5 - 0.1), Vector3(W * 0.95, 0.10, 0.10), DARKC)
			D.box(Vector3(W * 0.42, 1.6, -L * 0.2), Vector3(0.05, 0.7, 0.07), DARKC)
		"buggy":
			var hw: float = W * 0.5 * 0.55
			# gaiola de proteção
			for sx in [-1.0, 1.0]:
				for zz in [-0.05, 0.28]:
					D.box(Vector3(sx * hw, 1.15, L * zz), Vector3(0.07, 0.8, 0.07), DARKC)
				D.box(Vector3(sx * hw, 1.55, L * 0.115), Vector3(0.07, 0.07, L * 0.4), DARKC)
				D.box(Vector3(sx * hw, 1.15, L * 0.115), Vector3(0.07, 0.07, L * 0.4), DARKC, Vector3(0.7, 0, 0))
			D.box(Vector3(0, 1.55, -L * 0.05), Vector3(hw * 2.0, 0.07, 0.07), DARKC)
			D.box(Vector3(0, 1.55, L * 0.28), Vector3(hw * 2.0, 0.07, 0.07), DARKC)
			D.box(Vector3(0, 0.95, L * 0.08), Vector3(0.7, 0.14, 0.5), Color(0.15, 0.15, 0.18))   # banco
			D.box(Vector3(0, 1.2, L * 0.20), Vector3(0.7, 0.5, 0.12), Color(0.15, 0.15, 0.18))
			D.box(Vector3(0, 0.95, L * 0.42), Vector3(0.9, 0.5, 0.6), Color(0.3, 0.3, 0.33))     # motor
			for sx in [-1.0, 1.0]:                                                                  # guarda-lamas
				P.box(Vector3(sx * W * 0.5, R * 1.7, -L * 0.30), Vector3(0.5, 0.06, 1.1), white)
				P.box(Vector3(sx * W * 0.5, R * 1.7, L * 0.30), Vector3(0.5, 0.06, 1.1), white)
			G.box(Vector3(0, 0.95, -L * 0.5 + 0.02), Vector3(0.9, 0.12, 0.06), LIGHTC)
			G.box(Vector3(0, 0.95, L * 0.5 + 0.1), Vector3(0.7, 0.08, 0.05), TAILC)
		"drift":
			D.box(Vector3(0, 0.20, -L * 0.5 - 0.08), Vector3(W * 1.02, 0.05, 0.40), DARKC)
			_wing(D, P, 0, top + 0.62, L * 0.5 - 0.1, W * 1.0, 0.50, 0.58)
			for sx in [-1.0, 1.0]:                                                                  # alargadores de guarda-lamas
				P.box(Vector3(sx * (W * 0.5 + 0.05), 0.48, -L * float(def["fa"]) * 0.5), Vector3(0.20, 0.20, 1.15), white)
				P.box(Vector3(sx * (W * 0.5 + 0.05), 0.50, L * float(def["ra"]) * 0.5), Vector3(0.22, 0.22, 1.25), white)
		"super":
			for sx in [-1.0, 1.0]:
				D.box(Vector3(sx * W * 0.5, 0.52, L * 0.06), Vector3(0.06, 0.20, 0.7), DARKC)
			for k in 3:
				D.box(Vector3(0, 0.77, L * (0.36 + k * 0.045)), Vector3(W * 0.5, 0.012, 0.05), DARKC)
			D.box(Vector3(0, 0.18, -L * 0.5 - 0.1), Vector3(W * 1.02, 0.05, 0.5), DARKC)
			_wing(D, P, 0, 1.0, L * 0.5 - 0.1, W * 0.96, 0.46, 0.25)
			D.box(Vector3(0, 0.26, L * 0.5), Vector3(W * 0.8, 0.14, 0.35), DARKC)
		"formula":
			var track: float = W * 0.5
			# asas, pontos laterais e cockpit
			D.box(Vector3(0, 0.17, -L * 0.5 - 0.15), Vector3(W * 0.95, 0.05, 0.55), DARKC)
			for sx in [-1.0, 1.0]:
				D.box(Vector3(sx * W * 0.47, 0.27, -L * 0.5 - 0.15), Vector3(0.04, 0.25, 0.6), DARKC)
				P.box(Vector3(sx * 0.46, 0.38, L * 0.02), Vector3(0.40, 0.30, L * 0.30), white)
				D.box(Vector3(sx * W * 0.5 * 0.97, 0.9, L * 0.5 - 0.1), Vector3(0.04, 0.5, 0.6), DARKC)
			D.box(Vector3(0, 1.05, L * 0.5 - 0.1), Vector3(W * 0.97, 0.05, 0.40), DARKC)
			D.box(Vector3(0, 0.82, L * 0.5 - 0.1), Vector3(W * 0.97, 0.05, 0.55), DARKC)
			D.box(Vector3(0, 0.62, L * 0.5 - 0.1), Vector3(0.10, 0.5, 0.4), DARKC)
			D.box(Vector3(0, 0.56, -L * 0.04), Vector3(0.42, 0.10, 0.9), Color(0.1, 0.1, 0.12))
			D.box(Vector3(0, 0.74, -L * 0.03), Vector3(0.26, 0.26, 0.28), Color(1.0, 0.85, 0.1))  # capacete
			P.box(Vector3(0, 0.78, L * 0.20), Vector3(0.30, 0.55, 0.50), white)                 # entrada de ar
			D.box(Vector3(0, 0.90, -L * 0.06), Vector3(0.05, 0.05, 0.7), DARKC)                 # halo
			G.box(Vector3(0, 0.30, -L * 0.5 + 0.02), Vector3(0.30, 0.05, 0.05), LIGHTC)
			G.box(Vector3(0, 0.40, L * 0.5 + 0.02), Vector3(0.30, 0.06, 0.04), TAILC)
			D.box(Vector3(-track + 0.0, 0.36, -L * float(def["fa"]) * 0.5), Vector3(0.10, 0.06, 0.06), DARKC)
		"hyper":
			D.box(Vector3(0, 0.15, -L * 0.5 - 0.12), Vector3(W * 1.04, 0.04, 0.6), DARKC)
			G.box(Vector3(0, 0.32, -L * 0.5 + 0.01), Vector3(W * 0.82, 0.03, 0.05), Color(0.2, 0.8, 1.0))
			D.box(Vector3(0, 0.88, L * 0.22), Vector3(0.05, 0.55, 1.5), DARKC)               # barbatana central
			_wing(D, P, 0, 1.12, L * 0.5 - 0.05, W * 1.0, 0.55, 0.45)
			D.box(Vector3(0, 0.24, L * 0.5 + 0.02), Vector3(W * 0.8, 0.14, 0.4), DARKC)
			for sx in [-1.0, 1.0]:
				D.box(Vector3(sx * W * 0.5, 0.40, -L * 0.05), Vector3(0.05, 0.16, 0.8), DARKC)
			G.box(Vector3(0, 0.62, L * 0.5), Vector3(W * 0.6, 0.03, 0.04), TAILC)
	# riscas de corrida (pintura 3)
	if finish == 3 and kind != "formula":
		var ytop: float = top + 0.012
		for sx in [-1.0, 1.0]:
			D.box(Vector3(sx * W * 0.07, ytop + 0.02, 0.0), Vector3(W * 0.10, 0.012, L * 0.55), white)

	# --- Malhas finais ---
	var rough: float = [0.22, 0.85, 0.25, 0.22][finish]
	var metal: float = [0.30, 0.0, 0.95, 0.30][finish]
	var paint_mat := StandardMaterial3D.new()
	paint_mat.albedo_color = color
	paint_mat.roughness = rough
	paint_mat.metallic = metal
	paint_mat.vertex_color_use_as_albedo = true
	if Settings.quality == 0:
		paint_mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
	_mesh_node(v.body_root, P, paint_mat)
	_mesh_node(v.body_root, D, MeshKit.vc_material(false))
	_mesh_node(v.body_root, G, MeshKit.vc_material(true))

	# --- Rodas: pivô (direção) -> spinner (rotação) -> uma só malha (pneu + jante + raios) ---
	var rim_style: int = int(sv["rim"])
	var rim_color: Color = [Color(0.80, 0.82, 0.86), Color(0.75, 0.77, 0.82), Color(0.95, 0.75, 0.2), Color(0.95, 0.95, 0.97), Color(0.1, 0.9, 1.0)][rim_style]
	var ww: float = def["ww"]
	var wk := MeshKit.new()
	wk.cyl_x(Vector3.ZERO, R, ww, Color(0.025, 0.025, 0.025), 14)
	wk.cyl_x(Vector3.ZERO, R * 0.62, ww * 1.03, rim_color if rim_style == 0 or rim_style == 4 else Color(0.06, 0.06, 0.08), 12)
	var bars: int = [0, 3, 4, 3, 0][rim_style]
	for k in bars:
		var a: float = PI * k / bars
		for sx in [-1.0, 1.0]:
			wk.box(Vector3(sx * ww * 0.51, 0, 0), Vector3(0.02, 0.05, R * 1.2), rim_color, Vector3(a, 0, 0))
	wk.cyl_x(Vector3.ZERO, R * 0.18, ww * 1.06, Color(0.08, 0.08, 0.1), 8)
	var wheel_mesh: ArrayMesh = wk.commit()
	var wmat := MeshKit.vc_material(false)
	var xs: float = W * 0.5 - ww * 0.5 + (0.08 if kind == "buggy" or kind == "formula" else -0.04)
	var zf: float = -L * 0.5 * float(def["fa"])
	var zr: float = L * 0.5 * float(def["ra"])
	var pos_x: Array = [-xs, xs, -xs, xs]
	var pos_z: Array = [zf, zf, zr, zr]
	for i in 4:
		var pivot := Node3D.new()
		pivot.position = Vector3(pos_x[i], R, pos_z[i])
		v.add_child(pivot)
		var spin := Node3D.new()
		pivot.add_child(spin)
		var mi := MeshInstance3D.new()
		mi.mesh = wheel_mesh
		mi.material_override = wmat
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		spin.add_child(mi)
		v.pivots.append(pivot)
		v.spinners.append(spin)
	v.add_child(_blob(L, W))
	v.eye = Vector3(0, cab_top - 0.22, (cab_zmin + (cab_zmax - cab_zmin) * 0.38) if cab_zmax > cab_zmin else L * 0.1)
	if kind == "formula" or kind == "buggy":
		v.eye = Vector3(0, 1.0 if kind == "formula" else 1.35, L * 0.0)
	v.top_height = cab_top
	return v
