class_name CarVisual
extends Node3D
## Modelo 3D de um carro (criado por ProceduralCar). Guarda as rodas para animação.

var body_root: Node3D
var pivots: Array = []     # 4 pivôs de roda (FL, FR, RL, RR): os da frente viram com a direção
var spinners: Array = []   # 4 nós que rodam com a velocidade
var wheel_radius: float = 0.34
var eye := Vector3(0, 1.3, 0.15)  # posição da câmara interior
var top_height: float = 1.2
