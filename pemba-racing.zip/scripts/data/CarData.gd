class_name CarData
extends RefCounted
## Os 10 carros do jogo. São 10 TIPOS diferentes de veículo (forma e condução):
## GT, hatchback, muscle car, pick-up, SUV 4x4, buggy, carro de drift, super-desportivo, fórmula e hiper-carro.
## Para adicionar um carro novo basta acrescentar uma linha em ALL e (se for um tipo novo) um desenho em ProceduralCar.
##
## kind  = desenho 3D (ProceduralCar.KINDS)         kmh   = velocidade máxima base
## accel = aceleração (m/s²)                         brake = travagem (m/s²)
## steer = rotação máxima da direção (°/s)           grip  = aderência lateral (0-1): baixo = derrapa
## down  = força descendente (aderência extra em velocidade)    drive = tração: rwd / fwd / awd
## off   = rendimento fora da estrada (0 mau .. 1 excelente)    len/wid = tamanho    wr/ww = raio e largura das rodas
## fa/ra = posição dos eixos (fração do meio comprimento)

const ALL: Array = [
	{"id": "pemba_gt", "kind": "gt", "name": "PEMBA GT - PEMBA GTR", "tag": ["Cupé GT equilibrado. Ideal para começar.", "Balanced GT coupe. Great to start."], "price": 0, "kmh": 205.0, "accel": 7.0, "brake": 17.0, "steer": 95.0, "grip": 0.90, "mass": 1300.0, "down": 0.15, "drive": "rwd", "off": 0.45, "len": 4.5, "wid": 1.90, "wr": 0.34, "ww": 0.26, "fa": 0.62, "ra": 0.64},
	{"id": "maputo_s", "kind": "hatch", "name": "MAPUTO S - ACABA DE MI MATA", "tag": ["Hatchback leve e ágil nas curvas.", "Light, agile hatchback."], "price": 0, "kmh": 178.0, "accel": 7.6, "brake": 16.0, "steer": 120.0, "grip": 0.96, "mass": 1000.0, "down": 0.0, "drive": "fwd", "off": 0.55, "len": 3.9, "wid": 1.75, "wr": 0.31, "ww": 0.22, "fa": 0.64, "ra": 0.62},
	{"id": "luanda_x", "kind": "muscle", "name": "LUANDA X - DODGE", "tag": ["Muscle car: força bruta, rabo solto.", "Muscle car: raw torque, loose tail."], "price": 1800, "kmh": 225.0, "accel": 9.2, "brake": 15.0, "steer": 82.0, "grip": 0.78, "mass": 1650.0, "down": 0.0, "drive": "rwd", "off": 0.40, "len": 4.9, "wid": 1.98, "wr": 0.36, "ww": 0.30, "fa": 0.62, "ra": 0.62},
	{"id": "zambezi_rs", "kind": "pickup", "name": "ZAMBEZI RS - RABO DO PATO", "tag": ["Pick-up pesada 4x4: aguenta tudo.", "Heavy 4x4 pickup: handles anything."], "price": 2600, "kmh": 170.0, "accel": 5.8, "brake": 16.0, "steer": 85.0, "grip": 0.85, "mass": 2100.0, "down": 0.0, "drive": "awd", "off": 0.88, "len": 5.2, "wid": 2.00, "wr": 0.47, "ww": 0.30, "fa": 0.66, "ra": 0.62},
	{"id": "kilimanjaro", "kind": "suv", "name": "KILIMANJARO - HIACE TOYATE", "tag": ["SUV 4x4 alto, estável, travões fortes.", "Tall, stable 4x4 SUV, strong brakes."], "price": 3400, "kmh": 192.0, "accel": 6.4, "brake": 20.0, "steer": 88.0, "grip": 0.95, "mass": 1950.0, "down": 0.05, "drive": "awd", "off": 0.80, "len": 4.7, "wid": 2.00, "wr": 0.44, "ww": 0.28, "fa": 0.62, "ra": 0.64},
	{"id": "serengeti", "kind": "buggy", "name": "SERENGET - FÓRMULA 2", "tag": ["Buggy leve: voa na terra, salta tudo.", "Light buggy: flies on dirt."], "price": 4500, "kmh": 165.0, "accel": 8.4, "brake": 14.0, "steer": 128.0, "grip": 0.92, "mass": 700.0, "down": 0.0, "drive": "rwd", "off": 1.0, "len": 3.6, "wid": 2.00, "wr": 0.52, "ww": 0.34, "fa": 0.68, "ra": 0.60},
	{"id": "cabinda_r", "kind": "drift", "name": "CABINDA R - FERRARI", "tag": ["Carro de drift: derrapa com estilo.", "Drift car: slides with style."], "price": 5600, "kmh": 222.0, "accel": 8.4, "brake": 18.0, "steer": 120.0, "grip": 0.70, "mass": 1250.0, "down": 0.10, "drive": "rwd", "off": 0.40, "len": 4.5, "wid": 1.96, "wr": 0.34, "ww": 0.30, "fa": 0.62, "ra": 0.64},
	{"id": "nacala_gtr", "kind": "super", "name": "NACALA GTR - LAMBORGHINI", "tag": ["Super-desportivo baixo e largo.", "Low, wide supercar."], "price": 7200, "kmh": 262.0, "accel": 8.6, "brake": 22.0, "steer": 100.0, "grip": 0.96, "mass": 1350.0, "down": 0.35, "drive": "awd", "off": 0.35, "len": 4.5, "wid": 2.02, "wr": 0.35, "ww": 0.32, "fa": 0.62, "ra": 0.66},
	{"id": "benguela_v12", "kind": "formula", "name": "BENGALA V12 - FÓRMULA 1", "tag": ["Fórmula de rodas expostas: máxima aderência.", "Open-wheel formula: maximum downforce."], "price": 9000, "kmh": 296.0, "accel": 10.5, "brake": 26.0, "steer": 112.0, "grip": 1.00, "mass": 780.0, "down": 0.60, "drive": "rwd", "off": 0.20, "len": 5.0, "wid": 2.10, "wr": 0.36, "ww": 0.36, "fa": 0.66, "ra": 0.70},
	{"id": "pemba_hyper", "kind": "hyper", "name": "PEMBA HYPR - MARIDÃO.3Y", "tag": ["Hiper-carro: o rei da pista.", "Hypercar: king of the track."], "price": 12000, "kmh": 305.0, "accel": 10.2, "brake": 25.0, "steer": 106.0, "grip": 0.98, "mass": 1300.0, "down": 0.45, "drive": "awd", "off": 0.30, "len": 4.7, "wid": 2.04, "wr": 0.35, "ww": 0.34, "fa": 0.62, "ra": 0.66},
]

# Valores máximos usados para desenhar as barras da garagem
const MAX_KMH := 340.0
const MAX_ACCEL := 12.0
const MAX_BRAKE := 30.0
const MAX_STEER := 135.0


static func by_id(id: String) -> Dictionary:
	for c in ALL:
		if c["id"] == id:
			return c
	return ALL[0]


static func index_of(id: String) -> int:
	for i in ALL.size():
		if ALL[i]["id"] == id:
			return i
	return 0


static func tag(def: Dictionary) -> String:
	var t: Array = def["tag"]
	return t[1] if Settings.language == 1 else t[0]
