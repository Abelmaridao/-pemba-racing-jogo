class_name TrackData
extends RefCounted
## As pistas do jogo. Cada pista é um circuito fechado definido por uma curva suave (forma + cores + cenário).
## shape = [[harmónica, amplitude, fase], ...] sobre um círculo de raio "base"; sx/sz esticam a forma.
## tunnels (opcional) = nº de túneis decorativos ao longo da pista. wrongway (opcional) = true para pôr
## sinais de perigo/contramão numa curva (aviso visual; a corrida continua sempre no mesmo sentido).
## Para criar uma pista nova basta acrescentar uma entrada em ALL. As primeiras 5 são as do campeonato
## (ChampionshipManager usa sempre as 5 primeiras, por esta ordem) — as pistas extra ficam só na corrida rápida.
## Nota: a forma da SAVANA tinha só curvas para um lado; foi ajustada (harmónico extra) para ter curvas
## à esquerda E à direita, tal como as outras pistas.

const ALL: Array = [
	{"id": "savana", "name": ["SAVANA VERDE", "GREEN SAVANNA"], "level": [1, "FÁCIL", "EASY"],
	 "base": 260.0, "shape": [[2, 0.09, 0.3], [3, 0.08, 1.2], [4, 0.05, 4.0]], "sx": 1.25, "sz": 0.9, "width": 17.0, "laps": 3,
	 "ground": Color(0.24, 0.52, 0.20), "road": Color(0.20, 0.21, 0.23), "sky_top": Color(0.28, 0.52, 0.88), "horizon": Color(0.80, 0.90, 0.97),
	 "sun": 1.1, "ambient": 0.9, "props": "trees", "night": false},
	{"id": "deserto", "name": ["DESERTO DE PEMBA", "PEMBA DESERT"], "level": [2, "MÉDIO", "MEDIUM"],
	 "base": 300.0, "shape": [[3, 0.14, 0.5], [5, 0.05, 2.0]], "sx": 1.1, "sz": 1.0, "width": 16.0, "laps": 3,
	 "ground": Color(0.80, 0.66, 0.38), "road": Color(0.24, 0.23, 0.22), "sky_top": Color(0.35, 0.60, 0.92), "horizon": Color(0.98, 0.88, 0.70),
	 "sun": 1.3, "ambient": 1.0, "props": "cacti", "night": false},
	{"id": "cidade", "name": ["CIDADE NOTURNA", "NIGHT CITY"], "level": [3, "MÉDIO", "MEDIUM"],
	 "base": 240.0, "shape": [[4, 0.13, 0.0], [2, 0.10, 1.0]], "sx": 1.2, "sz": 1.0, "width": 16.0, "laps": 3,
	 "ground": Color(0.10, 0.11, 0.14), "road": Color(0.10, 0.10, 0.12), "sky_top": Color(0.02, 0.03, 0.10), "horizon": Color(0.10, 0.08, 0.22),
	 "sun": 0.35, "ambient": 0.9, "props": "city", "night": true},
	{"id": "gelo", "name": ["MONTANHA GELADA", "ICY MOUNTAIN"], "level": [4, "DIFÍCIL", "HARD"],
	 "base": 280.0, "shape": [[3, 0.18, 1.0], [5, 0.08, 0.3], [7, 0.03, 2.0]], "sx": 1.0, "sz": 1.0, "width": 15.0, "laps": 3,
	 "ground": Color(0.90, 0.94, 0.98), "road": Color(0.28, 0.30, 0.34), "sky_top": Color(0.45, 0.62, 0.85), "horizon": Color(0.88, 0.93, 0.98),
	 "sun": 1.0, "ambient": 1.1, "props": "pines", "night": false},
	{"id": "final", "name": ["CIRCUITO FINAL", "FINAL CIRCUIT"], "level": [5, "EXPERT", "EXPERT"],
	 "base": 330.0, "shape": [[2, 0.18, 0.2], [4, 0.10, 2.1], [6, 0.04, 0.7]], "sx": 1.15, "sz": 0.95, "width": 15.0, "laps": 3,
	 "ground": Color(0.30, 0.20, 0.16), "road": Color(0.18, 0.17, 0.18), "sky_top": Color(0.50, 0.28, 0.45), "horizon": Color(1.0, 0.62, 0.30),
	 "sun": 0.9, "ambient": 0.85, "props": "rocks", "night": false},
	{"id": "montanha_passo", "name": ["PASSO DA MONTANHA", "MOUNTAIN PASS"], "level": [6, "MUITO DIFÍCIL", "VERY HARD"],
	 "base": 300.0, "shape": [[3, 0.16, 0.4], [5, 0.07, 2.2], [2, 0.06, 4.0]], "sx": 1.05, "sz": 1.0, "width": 14.0, "laps": 3,
	 "ground": Color(0.34, 0.40, 0.32), "road": Color(0.20, 0.19, 0.20), "sky_top": Color(0.40, 0.58, 0.82), "horizon": Color(0.82, 0.88, 0.95),
	 "sun": 1.1, "ambient": 0.95, "props": "mountains", "night": false, "tunnels": 2, "wrongway": true},
	{"id": "canyon_contramao", "name": ["DESFILADEIRO CONTRAMÃO", "WRONG-WAY CANYON"], "level": [7, "SUPER DIFÍCIL", "SUPER HARD"],
	 "base": 320.0, "shape": [[4, 0.15, 1.0], [3, 0.09, 3.0], [6, 0.05, 0.5]], "sx": 1.1, "sz": 0.95, "width": 14.0, "laps": 3,
	 "ground": Color(0.48, 0.28, 0.18), "road": Color(0.22, 0.19, 0.17), "sky_top": Color(0.55, 0.30, 0.22), "horizon": Color(1.0, 0.65, 0.35),
	 "sun": 1.0, "ambient": 0.9, "props": "canyon", "night": false, "tunnels": 1, "wrongway": true},
]


static func by_id(id: String) -> Dictionary:
	for t in ALL:
		if t["id"] == id:
			return t
	return ALL[0]


static func index_of(id: String) -> int:
	for i in ALL.size():
		if ALL[i]["id"] == id:
			return i
	return 0


static func tname(d: Dictionary) -> String:
	var n: Array = d["name"]
	return n[1] if Settings.language == 1 else n[0]


static func level_name(d: Dictionary) -> String:
	var l: Array = d["level"]
	return l[2] if Settings.language == 1 else l[1]
