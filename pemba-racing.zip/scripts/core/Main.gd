extends Node
## Cena principal. Os sistemas do jogo são autoloads (ver project.godot): o GameManager abre o menu sozinho.
## Argumento de linha de comandos "--selftest" corre o teste automático (ver tests/SelfTest.gd).


func _ready() -> void:
	if "--shots" in OS.get_cmdline_user_args():
		add_child(preload("res://tests/Shots.gd").new())
	if "--cars" in OS.get_cmdline_user_args():
		add_child(preload("res://tests/CarsGrid.gd").new())
	if "--griddbg" in OS.get_cmdline_user_args():
		add_child(preload("res://tests/GridDbg.gd").new())
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--mp-test="):
			add_child(preload("res://tests/MPTest.gd").new())
	if "--idledbg" in OS.get_cmdline_user_args():
		add_child(preload("res://tests/IdleDbg.gd").new())
	if "--nitrotest" in OS.get_cmdline_user_args():
		add_child(preload("res://tests/NitroTest.gd").new())
	if "--tracktest" in OS.get_cmdline_user_args():
		add_child(preload("res://tests/TrackTest.gd").new())
	if "--selftest" in OS.get_cmdline_user_args():
		var t := preload("res://tests/SelfTest.gd").new()
		add_child(t)
