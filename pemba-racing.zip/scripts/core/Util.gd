class_name U
extends RefCounted
## Ajudantes de interface e tradução. Toda a interface do jogo é construída por código com estes métodos.

const RED := Color(0.90, 0.13, 0.17)
const BLUE := Color(0.10, 0.45, 0.95)
const DARK := Color(0.04, 0.08, 0.18, 0.92)
const BLACK := Color(0.03, 0.03, 0.06, 0.92)
const GRAY := Color(0.30, 0.33, 0.40, 0.95)


## Tradução simples: U.t("português", "english"). O idioma vem das Configurações.
static func t(pt: String, en: String) -> String:
	return en if Settings.language == 1 else pt


static func box(bg: Color, radius: int = 22, border: Color = Color(0, 0, 0, 0), bw: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	s.border_color = border
	s.set_border_width_all(bw)
	s.content_margin_left = 14
	s.content_margin_right = 14
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	return s


static func button(text: String, color: Color, size: Vector2, fs: int = 40, cb: Callable = Callable()) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = size
	b.size = size
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", fs)
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(c, Color.WHITE)
	b.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.45))
	b.add_theme_stylebox_override("normal", box(color))
	b.add_theme_stylebox_override("hover", box(color.lightened(0.15)))
	b.add_theme_stylebox_override("pressed", box(color.darkened(0.25)))
	b.add_theme_stylebox_override("disabled", box(color.darkened(0.5)))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.pressed.connect(func() -> void: Audio.click())
	if cb.is_valid():
		b.pressed.connect(cb)
	return b


static func label(text: String, fs: int, color: Color = Color.WHITE, align: int = HORIZONTAL_ALIGNMENT_LEFT, outline: bool = true) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = align as HorizontalAlignment
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_color", color)
	if outline:
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
		l.add_theme_constant_override("outline_size", maxi(2, fs / 10))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


static func panel(color: Color, radius: int = 24) -> Panel:
	var p := Panel.new()
	p.add_theme_stylebox_override("panel", box(color, radius))
	return p


## Posiciona um Control. anchor: (0|0.5|1, 0|0.5|1). pos = afastamento "para dentro" a partir do canto.
static func place(c: Control, anchor: Vector2, pos: Vector2, size: Vector2) -> void:
	c.anchor_left = anchor.x
	c.anchor_right = anchor.x
	c.anchor_top = anchor.y
	c.anchor_bottom = anchor.y
	var x: float = -pos.x if anchor.x > 0.75 else pos.x
	var y: float = -pos.y if anchor.y > 0.75 else pos.y
	var left: float = x - size.x * anchor.x
	var top: float = y - size.y * anchor.y
	c.offset_left = left
	c.offset_right = left + size.x
	c.offset_top = top
	c.offset_bottom = top + size.y


static func full(c: Control) -> void:
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


static func circle_tex(d: int, color: Color) -> ImageTexture:
	var img := Image.create(d, d, false, Image.FORMAT_RGBA8)
	var r: float = d / 2.0
	for y in d:
		for x in d:
			var dist: float = Vector2(x + 0.5, y + 0.5).distance_to(Vector2(r, r))
			img.set_pixel(x, y, Color(color.r, color.g, color.b, clampf(r - dist, 0.0, 1.0)))
	return ImageTexture.create_from_image(img)


## Margens (em unidades do canvas) para evitar entalhes e câmaras do telemóvel. (esquerda, topo, direita, fundo)
static func safe_margins(node: Node) -> Vector4:
	var win := Vector2(DisplayServer.window_get_size())
	var scr := Vector2(DisplayServer.screen_get_size())
	if win.x <= 0.0 or scr.x <= 0.0:
		return Vector4.ZERO
	var sa := DisplayServer.get_display_safe_area()
	var vp: Vector2 = node.get_viewport().get_visible_rect().size
	var sx: float = vp.x / win.x
	var sy: float = vp.y / win.y
	return Vector4(
		maxf(0.0, float(sa.position.x)) * sx,
		maxf(0.0, float(sa.position.y)) * sy,
		maxf(0.0, scr.x - float(sa.end.x)) * sx,
		maxf(0.0, scr.y - float(sa.end.y)) * sy)


## Contentor de ecrã inteiro já com as margens seguras.
static func safe_root(parent: Control) -> Control:
	var m := U.safe_margins(parent)
	var c := Control.new()
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(c)
	U.full(c)
	c.offset_left = m.x + 24.0
	c.offset_top = m.y + 16.0
	c.offset_right = -(m.z + 24.0)
	c.offset_bottom = -(m.w + 16.0)
	return c


static func fmt_time(t: float) -> String:
	var m: int = int(t) / 60
	var s: float = t - m * 60.0
	return "%02d:%04.1f" % [m, s]
