extends Node
## ChampionshipManager (autoload "Championship")
## ETAPA 5 (ainda não implementado). Aqui ficará: várias corridas, pontos por posição,
## classificação geral, desbloqueio de carros e pistas e troféus.
## Nesta etapa só existe a tabela de pontos, que será usada quando o campeonato for criado.

const POINTS := [25, 18, 15, 12, 10, 8, 6, 4]
const IMPLEMENTED := false


func points_for(position: int) -> int:
	return POINTS[position - 1] if position >= 1 and position <= POINTS.size() else 0
