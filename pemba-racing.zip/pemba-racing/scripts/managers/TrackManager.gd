class_name TrackManager
extends Node3D
## TrackManager: constrói as pistas e o cenário (luz, céu, limites, colisões).
## ETAPA 1: apenas a "Pista de Testes" (arena aberta com cones e rampa) para provar a condução.
## ETAPA 2/5: aqui entram a pista com voltas e as 5 pistas finais.

var spawn_transform := Transform3D.IDENTITY


static func make_environment(top: Color, horizon: Color, ambient: float, fog: bool) -> WorldEnvironment:
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = top
	sky_mat.sky_horizon_color = horizon
	sky_mat.ground_horizon_color = horizon
	sky_mat.ground_bottom_color = horizon.darkened(0.4)
	var sky := Sky.new()
	sky.sky_material = sky_mat
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = ambient
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	if fog:
		env.fog_enabled = true
		env.fog_light_color = horizon
		env.fog_density = 0.0025
	var we := WorldEnvironment.new()
	we.environment = env
	return we


static func make_sun(energy: float = 1.1) -> DirectionalLight3D:
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -35, 0)
	sun.light_energy = energy
	sun.shadow_enabled = Settings.shadows_enabled()
	sun.directional_shadow_max_distance = 60.0
	return sun


static func _checker_texture() -> ImageTexture:
	var img := Image.create(64, 64, true, Image.FORMAT_RGBA8)
	for y in 64:
		for x in 64:
			var odd: bool = ((x / 32) + (y / 32)) % 2 == 1
			img.set_pixel(x, y, Color(0.36, 0.38, 0.42) if odd else Color(0.30, 0.32, 0.36))
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


func _static_box(size: Vector3, pos: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	body.rotation = rot
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	body.add_child(cs)
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.material_override = mat
	body.add_child(mi)
	add_child(body)
	return body


## Pista de testes: arena quadrada 400x400 com muros, cones e uma rampa.
func build_test_arena() -> void:
	add_child(make_environment(Color(0.28, 0.50, 0.85), Color(0.75, 0.85, 0.95), 0.9, true))
	add_child(make_sun())

	var ground_mat := StandardMaterial3D.new()
	ground_mat.albedo_texture = _checker_texture()
	ground_mat.uv1_scale = Vector3(100, 100, 1)
	ground_mat.roughness = 0.9
	var ground := _static_box(Vector3(400, 1, 400), Vector3(0, -0.5, 0), ground_mat)
	var gmesh: BoxMesh = (ground.get_child(1) as MeshInstance3D).mesh as BoxMesh
	gmesh.size = Vector3(400, 1, 400)
	# O BoxMesh usa UVs por face; o chão usa o topo repetido 100x100 (cada quadrado = 4 m)

	var wall_mat := StandardMaterial3D.new()
	wall_mat.albedo_color = Color(0.85, 0.12, 0.15)
	wall_mat.roughness = 0.6
	_static_box(Vector3(400, 4, 2), Vector3(0, 2, -201), wall_mat)
	_static_box(Vector3(400, 4, 2), Vector3(0, 2, 201), wall_mat)
	_static_box(Vector3(2, 4, 400), Vector3(-201, 2, 0), wall_mat)
	_static_box(Vector3(2, 4, 400), Vector3(201, 2, 0), wall_mat)

	# Linha de partida
	var line_mat := StandardMaterial3D.new()
	line_mat.albedo_color = Color(1, 1, 1)
	var line := MeshInstance3D.new()
	var lm := BoxMesh.new()
	lm.size = Vector3(14, 0.02, 0.6)
	line.mesh = lm
	line.material_override = line_mat
	line.position = Vector3(0, 0.011, 0)
	add_child(line)

	# Cones (corpos rígidos: podem ser derrubados)
	var cone_mat := StandardMaterial3D.new()
	cone_mat.albedo_color = Color(1.0, 0.45, 0.05)
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for i in 48:
		var ang: float = TAU * i / 48.0
		var rad: float = 60.0 + (i % 4) * 22.0
		_cone(Vector3(cos(ang) * rad, 0.5, sin(ang) * rad - 80.0), cone_mat)
	for i in 10:
		_cone(Vector3(-8.0 + i * 1.8, 0.5, -40.0), cone_mat)  # slalom
	# Rampa
	var ramp_mat := StandardMaterial3D.new()
	ramp_mat.albedo_color = Color(0.15, 0.35, 0.9)
	_static_box(Vector3(10, 0.6, 16), Vector3(40, 0.9, -120), ramp_mat, Vector3(deg_to_rad(-9.0), 0, 0))

	spawn_transform = Transform3D(Basis(), Vector3(0, 0.1, 30))


func _cone(pos: Vector3, mat: Material) -> void:
	var rb := RigidBody3D.new()
	rb.mass = 3.0
	rb.position = pos
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(0.6, 1.0, 0.6)
	cs.shape = shape
	rb.add_child(cs)
	var mi := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.05
	mesh.bottom_radius = 0.34
	mesh.height = 1.0
	mesh.radial_segments = 10
	mesh.rings = 1
	mi.mesh = mesh
	mi.material_override = mat
	rb.add_child(mi)
	add_child(rb)
