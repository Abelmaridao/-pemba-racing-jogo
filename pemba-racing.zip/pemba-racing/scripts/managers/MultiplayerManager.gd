extends Node
## MultiplayerManager (autoload "MP")
## ETAPA 4 (ainda não implementado). Aqui ficará a lógica da sala: lista de jogadores, anfitrião escolhe a pista,
## cada jogador escolhe o carro, contagem regressiva sincronizada, posições/velocidades dos carros, reconexão.
const IMPLEMENTED := false
