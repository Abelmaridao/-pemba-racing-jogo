extends Node
## SettingsManager (autoload "Settings")
## Configurações do jogador: qualidade gráfica, volumes, sensibilidade, tipo de controlo e idioma.
## Guardadas em user://settings.cfg e aplicadas imediatamente.

const PATH := "user://settings.cfg"

var quality: int = 1          # 0 baixa, 1 média, 2 alta
var music_vol: float = 0.7
var sfx_vol: float = 0.9
var sensitivity: float = 1.0  # 0.5 a 1.5
var control_type: int = 0     # 0 botões, 1 volante virtual, 2 inclinação do telemóvel
var language: int = 0         # 0 português, 1 inglês


func _ready() -> void:
	_load()
	apply()


func _load() -> void:
	var cf := ConfigFile.new()
	var default_q := 1
	# Telemóveis fracos começam em qualidade baixa.
	var os_name := OS.get_name()
	if os_name == "Android" or os_name == "iOS":
		var mem: Dictionary = OS.get_memory_info()
		var phys: int = int(mem.get("physical", 0))
		if phys > 0 and phys < 3_000_000_000:
			default_q = 0
	if cf.load(PATH) == OK:
		quality = int(cf.get_value("s", "quality", default_q))
		music_vol = float(cf.get_value("s", "music", 0.7))
		sfx_vol = float(cf.get_value("s", "sfx", 0.9))
		sensitivity = float(cf.get_value("s", "sens", 1.0))
		control_type = int(cf.get_value("s", "ctrl", 0))
		language = int(cf.get_value("s", "lang", 0))
	else:
		quality = default_q
		language = 1 if OS.get_locale_language() == "en" else 0


func save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("s", "quality", quality)
	cf.set_value("s", "music", music_vol)
	cf.set_value("s", "sfx", sfx_vol)
	cf.set_value("s", "sens", sensitivity)
	cf.set_value("s", "ctrl", control_type)
	cf.set_value("s", "lang", language)
	cf.save(PATH)


## Aplica qualidade gráfica e volumes.
func apply() -> void:
	Engine.max_fps = 30 if quality == 0 else 60
	var vp := get_viewport()
	if vp:
		vp.msaa_3d = Viewport.MSAA_DISABLED if quality < 2 else Viewport.MSAA_2X
	if has_node("/root/Audio"):
		Audio.refresh_volumes()


func shadows_enabled() -> bool:
	return quality >= 1


func shadow_size() -> int:
	return 1024 if quality == 1 else 2048
