extends Node
## CarSelectionManager (autoload "CarSelection")
## Compra, selecção e personalização dos carros (cores, jantes, pintura, melhorias).
## Calcula também as estatísticas finais de condução (base + melhorias).

const MAX_UPGRADE := 5

const COLORS: Array[Color] = [
	Color(0.90, 0.12, 0.16), Color(0.10, 0.40, 0.95), Color(0.05, 0.05, 0.07),
	Color(0.95, 0.95, 0.97), Color(0.98, 0.78, 0.08), Color(0.12, 0.75, 0.35),
	Color(0.95, 0.45, 0.08), Color(0.55, 0.18, 0.85), Color(0.10, 0.80, 0.85),
	Color(0.55, 0.58, 0.62)]
const RIM_NAMES := [["Clássica", "Classic"], ["Raios 5", "5 spokes"], ["Raios 8", "8 spokes"], ["Turbina", "Turbine"], ["Néon", "Neon"]]
const FINISH_NAMES := [["Brilhante", "Gloss"], ["Mate", "Matte"], ["Metálica", "Metallic"], ["Riscas", "Stripes"]]


func rim_name(i: int) -> String:
	return RIM_NAMES[i][Settings.language]


func finish_name(i: int) -> String:
	return FINISH_NAMES[i][Settings.language]


## Dados guardados de um carro (cria os valores iniciais se ainda não existirem).
func get_car(id: String) -> Dictionary:
	var cars: Dictionary = Game.save["cars"]
	if not cars.has(id):
		var def := CarData.by_id(id)
		cars[id] = {"owned": int(def["price"]) == 0, "color": 0, "rim": 0, "finish": 0,
			"up_speed": 0, "up_accel": 0, "up_brake": 0}
	return cars[id]


func stats(def: Dictionary, sv: Dictionary) -> Dictionary:
	return {
		"max_ms": float(def["kmh"]) * (1.0 + 0.04 * int(sv["up_speed"])) / 3.6,
		"accel": float(def["accel"]) * (1.0 + 0.06 * int(sv["up_accel"])),
		"brake": float(def["brake"]) * (1.0 + 0.06 * int(sv["up_brake"])),
		"steer": float(def["steer"]),
		"grip": float(def["grip"]),
		"mass": float(def["mass"]),
	}


func upgrade_cost(level: int) -> int:
	return 300 + 350 * level


func try_buy(def: Dictionary) -> bool:
	var sv := get_car(def["id"])
	var price: int = int(def["price"])
	if sv["owned"] or int(Game.save["coins"]) < price:
		return false
	Game.save["coins"] = int(Game.save["coins"]) - price
	sv["owned"] = true
	Game.save_game()
	return true


func select(def: Dictionary) -> void:
	if not get_car(def["id"])["owned"]:
		return
	Game.save["selected"] = def["id"]
	Game.save_game()


## kind: 0 velocidade, 1 aceleração, 2 travagem
func try_upgrade(def: Dictionary, kind: int) -> bool:
	var sv := get_car(def["id"])
	if not sv["owned"]:
		return false
	var key: String = ["up_speed", "up_accel", "up_brake"][kind]
	var lvl: int = int(sv[key])
	if lvl >= MAX_UPGRADE:
		return false
	var cost := upgrade_cost(lvl)
	if int(Game.save["coins"]) < cost:
		return false
	Game.save["coins"] = int(Game.save["coins"]) - cost
	sv[key] = lvl + 1
	Game.save_game()
	return true
