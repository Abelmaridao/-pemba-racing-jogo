extends Node
## Teste automático (corre sem ecrã): godot --headless --path . --fixed-fps 60 -- --selftest
## Verifica: menu, garagem (10 carros, compra, personalização, melhorias), condução (acelerar, virar, travar,
## marcha-atrás, travão de mão), câmaras, pausa e configurações. Sai com código 0 se tudo passar.

var fails: int = 0
var checks: int = 0


func ok(cond: bool, msg: String) -> void:
	checks += 1
	if cond:
		print("  OK   ", msg)
	else:
		fails += 1
		print("  FALHA ", msg)


func frames(n: int) -> void:
	for i in n:
		await get_tree().physics_frame


func _ready() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	await run()
	print("== %d verificações, %d falhas ==" % [checks, fails])
	get_tree().quit(1 if fails > 0 else 0)


func run() -> void:
	print("[menu]")
	Game.reset_save()
	Game.go_menu()
	await frames(5)
	ok(Game.state == "menu" and Game.screen is MainMenuManager, "menu principal abre")
	ok(Game.screen._buttons.size() == 6, "6 botões no menu")
	Game.screen._on_multi()
	await frames(2)
	ok(Game.screen._overlay != null, "painel Multiplayer abre")
	Game.screen.on_back()
	await frames(2)
	ok(Game.screen._overlay == null, "voltar fecha o painel")
	Game.screen._on_settings()
	await frames(2)
	ok(Game.screen._overlay != null, "painel Configurações abre")
	var lang_before: int = Settings.language
	Settings.language = 1
	Game.screen._build_ui()
	Game.screen._on_settings()
	await frames(2)
	ok(Game.screen._overlay != null, "idioma inglês reconstrói o menu")
	Settings.language = 0
	Settings.quality = 2
	Settings.apply()
	Settings.quality = 0
	Settings.apply()
	Settings.save()
	ok(Engine.max_fps == 30, "qualidade baixa limita a 30 FPS")
	Settings.quality = 1
	Settings.apply()
	ok(Engine.max_fps == 60, "qualidade média usa 60 FPS")

	print("[garagem]")
	Game.go_garage()
	await frames(5)
	ok(Game.state == "garage" and Game.screen is GarageManager, "garagem abre")
	ok(CarData.ALL.size() == 10, "existem 10 carros")
	var seen: Dictionary = {}
	for i in 10:
		var g: GarageManager = Game.screen
		g._step(1)
		await frames(2)
		var d: Dictionary = g._def()
		seen[d["name"]] = float(d["kmh"]) + float(d["accel"]) * 1000.0
		ok(g._visual != null and g._visual.spinners.size() == 4, "modelo 3D de " + str(d["name"]) + " tem 4 rodas")
	ok(seen.size() == 10, "10 carros com nomes e estatísticas diferentes")
	var coins0: int = int(Game.save["coins"])
	var g2: GarageManager = Game.screen
	g2._idx = 2  # LUANDA X (1800)
	g2._rebuild_car()
	g2._refresh()
	g2._on_action()
	ok(int(Game.save["coins"]) == coins0 - 1800 and CarSelection.get_car("luanda_x")["owned"], "comprar carro gasta moedas")
	ok(str(Game.save["selected"]) == "luanda_x", "carro comprado fica selecionado")
	g2._idx = 9  # PEMBA HYPER (12000) — não há moedas
	g2._refresh()
	g2._on_action()
	ok(not CarSelection.get_car("pemba_hyper")["owned"], "sem moedas suficientes não compra")
	g2._idx = 2
	g2._refresh()
	var sv: Dictionary = CarSelection.get_car("luanda_x")
	var spd0: float = float(CarSelection.stats(CarData.by_id("luanda_x"), sv)["max_ms"])
	g2._on_upgrade(0)
	ok(int(sv["up_speed"]) == 1, "melhoria de velocidade sobe de nível")
	ok(float(CarSelection.stats(CarData.by_id("luanda_x"), sv)["max_ms"]) > spd0, "melhoria aumenta a velocidade máxima")
	g2._on_color(3)
	g2._on_rim()
	g2._on_finish()
	ok(int(sv["color"]) == 3 and int(sv["rim"]) == 1 and int(sv["finish"]) == 1, "cor, jantes e pintura mudam")
	Game.save_game()
	var saved: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(Game.SAVE_PATH))
	ok(saved["cars"]["luanda_x"]["owned"] == true and int(saved["coins"]) == int(Game.save["coins"]), "progresso guardado em disco")

	print("[condução]")
	Game.go_race()
	await frames(30)
	ok(Game.state == "race" and Game.screen is RaceManager, "corrida (teste de condução) abre")
	var r: RaceManager = Game.screen
	var car: CarController = r.car
	ok(str(car.stats["max_ms"]) != "", "carro tem estatísticas")
	ok(car.grounded, "carro assenta no chão")
	var p0: Vector3 = car.global_position
	r.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": false}
	await frames(180)
	var v1: float = car.speed_kmh
	ok(v1 > 40.0, "acelera: %.0f km/h após 3 s" % v1)
	ok(car.global_position.distance_to(p0) > 20.0, "o carro avança")
	ok(car.global_position.z < p0.z - 10.0, "anda para a frente (-Z)")
	var yaw0: float = car.rotation.y
	r.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": 1.0, "reverse": false, "handbrake": false}
	await frames(60)
	var dyaw: float = angle_difference(yaw0, car.rotation.y)
	ok(dyaw < -0.3, "direção para a direita vira o carro (%.2f rad)" % dyaw)
	r.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": -1.0, "reverse": false, "handbrake": false}
	var yaw1: float = car.rotation.y
	await frames(60)
	ok(angle_difference(yaw1, car.rotation.y) > 0.3, "direção para a esquerda vira o carro")
	var vb: float = car.speed_kmh
	r.controls.override_input = {"throttle": 0.0, "brake": 1.0, "steer": 0.0, "reverse": false, "handbrake": false}
	await frames(60)
	ok(car.speed_kmh < vb * 0.5, "travar reduz a velocidade (%.0f -> %.0f)" % [vb, car.speed_kmh])
	await frames(120)
	ok(car.speed_kmh < 3.0, "o carro pára")
	var pr: Vector3 = car.global_position
	r.controls.override_input = {"throttle": 0.0, "brake": 0.0, "steer": 0.0, "reverse": true, "handbrake": false}
	await frames(90)
	var back: float = (car.global_position - pr).dot(car.global_transform.basis.z)
	ok(back > 2.0, "marcha-atrás recua (%.1f m)" % back)
	r.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": false}
	await frames(180)
	var vhb: float = car.speed_kmh
	r.controls.override_input = {"throttle": 0.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": true}
	await frames(60)
	ok(car.speed_kmh < vhb * 0.6, "travão de mão trava")
	# câmaras
	var modes: Array = []
	for i in 3:
		r._on_camera()
		modes.append(r._cam.mode)
		await frames(3)
	ok(modes == [2, 3, 1], "câmaras alternam interior -> superior -> traseira")
	# pausa
	r.toggle_pause()
	await frames(3)
	ok(get_tree().paused and r._pause_panel != null, "pausa liga")
	r.toggle_pause()
	await frames(3)
	ok(not get_tree().paused, "pausa desliga")
	# diferenças reais entre carros
	var a: Dictionary = CarSelection.stats(CarData.by_id("maputo_s"), CarSelection.get_car("maputo_s"))
	var b: Dictionary = CarSelection.stats(CarData.by_id("pemba_hyper"), CarSelection.get_car("pemba_hyper"))
	ok(float(b["max_ms"]) > float(a["max_ms"]) and float(a["steer"]) > float(b["steer"]), "carros têm características diferentes")

	print("[voltar ao menu]")
	Game.go_menu()
	await frames(5)
	ok(Game.state == "menu" and not get_tree().paused, "voltar ao menu principal")
	Game.reset_save()
