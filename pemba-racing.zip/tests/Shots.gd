extends Node
## Tira capturas de ecrã de cada ecrã do jogo (precisa de um ecrã/GPU, ou xvfb): godot --path . -- --shots
func _ready() -> void:
	await get_tree().create_timer(1.5).timeout
	await _shot("menu")
	Game.screen._on_settings()
	await get_tree().create_timer(0.5).timeout
	await _shot("settings")
	Game.go_garage()
	await get_tree().create_timer(1.0).timeout
	await _shot("garage")
	Game.go_race()
	await get_tree().create_timer(1.0).timeout
	var r: RaceManager = Game.screen
	r.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": 0.3, "reverse": false, "handbrake": false}
	await get_tree().create_timer(3.0).timeout
	await _shot("race_rear")
	r._on_camera()
	await get_tree().create_timer(0.6).timeout
	await _shot("race_interior")
	r._on_camera()
	await get_tree().create_timer(0.6).timeout
	await _shot("race_top")
	get_tree().quit()

func _shot(n: String) -> void:
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	img.save_png("/tmp/pemba/shots/%s.png" % n)
