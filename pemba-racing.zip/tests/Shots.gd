extends Node
func _ready() -> void:
	await get_tree().create_timer(1.0).timeout
	Game.go_lobby()
	await get_tree().create_timer(0.4).timeout
	Game.screen._on_join_menu()
	await get_tree().create_timer(0.6).timeout
	await _shot("joinkeypad")
	get_tree().quit()

func _shot(n: String) -> void:
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("/tmp/pemba/shots/%s.png" % n)
