extends Node
func _ready() -> void:
	await get_tree().create_timer(1.0).timeout
	Game.go_race({"mode": "quick", "track": "savana", "laps": 3, "opponents": 7, "difficulty": 0})
	await get_tree().create_timer(5.5).timeout
	var r: RaceManager = Game.screen
	r.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": false, "nitro": false}
	await get_tree().create_timer(4.0).timeout
	r.controls.override_input["nitro"] = true
	await get_tree().create_timer(1.5).timeout
	await _shot("nitro")
	get_tree().quit()

func _shot(n: String) -> void:
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("/tmp/pemba/shots/%s.png" % n)
