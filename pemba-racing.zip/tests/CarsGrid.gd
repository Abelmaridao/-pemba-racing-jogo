extends Node
## Captura os 10 carros lado a lado (precisa de ecrã/xvfb): godot --path . -- --cars
func _ready() -> void:
	await get_tree().create_timer(0.8).timeout
	if Game.screen != null:
		Game.screen.queue_free()
	var w := Node3D.new()
	add_child(w)
	w.add_child(TrackManager.make_environment(Color(0.3, 0.5, 0.85), Color(0.8, 0.88, 0.95), 0.9, false))
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-45, -40, 0)
	w.add_child(sun)
	var floor_mi := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(80, 40)
	floor_mi.mesh = pm
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(0.25, 0.27, 0.3)
	floor_mi.material_override = fm
	w.add_child(floor_mi)
	for i in CarData.ALL.size():
		var def: Dictionary = CarData.ALL[i]
		var sv := {"color": i % 10, "rim": i % 5, "finish": 0, "up_speed": 0, "up_accel": 0, "up_brake": 0}
		var car := ProceduralCar.build(def, sv)
		car.position = Vector3((i % 5 - 2) * 6.5, 0, (i / 5) * 8.0 - 4.0)
		car.rotation.y = deg_to_rad(-35)
		w.add_child(car)
	var cam := Camera3D.new()
	cam.fov = 50
	w.add_child(cam)
	cam.position = Vector3(0, 11, 24)
	cam.look_at(Vector3(0, 0.5, 0), Vector3.UP)
	cam.current = true
	await get_tree().create_timer(1.0).timeout
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("/tmp/pemba/shots/cars10.png")
	get_tree().quit()
