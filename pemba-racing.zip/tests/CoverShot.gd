extends Node
## Captura o carro mais veloz (PEMBA HYPR) sozinho, sobre um fundo de cor sólida (chroma-key), para
## se poder recortar e usar como nova imagem/ícone de capa do jogo: godot --path . -- --cover
func _ready() -> void:
	await get_tree().create_timer(0.8).timeout
	if Game.screen != null:
		Game.screen.queue_free()
	var w := Node3D.new()
	add_child(w)
	var we := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(1, 0, 1)   # magenta: fácil de recortar a seguir
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(1, 1, 1)
	e.ambient_light_energy = 1.1
	we.environment = e
	w.add_child(we)
	var key := DirectionalLight3D.new()
	key.rotation_degrees = Vector3(-48, 35, 0)
	key.light_energy = 1.3
	w.add_child(key)
	var fill := DirectionalLight3D.new()
	fill.rotation_degrees = Vector3(-25, -140, 0)
	fill.light_energy = 0.6
	fill.light_color = Color(0.75, 0.82, 1.0)
	w.add_child(fill)
	var def: Dictionary = CarData.by_id("pemba_hyper")
	var sv := {"color": 0, "rim": 3, "finish": 2, "up_speed": 0, "up_accel": 0, "up_brake": 0}
	var car := ProceduralCar.build(def, sv)
	car.rotation.y = deg_to_rad(145)
	w.add_child(car)
	var cam := Camera3D.new()
	cam.fov = 36
	w.add_child(cam)
	cam.position = Vector3(4.8, 1.85, 5.9)
	cam.look_at(Vector3(0, 0.55, 0), Vector3.UP)
	cam.current = true
	await get_tree().create_timer(0.6).timeout
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("/tmp/pemba/shots/hyper_cover.png")
	get_tree().quit()
