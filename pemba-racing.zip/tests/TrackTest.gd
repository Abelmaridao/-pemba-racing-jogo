extends Node
## Corre uma volta em cada pista com adversários difíceis da IA e confirma que todos terminam: godot --headless --path . --fixed-fps 60 -- --tracktest
var fails: int = 0

func _ready() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	for td in TrackData.ALL:
		if "--only=none" in OS.get_cmdline_user_args() or (OS.get_cmdline_user_args().has("--one") and td["id"] != "savana"):
			continue
		Game.reset_save()
		Game.go_race({"mode": "quick", "track": td["id"], "laps": 1, "opponents": 7, "difficulty": (0 if "--diff=0" in OS.get_cmdline_user_args() else 2)})
		await get_tree().physics_frame
		var rc: RaceManager = Game.screen
		var pilot := AIController.new()
		pilot.setup(rc.car, rc.circuit, 0.95, 0.0, 0.0)
		var f: int = 0
		var stuck_frames: int = 0
		while f < 14000 and rc.state != "done":
			await get_tree().physics_frame
			f += 1
			if f % 10 == 0 and rc.state == "racing" and f < 0:
				var q := rc.racers[3] as Racer
				var tg: Vector3 = rc.circuit.T[q.idx]
				print("   T=%.0f idx=%d fs=%.1f t=%.2f lat=%.1f yaw=%.0f dist=%.0f vel=%.1f ctrl=%s thr=%s st=%s" % [rad_to_deg(atan2(-tg.x, -tg.z)), q.idx, q.car.forward_speed, f/60.0, rc.circuit.lateral(q.car.global_position, q.idx), rad_to_deg(q.car.rotation.y), q.dist, q.car.linear_velocity.length(), str(q.car.controllable), str(q.car.drive.get("throttle")), str(q.car.drive.get("steer"))])
			if rc.state == "racing":
				pilot.update(1.0 / 60.0)
				rc.controls.override_input = rc.car.drive.duplicate()
		var fin: int = 0
		for r in rc.racers:
			if (r as Racer).finished:
				fin += 1
		for r in rc.racers:
			var rr := r as Racer
			if not rr.finished:
				print("   preso: %s dist=%.0f/%d volta=%d vel=%.1f" % [rr.name_txt if "name_txt" in rr else str(rr.name), rr.dist, rc.circuit.N * 1, rr.laps, rr.car.linear_velocity.length()])
		var best: float = 1e9
		for row in rc._result_rows:
			if float(row["time"]) > 0.0:
				best = minf(best, float(row["time"]))
		print("   posição final do piloto de teste (skill 0.95): %d/8" % rc.me.rank)
		var okk: bool = rc.state == "done" and fin == 8
		if not okk:
			fails += 1
		print("%s %s: terminaram %d/8, melhor volta %.1f s, %d s simulados" % ["OK  " if okk else "FALHA", td["id"], fin, best, int(f / 60)])
	print("== tracktest: %d falhas ==" % fails)
	get_tree().quit(1 if fails > 0 else 0)
