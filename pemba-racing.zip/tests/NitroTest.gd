extends Node
func _ready() -> void:
	await get_tree().process_frame
	Game.go_race({"mode": "test"})
	await get_tree().physics_frame
	var rc: RaceManager = Game.screen
	var c: CarController = rc.car
	rc.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": false, "nitro": false}
	for i in 600:
		await get_tree().physics_frame
	var base: float = c.speed_kmh
	print("sem nitro após 10 s: %.0f km/h, carga %.2f" % [base, c.nitro])
	rc.controls.override_input["nitro"] = true
	var peak: float = 0.0
	var used_at: int = -1
	for i in 360:
		await get_tree().physics_frame
		peak = maxf(peak, c.speed_kmh)
		if used_at < 0 and c.nitro < 0.03:
			used_at = i
	print("com nitro: pico %.0f km/h; carga %.2f; esgotou aos %.1f s; nitro_on=%s" % [peak, c.nitro, used_at / 60.0, str(c.nitro_on)])
	rc.controls.override_input["nitro"] = false
	for i in 720:
		await get_tree().physics_frame
	print("recarga após 12 s: %.2f" % c.nitro)
	var ok: bool = peak > base * 1.1 and used_at > 120 and used_at < 240 and c.nitro > 0.9
	print("NITRO ", "OK" if ok else "FALHA")
	get_tree().quit(0 if ok else 1)
