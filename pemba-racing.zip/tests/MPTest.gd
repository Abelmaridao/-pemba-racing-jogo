extends Node
## Teste de multiplayer em localhost: godot --headless --path . -- --mp-test=host|client
var role: String = "client"
var t: float = 0.0
var stage: int = 0
var start_pos := {}
func _ready() -> void:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--mp-test="):
			role = a.substr(10)
	await get_tree().process_frame
	await get_tree().process_frame
	if role == "host":
		var e: int = MP.create_room()
		print("[host] criar sala: ", e)
	else:
		await get_tree().create_timer(1.5 + randf() * 0.5).timeout
		var e2: int = MP.join_room("127.0.0.1")
		print("[client] entrar: ", e2)

func _physics_process(delta: float) -> void:
	t += delta
	if role == "host" and stage == 0 and MP.players.size() >= 3:
		print("[host] jogadores na sala: ", MP.players.size())
		MP.laps = 1
		stage = 1
		await get_tree().create_timer(1.0).timeout
		print("[host] iniciar corrida: ", MP.start_race())
	var rc = Game.screen as RaceManager
	if rc != null and rc.me != null and MP.in_race:
		if stage < 2:
			stage = 2
			print("[%s] corrida carregada, id=%d" % [role, MP.my_id()])
			start_pos = {}
		if rc.state == "racing":
			rc.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": false}
		if rc.state == "racing" and stage == 2:
			stage = 3
			print("[%s] semaforo verde (GO) recebido aos %.1f s" % [role, t])
			for k in MP.states.keys():
				start_pos[k] = (MP.states[k]["pos"] as Vector3)
			set_meta("go_t", t)
		if stage == 3 and t - float(get_meta("go_t")) > 8.0:
			var moved: int = 0
			for k in MP.states.keys():
				if k in start_pos and (MP.states[k]["pos"] as Vector3).distance_to(start_pos[k]) > 5.0:
					moved += 1
			var remotes: int = 0
			var rem_moved: int = 0
			for r in rc.racers:
				if (r as Racer).remote:
					remotes += 1
					if (r.car as Node3D).global_position.distance_to(((r.car as CarController).grid_pos if "grid_pos" in r.car else (r.car as Node3D).global_position)) >= 0.0:
						rem_moved += 1
			print("[%s] RESULTADO: estados recebidos=%d, carros remotos=%d, remotos que se moveram (estado)=%d, eu: %.0f km/h" % [role, MP.states.size(), remotes, moved, rc.car.speed_kmh])
			var ok: bool = MP.states.size() == 2 and remotes == 2 and moved == 2
			print("[%s] %s" % [role, "OK" if ok else "FALHA"])
			get_tree().quit(0 if ok else 1)
	if t > 60.0:
		print("[%s] FALHA: tempo esgotado, stage=%d players=%d" % [role, stage, MP.players.size()])
		get_tree().quit(1)
