extends Node
func _ready() -> void:
	await get_tree().process_frame
	Game.go_race({"mode": "quick", "track": "savana", "laps": 3, "opponents": 7, "difficulty": 1})
	await get_tree().physics_frame
	var rc: RaceManager = Game.screen
	var c: CarController = rc.car
	var ys := []
	var lastp := c.global_position
	var dmax := 0.0
	var vmax := 0.0
	for i in 150:
		await get_tree().physics_frame
		ys.append(c.global_position.y)
		dmax = maxf(dmax, c.global_position.distance_to(lastp))
		lastp = c.global_position
		vmax = maxf(vmax, c.linear_velocity.length() + c.angular_velocity.length())
		if i % 25 == 0:
			print("f%d y=%.3f v=%.3f w=%.3f state=%s" % [i, c.global_position.y, c.linear_velocity.length(), c.angular_velocity.length(), rc.state])
	var mn: float = ys.min()
	var mx: float = ys.max()
	print("y min %.3f max %.3f; passo max %.4f; v+w max %.3f" % [mn, mx, dmax, vmax])
	get_tree().quit()
