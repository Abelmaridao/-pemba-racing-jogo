extends Node
func _ready() -> void:
	await get_tree().process_frame
	for td in TrackData.ALL:
		var c := Circuit.new()
		add_child(c)
		c.build(td)
		var mind := 1e9
		var N: int = c.N
		for i in range(0, N, 2):
			for j in range(i + int(60.0 / c.ds), N, 2):
				if N - (j - i) < int(60.0 / c.ds):
					continue
				mind = minf(mind, c.P[i].distance_to(c.P[j]))
		var bad := 0
		for n in range(8):
			var t: Transform3D = c.grid_slot(n)
			var g: int = c.nearest_global(t.origin)
			var exp_i: int = (N - int((9.0 + (n / 2) * 9.0) / c.ds)) % N
			if absi(g - exp_i) > 4 and N - absi(g - exp_i) > 4:
				bad += 1
		print("%s: N=%d dist_min_autoproximidade=%.1f m grelha_mal=%d" % [td["id"], N, mind, bad])
	get_tree().quit()
