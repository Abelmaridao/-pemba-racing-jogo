extends Node
## Teste automático (corre sem ecrã): godot --headless --path . --fixed-fps 60 -- --selftest
## Verifica: menu, garagem (10 carros, compra, personalização, melhorias), condução (acelerar, virar, travar,
## marcha-atrás, travão de mão), câmaras, pausa e configurações. Sai com código 0 se tudo passar.

var fails: int = 0
var checks: int = 0


func ok(cond: bool, msg: String) -> void:
	checks += 1
	if cond:
		print("  OK   ", msg)
	else:
		fails += 1
		print("  FALHA ", msg)


func frames(n: int) -> void:
	for i in n:
		await get_tree().physics_frame


func _ready() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	await run()
	print("== %d verificações, %d falhas ==" % [checks, fails])
	get_tree().quit(1 if fails > 0 else 0)


func run() -> void:
	print("[menu]")
	Game.reset_save()
	Game.go_menu()
	await frames(5)
	ok(Game.state == "menu" and Game.screen is MainMenuManager, "menu principal abre")
	ok(Game.screen._buttons.size() == 6, "6 botões no menu")
	Game.screen._on_settings()
	await frames(2)
	ok(Game.screen._overlay != null, "painel Configurações abre")
	var lang_before: int = Settings.language
	Settings.language = 1
	Game.screen._build_ui()
	Game.screen._on_settings()
	await frames(2)
	ok(Game.screen._overlay != null, "idioma inglês reconstrói o menu")
	Settings.language = 0
	Settings.quality = 2
	Settings.apply()
	Settings.quality = 0
	Settings.apply()
	Settings.save()
	ok(Engine.max_fps == 30, "qualidade baixa limita a 30 FPS")
	Settings.quality = 1
	Settings.apply()
	ok(Engine.max_fps == 60, "qualidade média usa 60 FPS")

	print("[garagem]")
	Game.go_garage()
	await frames(5)
	ok(Game.state == "garage" and Game.screen is GarageManager, "garagem abre")
	ok(CarData.ALL.size() == 10, "existem 10 carros")
	var seen: Dictionary = {}
	for i in 10:
		var g: GarageManager = Game.screen
		g._step(1)
		await frames(2)
		var d: Dictionary = g._def()
		seen[d["name"]] = float(d["kmh"]) + float(d["accel"]) * 1000.0
		ok(g._visual != null and g._visual.spinners.size() == 4, "modelo 3D de " + str(d["name"]) + " tem 4 rodas")
	ok(seen.size() == 10, "10 carros com nomes e estatísticas diferentes")
	var coins0: int = int(Game.save["coins"])
	var g2: GarageManager = Game.screen
	g2._idx = 2  # LUANDA X (1800)
	g2._rebuild_car()
	g2._refresh()
	g2._on_action()
	ok(int(Game.save["coins"]) == coins0 - 1800 and CarSelection.get_car("luanda_x")["owned"], "comprar carro gasta moedas")
	ok(str(Game.save["selected"]) == "luanda_x", "carro comprado fica selecionado")
	g2._idx = 9  # PEMBA HYPER (12000) — não há moedas
	g2._refresh()
	g2._on_action()
	ok(not CarSelection.get_car("pemba_hyper")["owned"], "sem moedas suficientes não compra")
	g2._idx = 2
	g2._refresh()
	var sv: Dictionary = CarSelection.get_car("luanda_x")
	var spd0: float = float(CarSelection.stats(CarData.by_id("luanda_x"), sv)["max_ms"])
	g2._on_upgrade(0)
	ok(int(sv["up_speed"]) == 1, "melhoria de velocidade sobe de nível")
	ok(float(CarSelection.stats(CarData.by_id("luanda_x"), sv)["max_ms"]) > spd0, "melhoria aumenta a velocidade máxima")
	g2._on_color(3)
	g2._on_rim()
	g2._on_finish()
	ok(int(sv["color"]) == 3 and int(sv["rim"]) == 1 and int(sv["finish"]) == 1, "cor, jantes e pintura mudam")
	Game.save_game()
	var saved: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(Game.SAVE_PATH))
	ok(saved["cars"]["luanda_x"]["owned"] == true and int(saved["coins"]) == int(Game.save["coins"]), "progresso guardado em disco")

	print("[condução]")
	Game.go_race()
	await frames(30)
	ok(Game.state == "race" and Game.screen is RaceManager, "corrida (teste de condução) abre")
	var r: RaceManager = Game.screen
	var car: CarController = r.car
	ok(str(car.stats["max_ms"]) != "", "carro tem estatísticas")
	ok(car.grounded, "carro assenta no chão")
	var p0: Vector3 = car.global_position
	r.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": false}
	await frames(180)
	var v1: float = car.speed_kmh
	ok(v1 > 40.0, "acelera: %.0f km/h após 3 s" % v1)
	ok(car.global_position.distance_to(p0) > 20.0, "o carro avança")
	ok(car.global_position.z < p0.z - 10.0, "anda para a frente (-Z)")
	var yaw0: float = car.rotation.y
	r.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": 1.0, "reverse": false, "handbrake": false}
	await frames(60)
	var dyaw: float = angle_difference(yaw0, car.rotation.y)
	ok(dyaw < -0.3, "direção para a direita vira o carro (%.2f rad)" % dyaw)
	r.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": -1.0, "reverse": false, "handbrake": false}
	var yaw1: float = car.rotation.y
	await frames(60)
	ok(angle_difference(yaw1, car.rotation.y) > 0.3, "direção para a esquerda vira o carro")
	var vb: float = car.speed_kmh
	r.controls.override_input = {"throttle": 0.0, "brake": 1.0, "steer": 0.0, "reverse": false, "handbrake": false}
	await frames(60)
	ok(car.speed_kmh < vb * 0.5, "travar reduz a velocidade (%.0f -> %.0f)" % [vb, car.speed_kmh])
	await frames(120)
	ok(car.speed_kmh < 3.0, "o carro pára")
	var pr: Vector3 = car.global_position
	r.controls.override_input = {"throttle": 0.0, "brake": 0.0, "steer": 0.0, "reverse": true, "handbrake": false}
	await frames(90)
	var back: float = (car.global_position - pr).dot(car.global_transform.basis.z)
	ok(back > 2.0, "marcha-atrás recua (%.1f m)" % back)
	r.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": false}
	await frames(180)
	var vhb: float = car.speed_kmh
	r.controls.override_input = {"throttle": 0.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": true}
	await frames(60)
	ok(car.speed_kmh < vhb * 0.6, "travão de mão trava")
	# câmaras
	var modes: Array = []
	for i in 3:
		r._on_camera()
		modes.append(r._cam.mode)
		await frames(3)
	ok(modes == [2, 3, 1], "câmaras alternam interior -> superior -> traseira")
	# pausa
	r.toggle_pause()
	await frames(3)
	ok(get_tree().paused and r._pause_panel != null, "pausa liga")
	r.toggle_pause()
	await frames(3)
	ok(not get_tree().paused, "pausa desliga")
	# diferenças reais entre carros
	var a: Dictionary = CarSelection.stats(CarData.by_id("maputo_s"), CarSelection.get_car("maputo_s"))
	var b: Dictionary = CarSelection.stats(CarData.by_id("pemba_hyper"), CarSelection.get_car("pemba_hyper"))
	ok(float(b["max_ms"]) > float(a["max_ms"]) and float(a["steer"]) > float(b["steer"]), "carros têm características diferentes")

	print("[pistas]")
	for td in TrackData.ALL:
		var c := Circuit.new()
		add_child(c)
		c.build(td)
		var kmax: float = 0.0
		for i in c.N:
			kmax = maxf(kmax, c.K[i])
		var closed: bool = c.P[0].distance_to(c.P[c.N - 1]) < c.ds * 1.5
		ok(c.N > 200 and c.length > 1400.0 and c.length < 2800.0 and closed and kmax < 1.0 / 35.0,
			"pista %s: %.0f m, curva mais apertada %.0f m, fechada" % [td["id"], c.length, 1.0 / maxf(kmax, 0.0001)])
		ok(c.surface(c.P[10], 10) > 0.99 and c.surface(c.P[10] + c.R[10] * (c.hw + 8.0), 10) < 0.01, "pista %s: estrada = aderência total, relva = menos" % td["id"])
		c.queue_free()
	await frames(2)

	print("[corrida com adversários]")
	Game.reset_save()
	var coins_race: int = int(Game.save["coins"])
	Game.go_race({"mode": "quick", "track": "savana", "laps": 1, "opponents": 3, "difficulty": 2})
	await frames(5)
	var rc: RaceManager = Game.screen
	ok(rc.mode == "quick" and rc.circuit != null and rc.racers.size() == 4, "corrida rápida abre com 4 pilotos")
	ok(rc.state == "countdown", "começa com contagem")
	var pcar: CarController = rc.car
	var pilot := AIController.new()
	pilot.setup(pcar, rc.circuit, 0.9, 0.0, 0.0)
	var f: int = 0
	var started_at: int = -1
	while f < 12000 and not (rc.state == "done"):
		await get_tree().physics_frame
		f += 1
		if rc.state == "racing":
			if started_at < 0:
				started_at = f
			pilot.update(1.0 / 60.0)
			rc.controls.override_input = pcar.drive.duplicate()
		if f == 600:
			var mv: int = 0
			for rcr in rc.racers:
				if (rcr as Racer).dist > 5.0:
					mv += 1
			ok(mv == 4, "depois de 10 s os 4 carros avançaram na pista")
	ok(started_at > 150 and started_at < 230, "contagem 3-2-1 demora ~3 s (começou no frame %d)" % started_at)
	ok(rc.state == "done", "a corrida termina (%d s simulados)" % int(f / 60))
	var nfin: int = 0
	var ranks: Array = []
	for rcr in rc.racers:
		if (rcr as Racer).finished:
			nfin += 1
		ranks.append((rcr as Racer).rank)
	ranks.sort()
	ok(nfin == 4, "os 4 pilotos terminam a volta (nenhum ficou preso)")
	ok(ranks == [1, 2, 3, 4], "classificação 1..4 sem repetidos")
	ok(rc.me.laps == 1 and rc.me.best_lap > 20.0 and rc.me.best_lap < 150.0, "volta do jogador medida: %.1f s" % rc.me.best_lap)
	ok(rc._results != null and int(Game.save["coins"]) > coins_race, "resultados aparecem e dão moedas (+%d)" % (int(Game.save["coins"]) - coins_race))
	print("   tempos: ", rc._result_rows.map(func(row: Dictionary) -> String: return "%s %.1f" % [row["name"], row["time"]]))

	print("[campeonato]")
	Game.reset_save()
	ok(not Championship.active(), "sem campeonato ativo no início")
	Championship.start_new(1)
	ok(Championship.active() and Championship.round_index() == 0 and Championship.standings().size() == 8, "campeonato começa com 8 pilotos")
	var coins1: int = int(Game.save["coins"])
	var expect_alive := [8, 6, 4, 3, 2]
	for round_n in 5:
		var cfgc: Dictionary = Championship.next_cfg()
		ok(cfgc["track"] == TrackData.ALL[round_n]["id"] and cfgc["opponents"] == expect_alive[round_n] - 1, "corrida %d: %d pilotos, pista %s" % [round_n + 1, expect_alive[round_n], cfgc["track"]])
		var rows: Array = [{"name": "TU"}]
		for n in cfgc["names"]:
			rows.append({"name": n})
		Championship.record_race(rows)
		var after: Array = [6, 4, 3, 2, 2]
		ok(Championship.alive().size() == after[round_n], "depois da corrida %d ficam %d pilotos" % [round_n + 1, after[round_n]])
	ok(Championship.finished() and not Championship.player_out() and int(Championship.state()["place"]) == 1, "ganhar a final dá o 1º lugar")
	ok(int(Game.save["coins"]) == coins1 + 3000, "prémio de campeão +3000 moedas")
	# ser eliminado: ficar em último na corrida 1 acaba o campeonato
	Championship.start_new(1)
	var cf2: Dictionary = Championship.next_cfg()
	var rows2: Array = []
	for n in cf2["names"]:
		rows2.append({"name": n})
	rows2.append({"name": "TU"})
	var coins2: int = int(Game.save["coins"])
	Championship.record_race(rows2)
	ok(Championship.finished() and Championship.player_out() and int(Championship.state()["place"]) == 8, "último na corrida 1 = eliminado em 8º")
	ok(int(Game.save["coins"]) == coins2 + 200, "eliminado recebe o prémio do lugar (+200)")
	Championship.start_new(1)
	Game.go_champ()
	await frames(3)
	ok(Game.state == "champ" and Game.screen is ChampionshipScreen, "ecrã do campeonato abre")
	Championship.reset()

	print("[ecrã de corrida rápida e multiplayer]")
	Game.go_setup()
	await frames(3)
	ok(Game.state == "setup", "ecrã Jogar abre")
	Game.screen._move_track(1)
	Game.screen._start()
	await frames(5)
	ok(Game.state == "race" and Game.screen.cfg["track"] == "deserto", "escolher pista e começar abre a corrida certa")
	Game.go_lobby()
	await frames(3)
	ok(Game.state == "lobby", "ecrã Multiplayer abre")
	Game.screen._on_create()
	await frames(3)
	ok(Net.hosting and MP.players.size() == 1 and Game.screen._view == "room", "criar sala funciona (anfitrião)")
	MP.leave()
	ok(not Net.hosting, "sair da sala fecha o servidor")

	print("[carros diferentes na condução]")
	var accel_res: Dictionary = {}
	for cid in ["pickup_dummy", "zambezi_rs", "benguela_v12", "luanda_x"]:
		if cid == "pickup_dummy":
			continue
		Game.reset_save()
		Game.save["selected"] = cid
		Game.go_race()
		await frames(3)
		var rr2: RaceManager = Game.screen
		rr2.controls.override_input = {"throttle": 1.0, "brake": 0.0, "steer": 0.0, "reverse": false, "handbrake": false}
		await frames(240)
		accel_res[cid] = rr2.car.speed_kmh
	ok(float(accel_res["benguela_v12"]) > float(accel_res["zambezi_rs"]) * 1.4, "fórmula acelera muito mais que a pick-up (%.0f vs %.0f km/h em 4 s)" % [accel_res["benguela_v12"], accel_res["zambezi_rs"]])
	ok(float(accel_res["luanda_x"]) > float(accel_res["zambezi_rs"]), "muscle car acelera mais que a pick-up")
	Game.reset_save()
	Settings.quality = 0
	Settings.apply()
	ok(is_equal_approx(get_viewport().scaling_3d_scale, 0.58), "qualidade baixa reduz a resolução 3D (mais leve)")

	print("[voltar ao menu]")
	Game.go_menu()
	await frames(5)
	ok(Game.state == "menu" and not get_tree().paused, "voltar ao menu principal")
	Game.reset_save()
